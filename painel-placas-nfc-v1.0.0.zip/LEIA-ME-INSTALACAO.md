# Painel de Placas NFC · Instalação na Hostinger

Sistema web para gerenciar estoque, vendas, clientes, instalações e acompanhamento das placas de avaliação NFC + QR Code.
O sistema não gera QR nem NFC: as placas continuam sendo geridas no painel da PlacasOn, e aqui você organiza a parte comercial.

## O que tem no ZIP

```
painel/                  -> tudo o que vai para o servidor
  app/                   -> código interno (bloqueado para acesso pela web)
    schema.sql           -> estrutura do banco (o instalador executa sozinho)
  install/               -> instalador (APAGUE depois de instalar)
  uploads/               -> fotos dos modelos (só imagens são servidas)
  assets/                -> CSS, JS, Bootstrap e ícones (sem depender de CDN)
  *.php                  -> páginas do painel
LEIA-ME-INSTALACAO.md    -> este arquivo
TESTE-MANUAL.md          -> roteiro de teste do fluxo completo
```

## Requisitos

- PHP 8.2 ou superior (recomendado 8.4, que a Hostinger oferece)
- Extensões `pdo_mysql`, `mbstring` e `gd` (já vêm ativas na Hostinger)
- Banco MySQL ou MariaDB
- SSL ativo no domínio (a Hostinger dá SSL grátis)

## Passo a passo

### 1. Criar o banco de dados
1. No hPanel, abra **Bancos de dados > Gerenciamento**.
2. Crie um banco novo. Anote o **nome do banco**, o **usuário** e a **senha** (a Hostinger coloca um prefixo, tipo `u123456789_placas`).
3. O servidor do banco na Hostinger normalmente é `localhost`.

### 2. Escolher a versão do PHP
1. No hPanel, abra **Avançado > Configuração do PHP**.
2. Selecione **PHP 8.4** (ou 8.3) e salve.

### 3. Enviar os arquivos
Você pode instalar no domínio principal ou em uma subpasta (recomendado, por ex. `seudominio.com.br/painel`).

1. Abra o **Gerenciador de Arquivos** e entre em `public_html`.
2. Se for usar subpasta, crie a pasta (ex.: `painel`) e entre nela.
3. Envie o ZIP e use **Extrair**. Depois mova o **conteúdo** da pasta `painel/` do ZIP para a pasta de destino, de forma que `index.php` fique direto em `public_html/painel/` (ou em `public_html/`).
4. Confira que os arquivos `.htaccess` foram junto (raiz, `app/` e `uploads/`). No Gerenciador de Arquivos eles aparecem normalmente.

### 4. Rodar o instalador
1. Acesse `https://seudominio.com.br/painel/install/`.
2. Todos os requisitos devem aparecer com ✓.
3. Preencha os dados do banco (passo 1) e crie seu usuário e senha de acesso (mínimo 10 caracteres, com letras e números).
4. Deixe marcado **Forçar HTTPS**.
5. Clique em **Instalar**.

### 5. Apagar o instalador
No Gerenciador de Arquivos, **apague a pasta `install/`**. O instalador já se recusa a rodar de novo depois de instalado, mas apagar é a prática segura.

### 6. Primeiro acesso
1. Entre em `https://seudominio.com.br/painel/`.
2. Vá em **Configurações** e preencha WhatsApp, Instagram e cidade (aparecem no card e no PDF de ofertas). Confira os preços (já vêm com avulsa R$ 80, combo R$ 250, kit R$ 140, upgrade R$ 170 e mensalidade R$ 24,90).
3. Em **Lotes**, registre as placas que você já tem.
4. Se você já tem o Classic Centro de Beleza instalado, registre a venda com data 29/09 ou 30/09 e a instalação com o marco zero de 30/09/2026 (nota 4,9, 126 avaliações). Assim as checagens já começam com o histórico certo.

## Segurança que já vem configurada

- Senha guardada com hash Argon2id (ou bcrypt, se o servidor não tiver Argon2).
- Sessão com expiração: 60 min parado ou 12 h no total. Cookie `HttpOnly`, `Secure` em HTTPS e `SameSite=Lax`.
- Limite de tentativas: 5 erros em 15 min bloqueiam o login por 15 min (por IP e por usuário).
- Token CSRF em todos os formulários.
- Consultas ao banco só com parâmetros (sem SQL montado com texto do usuário).
- Cabeçalhos de segurança (CSP, X-Frame-Options, HSTS em HTTPS).
- Pasta `app/` bloqueada para acesso pela web. Pasta `uploads/` só serve imagens, e toda foto enviada é recodificada (remove metadados e qualquer conteúdo escondido).
- Páginas marcadas como `noindex` (não aparecem no Google).

Para mudar o tempo de sessão, edite `app/config.php` (`session_idle_min` e `session_max_horas`).

## Backup

No hPanel, **Bancos de dados > phpMyAdmin > Exportar** gera um `.sql` com todos os dados. Vale exportar uma vez por mês, junto com a pasta `uploads/`.

## Esqueci a senha

Abra o phpMyAdmin, rode no seu computador `php -r "echo password_hash('NovaSenha2026', PASSWORD_BCRYPT);"` (ou peça para o Claude gerar o hash) e cole o resultado no campo `senha_hash` da tabela `usuarios`. Depois troque a senha em **Configurações**.

## Link do painel de scans da PlacasOn

Cada placa tem um campo **ID PlacasOn** e o botão **Scans na PlacasOn**. Por padrão o botão abre `https://placason.com.br/cliente`.
Se o painel da PlacasOn tiver um endereço próprio por placa, coloque em **Configurações** usando `{id}` no lugar do código, por exemplo `https://placason.com.br/cliente/placa/{id}`. O painel não faz login nem lê dados da conta da PlacasOn: ele só abre o link.

## Problemas comuns

| Sintoma | Solução |
| --- | --- |
| Erro 500 logo depois de enviar | Confira a versão do PHP (passo 2) |
| Instalador mostra ✗ em "permissão de escrita" | No Gerenciador de Arquivos, deixe as pastas `app/` e `uploads/` com permissão 755 |
| "Erro no banco de dados: Access denied" | Usuário ou senha do banco incorretos, ou o usuário não foi ligado ao banco no hPanel |
| Fica redirecionando sem parar | SSL ainda não ativo. Ative o SSL no hPanel, ou mude `force_https` para `false` em `app/config.php` |
| "Sessão inválida ou expirada" | A página ficou aberta muito tempo. Recarregue e envie de novo |
