<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require_login();

$id = get_int('id') ?: post_int('id');
$p = q_one('SELECT p.*, m.nome AS modelo, l.custo_unitario, l.data_compra, c.nome AS cliente, c.whatsapp, v.tipo AS venda_tipo, v.valor AS venda_valor
    FROM placas p JOIN modelos m ON m.id = p.modelo_id JOIN lotes l ON l.id = p.lote_id
    LEFT JOIN clientes c ON c.id = p.cliente_id LEFT JOIN vendas v ON v.id = p.venda_id WHERE p.id = ?', [$id]);
if (!$p) {
    not_found('Placa não encontrada.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = post('acao');
    $volta = 'placa.php?id=' . $id;
    try {
        switch ($acao) {
            case 'dados':
                q('UPDATE placas SET placason_id = ?, observacoes = ? WHERE id = ?', [mb_substr(post('placason_id'), 0, 80), post('observacoes'), $id]);
                flash('success', 'Dados da placa salvos.');
                break;
            case 'instalar':
                registrar_instalacao($id, post('data_instalacao'), post('marco_nota'), post('marco_avaliacoes'), post('local_instalacao'));
                flash('success', 'Instalação registrada com marco zero. As checagens de 7 e 30 dias vão aparecer no painel.');
                break;
            case 'editar_marco':
                $n = parse_nota(post('marco_nota'));
                $data = valid_date(post('data_instalacao'));
                if ($n === null || !ctype_digit(post('marco_avaliacoes')) || !$data) {
                    throw new DomainException('Confira data, nota (1,0 a 5,0) e total de avaliações.');
                }
                q('UPDATE placas SET data_instalacao = ?, marco_nota = ?, marco_avaliacoes = ?, local_instalacao = ? WHERE id = ?',
                    [$data, $n, (int)post('marco_avaliacoes'), mb_substr(post('local_instalacao'), 0, 120), $id]);
                flash('success', 'Marco zero corrigido.');
                break;
            case 'checagem':
                registrar_checagem($id, post('data_checagem'), post('nota'), post('avaliacoes'), post('scans'), post('observacoes'));
                flash('success', 'Checagem registrada.');
                $volta .= '#checagem';
                break;
            case 'excluir_checagem':
                q('DELETE FROM checagens WHERE id = ? AND placa_id = ?', [post_int('checagem_id'), $id]);
                flash('success', 'Checagem excluída.');
                $volta .= '#checagem';
                break;
            case 'desativar':
                desativar_placa($id, post('motivo'));
                flash('success', 'Placa marcada como desativada. Lembre de desativar também no painel da PlacasOn.');
                break;
            case 'reativar':
                reativar_placa($id);
                flash('success', 'Placa reativada. Lembre de reativar também no painel da PlacasOn.');
                break;
            case 'substituir':
                substituir_placa($id, post_int('nova_id'), post('motivo'));
                $nova = q_val('SELECT codigo FROM placas WHERE id = ?', [post_int('nova_id')]);
                flash('success', "Placa substituída por {$nova}. Registre a instalação da nova placa.");
                $volta = 'placa.php?id=' . post_int('nova_id');
                break;
        }
    } catch (DomainException $e) {
        flash('danger', $e->getMessage());
    }
    redirect($volta);
}

$checagens = q_all('SELECT * FROM checagens WHERE placa_id = ? ORDER BY data_checagem, id', [$id]);
$estoque = in_array($p['status'], ['vendida', 'instalada'], true)
    ? q_all("SELECT p.id, p.codigo, m.nome FROM placas p JOIN modelos m ON m.id = p.modelo_id WHERE p.status = 'estoque' ORDER BY (p.modelo_id = ?) DESC, p.codigo LIMIT 200", [$p['modelo_id']])
    : [];
$scanUrl = placason_link($p['placason_id']);

layout_header($p['codigo'], 'placas');
$acoes = '';
if ($p['status'] === 'estoque') {
    $acoes .= '<a class="btn btn-primary" href="venda_nova.php?placa=' . $id . '"><i class="bi bi-cart-plus me-1"></i>Vender esta placa</a>';
}
$acoes .= '<a class="btn btn-outline-dark" href="' . h($scanUrl) . '" target="_blank" rel="noopener noreferrer"><i class="bi bi-box-arrow-up-right me-1"></i>Scans na PlacasOn</a>';
page_title($p['codigo'], status_placa_badge($p['status']) . ' <span class="ms-1">' . h($p['modelo']) . '</span>', $acoes);
?>
<div class="row g-4">
  <div class="col-lg-5">
    <div class="card mb-4">
      <div class="card-header">Ficha da placa</div>
      <div class="card-body">
        <dl class="ficha row mb-0">
          <dt class="col-5">Código</dt><dd class="col-7 code-pill"><?= h($p['codigo']) ?></dd>
          <dt class="col-5">Modelo</dt><dd class="col-7"><?= h($p['modelo']) ?></dd>
          <dt class="col-5">Lote</dt><dd class="col-7"><a href="placas.php?lote=<?= $p['lote_id'] ?>">#<?= $p['lote_id'] ?></a> · <?= date_br($p['data_compra']) ?> · custo <?= money($p['custo_unitario']) ?></dd>
          <dt class="col-5">Status</dt><dd class="col-7"><?= status_placa_badge($p['status']) ?></dd>
          <dt class="col-5">Cliente</dt><dd class="col-7"><?= $p['cliente_id'] ? '<a href="cliente.php?id=' . $p['cliente_id'] . '">' . h($p['cliente']) . '</a>' : '-' ?></dd>
          <dt class="col-5">Oferta</dt><dd class="col-7"><?= $p['venda_id'] ? '<a href="venda.php?id=' . $p['venda_id'] . '">' . h(tipo_venda_label($p['venda_tipo'])) . '</a> · ' . money($p['venda_valor']) : '-' ?></dd>
          <dt class="col-5">Data da venda</dt><dd class="col-7"><?= date_br($p['data_venda']) ?></dd>
          <dt class="col-5">Data da instalação</dt><dd class="col-7"><?= date_br($p['data_instalacao']) ?></dd>
          <dt class="col-5">Local</dt><dd class="col-7"><?= h($p['local_instalacao'] ?: '-') ?></dd>
        </dl>
      </div>
    </div>

    <div class="card mb-4">
      <div class="card-header">PlacasOn e observações</div>
      <div class="card-body">
        <form method="post">
          <?= csrf_field() ?><input type="hidden" name="acao" value="dados"><input type="hidden" name="id" value="<?= $id ?>">
          <label class="form-label">ID da placa no painel PlacasOn</label>
          <input class="form-control font-monospace mb-1" name="placason_id" value="<?= h($p['placason_id']) ?>" placeholder="Código que aparece no painel do fornecedor">
          <div class="form-text mb-3">O botão "Scans na PlacasOn" abre <?= h(cfg('placason_url')) ?>. Ajuste o endereço em Configurações.</div>
          <label class="form-label">Observações</label>
          <textarea class="form-control mb-3" name="observacoes" rows="3"><?= h($p['observacoes']) ?></textarea>
          <button class="btn btn-outline-primary">Salvar</button>
        </form>
      </div>
    </div>

    <?php if (in_array($p['status'], ['vendida', 'instalada', 'desativada'], true)): ?>
    <div class="card mb-4">
      <div class="card-header">Ações da placa</div>
      <div class="card-body d-grid gap-3">
        <?php if ($p['status'] === 'desativada'): ?>
          <form method="post" data-confirm="Reativar esta placa?"><?= csrf_field() ?><input type="hidden" name="acao" value="reativar"><input type="hidden" name="id" value="<?= $id ?>">
            <button class="btn btn-outline-success w-100"><i class="bi bi-play-circle me-1"></i>Reativar placa</button></form>
        <?php else: ?>
          <form method="post" data-confirm="Marcar a placa como desativada?">
            <?= csrf_field() ?><input type="hidden" name="acao" value="desativar"><input type="hidden" name="id" value="<?= $id ?>">
            <div class="input-group"><input class="form-control" name="motivo" placeholder="Motivo (ex.: inadimplência)"><button class="btn btn-outline-dark">Desativar</button></div>
          </form>
          <?php if ($estoque): ?>
          <form method="post" data-confirm="Substituir esta placa pela selecionada? A atual fica desativada.">
            <?= csrf_field() ?><input type="hidden" name="acao" value="substituir"><input type="hidden" name="id" value="<?= $id ?>">
            <label class="form-label small text-secondary mb-1">Trocar por defeito (garantia)</label>
            <select class="form-select mb-2" name="nova_id" required><?php foreach ($estoque as $e): ?><option value="<?= $e['id'] ?>"><?= h($e['codigo'] . ' · ' . $e['nome']) ?></option><?php endforeach; ?></select>
            <div class="input-group"><input class="form-control" name="motivo" placeholder="Motivo (ex.: NFC não lê)"><button class="btn btn-outline-dark">Substituir</button></div>
          </form>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <div class="col-lg-7">
    <?php if ($p['status'] === 'vendida'): ?>
      <div class="card mb-4 border-primary">
        <div class="card-header bg-roxo">Registrar instalação e marco zero</div>
        <div class="card-body">
          <p class="text-secondary small">Anote a nota e o total de avaliações do cliente no Google no dia da instalação. Esse é o ponto de partida dos relatórios.</p>
          <form method="post" class="row g-3">
            <?= csrf_field() ?><input type="hidden" name="acao" value="instalar"><input type="hidden" name="id" value="<?= $id ?>">
            <div class="col-sm-4"><label class="form-label">Data</label><input type="date" class="form-control" name="data_instalacao" value="<?= today() ?>" required></div>
            <div class="col-6 col-sm-4"><label class="form-label">Nota no Google</label><input class="form-control" name="marco_nota" placeholder="4,9" inputmode="decimal" required></div>
            <div class="col-6 col-sm-4"><label class="form-label">Total de avaliações</label><input type="number" min="0" class="form-control" name="marco_avaliacoes" placeholder="126" required></div>
            <div class="col-12"><label class="form-label">Local da placa</label><input class="form-control" name="local_instalacao" placeholder="Ex.: balcão do caixa"></div>
            <div class="col-12"><button class="btn btn-primary">Registrar instalação</button></div>
          </form>
        </div>
      </div>
    <?php endif; ?>

    <?php if ($p['data_instalacao']): ?>
      <?php $ult = $checagens ? end($checagens) : null; ?>
      <div class="row g-3 mb-4">
        <div class="col-6 col-md-4"><div class="card kpi kpi-dark h-100"><div class="kpi-label">Marco zero</div><div class="kpi-value"><?= nota_fmt($p['marco_nota']) ?> <span class="fs-6 fw-normal">· <?= (int)$p['marco_avaliacoes'] ?> aval.</span></div><div class="kpi-sub"><?= date_br($p['data_instalacao']) ?></div></div></div>
        <div class="col-6 col-md-4"><div class="card kpi h-100"><div class="kpi-label">Última checagem</div>
          <?php if ($ult): ?><div class="kpi-value"><?= nota_fmt($ult['nota']) ?> <span class="fs-6 fw-normal">· <?= (int)$ult['avaliacoes'] ?> aval.</span></div><div class="kpi-sub"><?= date_br($ult['data_checagem']) ?></div>
          <?php else: ?><div class="kpi-value">-</div><div class="kpi-sub">nenhuma ainda</div><?php endif; ?></div></div>
        <div class="col-12 col-md-4"><div class="card kpi kpi-roxo h-100"><div class="kpi-label">Evolução</div>
          <?php if ($ult): ?><div class="kpi-value"><?= h(delta((int)$ult['avaliacoes'] - (int)$p['marco_avaliacoes'])) ?> aval.</div><div class="kpi-sub"><?php $dn = (float)$ult['nota'] - (float)$p['marco_nota']; ?><?= abs($dn) < 0.05 ? 'nota mantida' : 'nota ' . h(delta($dn, 1)) ?> em <?= days_between($p['data_instalacao'], $ult['data_checagem']) ?> dias</div>
          <?php else: ?><div class="kpi-value">-</div><div class="kpi-sub">registre uma checagem</div><?php endif; ?></div></div>
      </div>

      <div class="card mb-4" id="checagem">
        <div class="card-header d-flex justify-content-between align-items-center">
          <span>Checagens de acompanhamento</span>
          <span class="small text-secondary fw-normal">7 dias: <?= date_br(date('Y-m-d', strtotime($p['data_instalacao'] . ' +7 days'))) ?> · 30 dias: <?= date_br(date('Y-m-d', strtotime($p['data_instalacao'] . ' +30 days'))) ?></span>
        </div>
        <?php if ($checagens): ?>
        <div class="table-responsive">
          <table class="table align-middle mb-0">
            <thead><tr><th>Data</th><th class="text-end">Dias</th><th class="text-end">Nota</th><th class="text-end">Avaliações</th><th class="text-end">Novas</th><th class="text-end">Scans</th><th>Obs.</th><th></th></tr></thead>
            <tbody>
              <tr class="table-light"><td><?= date_br($p['data_instalacao']) ?></td><td class="text-end">0</td><td class="text-end"><?= nota_fmt($p['marco_nota']) ?></td><td class="text-end"><?= (int)$p['marco_avaliacoes'] ?></td><td class="text-end">-</td><td class="text-end">-</td><td class="small text-secondary">Marco zero</td><td></td></tr>
            <?php foreach ($checagens as $k): ?>
              <tr>
                <td><?= date_br($k['data_checagem']) ?></td>
                <td class="text-end"><?= days_between($p['data_instalacao'], $k['data_checagem']) ?></td>
                <td class="text-end"><?= nota_fmt($k['nota']) ?> <small><?= delta_html((float)$k['nota'] - (float)$p['marco_nota'], 1, true) ?></small></td>
                <td class="text-end"><?= (int)$k['avaliacoes'] ?></td>
                <td class="text-end"><?= delta_html((int)$k['avaliacoes'] - (int)$p['marco_avaliacoes']) ?></td>
                <td class="text-end"><?= $k['scans'] !== null ? (int)$k['scans'] : '-' ?></td>
                <td class="small"><?= h($k['observacoes']) ?></td>
                <td class="text-end">
                  <form method="post" data-confirm="Excluir esta checagem?"><?= csrf_field() ?><input type="hidden" name="acao" value="excluir_checagem"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="checagem_id" value="<?= $k['id'] ?>">
                    <button class="btn btn-sm btn-link text-danger p-0" title="Excluir"><i class="bi bi-x-circle"></i></button></form>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php endif; ?>
        <div class="card-body border-top">
          <form method="post" class="row g-2 align-items-end">
            <?= csrf_field() ?><input type="hidden" name="acao" value="checagem"><input type="hidden" name="id" value="<?= $id ?>">
            <div class="col-6 col-md-3"><label class="form-label small">Data</label><input type="date" class="form-control" name="data_checagem" value="<?= today() ?>" required></div>
            <div class="col-6 col-md-2"><label class="form-label small">Nota</label><input class="form-control" name="nota" value="<?= h(nota_fmt($ult['nota'] ?? $p['marco_nota'])) ?>" inputmode="decimal" required></div>
            <div class="col-6 col-md-2"><label class="form-label small">Avaliações</label><input type="number" min="0" class="form-control" name="avaliacoes" value="<?= (int)($ult['avaliacoes'] ?? $p['marco_avaliacoes']) ?>" required></div>
            <div class="col-6 col-md-2"><label class="form-label small">Scans</label><input type="number" min="0" class="form-control" name="scans" placeholder="opcional"></div>
            <div class="col-12 col-md-3"><label class="form-label small">Observação</label><input class="form-control" name="observacoes" placeholder="opcional"></div>
            <div class="col-12"><button class="btn btn-primary">Registrar checagem</button></div>
          </form>
        </div>
      </div>

      <div class="card mb-4">
        <div class="card-header"><a class="text-reset text-decoration-none" data-bs-toggle="collapse" href="#corrigirMarco">Corrigir marco zero <i class="bi bi-chevron-down small"></i></a></div>
        <div class="collapse" id="corrigirMarco"><div class="card-body">
          <form method="post" class="row g-2 align-items-end">
            <?= csrf_field() ?><input type="hidden" name="acao" value="editar_marco"><input type="hidden" name="id" value="<?= $id ?>">
            <div class="col-6 col-md-3"><label class="form-label small">Data</label><input type="date" class="form-control" name="data_instalacao" value="<?= h($p['data_instalacao']) ?>" required></div>
            <div class="col-6 col-md-2"><label class="form-label small">Nota</label><input class="form-control" name="marco_nota" value="<?= h(nota_fmt($p['marco_nota'])) ?>" required></div>
            <div class="col-6 col-md-2"><label class="form-label small">Avaliações</label><input type="number" min="0" class="form-control" name="marco_avaliacoes" value="<?= (int)$p['marco_avaliacoes'] ?>" required></div>
            <div class="col-6 col-md-3"><label class="form-label small">Local</label><input class="form-control" name="local_instalacao" value="<?= h($p['local_instalacao']) ?>"></div>
            <div class="col-md-2"><button class="btn btn-outline-primary w-100">Salvar</button></div>
          </form>
        </div></div>
      </div>
    <?php elseif ($p['status'] === 'estoque'): ?>
      <div class="card"><div class="empty"><i class="bi bi-box-seam fs-2 d-block mb-2"></i>Placa em estoque. Quando vender, ela aparece aqui com cliente, instalação e acompanhamento.</div></div>
    <?php endif; ?>
  </div>
</div>
<?php layout_footer();
