<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require_login();

$loteId = get_int('lote');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && post('acao') === 'ids_placason') {
    $ids = $_POST['placason'] ?? [];
    if (is_array($ids)) {
        $st = db()->prepare('UPDATE placas SET placason_id = ? WHERE id = ?');
        foreach ($ids as $pid => $val) {
            $st->execute([mb_substr(trim((string)$val), 0, 80), (int)$pid]);
        }
    }
    flash('success', 'IDs da PlacasOn atualizados.');
    redirect('placas.php?lote=' . post_int('lote'));
}

$status = get('status');
$modeloId = get_int('modelo');
$busca = get('q');
$editarIds = $loteId > 0 && get('editar_ids') === '1';

$where = [];
$params = [];
if (in_array($status, ['estoque', 'vendida', 'instalada', 'desativada'], true)) {
    $where[] = 'p.status = ?';
    $params[] = $status;
}
if ($modeloId) {
    $where[] = 'p.modelo_id = ?';
    $params[] = $modeloId;
}
if ($loteId) {
    $where[] = 'p.lote_id = ?';
    $params[] = $loteId;
}
if ($busca !== '') {
    $where[] = '(p.codigo LIKE ? OR p.placason_id LIKE ? OR c.nome LIKE ?)';
    array_push($params, "%$busca%", "%$busca%", "%$busca%");
}
$sql = 'SELECT p.*, m.nome AS modelo, c.nome AS cliente, v.tipo AS venda_tipo
    FROM placas p JOIN modelos m ON m.id = p.modelo_id
    LEFT JOIN clientes c ON c.id = p.cliente_id LEFT JOIN vendas v ON v.id = p.venda_id'
    . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
    . ' ORDER BY p.codigo LIMIT 1000';
$placas = q_all($sql, $params);
$modelos = q_all('SELECT id, nome FROM modelos ORDER BY ordem, nome');

$contagem = ['' => 0, 'estoque' => 0, 'vendida' => 0, 'instalada' => 0, 'desativada' => 0];
foreach (q_all('SELECT status, COUNT(*) n FROM placas GROUP BY status') as $r) {
    $contagem[$r['status']] = (int)$r['n'];
    $contagem[''] += (int)$r['n'];
}

layout_header('Placas', 'placas');
page_title('Placas', $loteId ? 'Placas do lote #' . $loteId . ' · <a href="placas.php">ver todas</a>' : 'Todas as placas, com status e cliente vinculado.',
    '<a class="btn btn-outline-primary" href="lotes.php?novo=1"><i class="bi bi-box-seam me-1"></i>Registrar lote</a><a class="btn btn-primary" href="venda_nova.php"><i class="bi bi-cart-plus me-1"></i>Nova venda</a>');
?>
<ul class="nav nav-pills mb-3 flex-nowrap overflow-auto">
  <?php foreach (['' => 'Todas', 'estoque' => 'Em estoque', 'vendida' => 'Vendidas', 'instalada' => 'Instaladas', 'desativada' => 'Desativadas'] as $k => $label):
      $qs = http_build_query(array_filter(['status' => $k, 'modelo' => $modeloId ?: null, 'lote' => $loteId ?: null, 'q' => $busca ?: null])); ?>
    <li class="nav-item"><a class="nav-link text-nowrap<?= $status === $k ? ' active bg-roxo' : '' ?>" href="placas.php<?= $qs ? '?' . $qs : '' ?>"><?= $label ?> <span class="badge text-bg-light ms-1"><?= $contagem[$k] ?></span></a></li>
  <?php endforeach; ?>
</ul>

<form class="row g-2 mb-3" method="get">
  <?php if ($status): ?><input type="hidden" name="status" value="<?= h($status) ?>"><?php endif; ?>
  <?php if ($loteId): ?><input type="hidden" name="lote" value="<?= $loteId ?>"><?php endif; ?>
  <div class="col-sm-5 col-md-4"><input class="form-control" name="q" value="<?= h($busca) ?>" placeholder="Código, ID PlacasOn ou cliente"></div>
  <div class="col-sm-4 col-md-3"><select class="form-select" name="modelo"><option value="">Todos os modelos</option><?php foreach ($modelos as $m): ?><option value="<?= $m['id'] ?>"<?= $modeloId === (int)$m['id'] ? ' selected' : '' ?>><?= h($m['nome']) ?></option><?php endforeach; ?></select></div>
  <div class="col-sm-3 col-md-2"><button class="btn btn-dark w-100">Filtrar</button></div>
  <?php if ($loteId && !$editarIds): ?>
    <div class="col-md-3 text-md-end"><a class="btn btn-outline-secondary w-100" href="placas.php?lote=<?= $loteId ?>&editar_ids=1"><i class="bi bi-pencil me-1"></i>Editar IDs PlacasOn</a></div>
  <?php endif; ?>
</form>

<?php if ($editarIds): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="acao" value="ids_placason"><input type="hidden" name="lote" value="<?= $loteId ?>"><?php endif; ?>
<div class="card">
  <?php if (!$placas): ?>
    <div class="empty">Nenhuma placa encontrada com esses filtros.</div>
  <?php else: ?>
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead><tr><th>Código</th><th>Modelo</th><th>Status</th><th>Cliente</th><th>Oferta</th><th>Instalação</th><th>Marco zero</th><th>ID PlacasOn</th></tr></thead>
      <tbody>
      <?php foreach ($placas as $p): ?>
        <tr>
          <td><a class="code-pill" href="placa.php?id=<?= $p['id'] ?>"><?= h($p['codigo']) ?></a></td>
          <td class="small"><?= h($p['modelo']) ?></td>
          <td><?= status_placa_badge($p['status']) ?></td>
          <td><?= $p['cliente_id'] ? '<a href="cliente.php?id=' . $p['cliente_id'] . '">' . h($p['cliente']) . '</a>' : '<span class="text-secondary">-</span>' ?></td>
          <td class="small"><?= $p['venda_tipo'] ? h(tipo_venda_label($p['venda_tipo'])) : '-' ?></td>
          <td class="small"><?= date_br($p['data_instalacao']) ?></td>
          <td class="small"><?= $p['marco_nota'] !== null ? nota_fmt($p['marco_nota']) . ' · ' . (int)$p['marco_avaliacoes'] . ' aval.' : '-' ?></td>
          <td class="small">
            <?php if ($editarIds): ?>
              <input class="form-control form-control-sm font-monospace" name="placason[<?= $p['id'] ?>]" value="<?= h($p['placason_id']) ?>" style="min-width:140px">
            <?php else: ?>
              <?= $p['placason_id'] !== '' ? '<span class="font-monospace">' . h($p['placason_id']) . '</span>' : '<span class="text-secondary">-</span>' ?>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php if ($editarIds): ?>
  <div class="mt-3 d-flex gap-2"><button class="btn btn-primary">Salvar IDs</button><a class="btn btn-outline-secondary" href="placas.php?lote=<?= $loteId ?>">Cancelar</a></div>
</form>
<?php endif; ?>
<?php layout_footer();
