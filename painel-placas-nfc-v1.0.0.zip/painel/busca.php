<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require_login();

$q = get('q');
$placas = $clientes = [];
if ($q !== '') {
    // Aceita "12", "0012" ou "PNF-0012"
    $codigoExato = preg_match('/^(?:pnf-?)?(\d{1,6})$/i', $q, $mm) ? formatar_codigo((int)$mm[1]) : null;
    $placas = q_all('SELECT p.id, p.codigo, p.status, p.placason_id, m.nome AS modelo, c.nome AS cliente
        FROM placas p JOIN modelos m ON m.id = p.modelo_id LEFT JOIN clientes c ON c.id = p.cliente_id
        WHERE p.codigo = ? OR p.codigo LIKE ? OR p.placason_id LIKE ? OR c.nome LIKE ? ORDER BY p.codigo LIMIT 50',
        [$codigoExato ?? '', "%$q%", "%$q%", "%$q%"]);
    $clientes = q_all('SELECT id, nome, nicho, bairro FROM clientes WHERE nome LIKE ? OR whatsapp LIKE ? OR bairro LIKE ? ORDER BY nome LIMIT 50', ["%$q%", "%$q%", "%$q%"]);

    // Um único resultado leva direto para a ficha.
    if (count($placas) === 1 && !$clientes) {
        redirect('placa.php?id=' . $placas[0]['id']);
    }
    if (count($clientes) === 1 && !$placas) {
        redirect('cliente.php?id=' . $clientes[0]['id']);
    }
}

layout_header('Busca', '');
page_title('Busca', $q !== '' ? 'Resultados para "' . h($q) . '"' : 'Digite o código da placa ou o nome do cliente.');
?>
<form class="row g-2 mb-4" method="get">
  <div class="col-sm-8 col-md-6"><input class="form-control" name="q" value="<?= h($q) ?>" placeholder="PNF-0012, ID PlacasOn ou nome do comércio" autofocus></div>
  <div class="col-sm-4 col-md-2"><button class="btn btn-dark w-100">Buscar</button></div>
</form>
<?php if ($q !== ''): ?>
<div class="row g-4">
  <div class="col-lg-6"><div class="card"><div class="card-header">Placas (<?= count($placas) ?>)</div>
    <?php if (!$placas): ?><div class="empty">Nenhuma placa.</div><?php else: ?>
    <ul class="list-group list-group-flush"><?php foreach ($placas as $p): ?>
      <a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" href="placa.php?id=<?= $p['id'] ?>">
        <span><span class="code-pill"><?= h($p['codigo']) ?></span> <span class="small text-secondary"><?= h($p['modelo']) ?><?= $p['cliente'] ? ' · ' . h($p['cliente']) : '' ?></span></span><?= status_placa_badge($p['status']) ?></a>
    <?php endforeach; ?></ul><?php endif; ?>
  </div></div>
  <div class="col-lg-6"><div class="card"><div class="card-header">Clientes (<?= count($clientes) ?>)</div>
    <?php if (!$clientes): ?><div class="empty">Nenhum cliente.</div><?php else: ?>
    <ul class="list-group list-group-flush"><?php foreach ($clientes as $c): ?>
      <a class="list-group-item list-group-item-action" href="cliente.php?id=<?= $c['id'] ?>"><span class="fw-semibold"><?= h($c['nome']) ?></span> <span class="small text-secondary"><?= h(implode(' · ', array_filter([$c['nicho'], $c['bairro']]))) ?></span></a>
    <?php endforeach; ?></ul><?php endif; ?>
  </div></div>
</div>
<?php endif;
layout_footer();
