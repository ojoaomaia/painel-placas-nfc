<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require_login();

$mes = get('mes', date('Y-m'));
if ($mes !== 'todos' && !preg_match('/^\d{4}-\d{2}$/', $mes)) {
    $mes = date('Y-m');
}
$tipo = get('tipo');

$where = [];
$params = [];
if ($mes !== 'todos') {
    $where[] = 'v.data_venda BETWEEN ? AND ?';
    $params[] = $mes . '-01';
    $params[] = date('Y-m-t', strtotime($mes . '-01'));
}
if (in_array($tipo, ['avulsa', 'combo', 'kit2', 'upgrade_combo'], true)) {
    $where[] = 'v.tipo = ?';
    $params[] = $tipo;
}
$vendas = q_all('SELECT v.*, c.nome AS cliente,
        (SELECT GROUP_CONCAT(p.codigo ORDER BY p.codigo SEPARATOR \', \') FROM placas p WHERE p.venda_id = COALESCE(v.venda_origem_id, v.id) AND p.status <> \'desativada\') AS codigos
    FROM vendas v JOIN clientes c ON c.id = v.cliente_id'
    . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY v.data_venda DESC, v.id DESC', $params);
$total = array_sum(array_column($vendas, 'valor'));

$meses = ['todos' => 'Todos os meses'];
for ($i = 0; $i < 18; $i++) {
    $m = date('Y-m', strtotime(date('Y-m-01') . " -{$i} month"));
    $meses[$m] = ucfirst(mes_nome($m));
}

layout_header('Vendas', 'vendas');
page_title('Vendas', count($vendas) . ' venda(s) · ' . money($total), '<a class="btn btn-primary" href="venda_nova.php"><i class="bi bi-cart-plus me-1"></i>Nova venda</a>');
?>
<form class="row g-2 mb-3" method="get">
  <div class="col-6 col-md-3"><select class="form-select" name="mes"><?= options($meses, $mes) ?></select></div>
  <div class="col-6 col-md-3"><select class="form-select" name="tipo"><option value="">Todos os tipos</option><?= options(['combo' => 'Google Completo', 'avulsa' => 'Avulsa', 'kit2' => 'Kit 2 Plaquinhas', 'upgrade_combo' => 'Upgrade para combo'], $tipo) ?></select></div>
  <div class="col-md-2"><button class="btn btn-dark w-100">Filtrar</button></div>
</form>
<div class="card">
  <?php if (!$vendas): ?><div class="empty">Nenhuma venda nesse período.</div><?php else: ?>
  <div class="table-responsive"><table class="table table-hover align-middle mb-0">
    <thead><tr><th>#</th><th>Data</th><th>Cliente</th><th>Tipo</th><th>Placas</th><th>Pagamento</th><th class="text-end">Valor</th></tr></thead>
    <tbody><?php foreach ($vendas as $v): ?>
      <tr>
        <td><a href="venda.php?id=<?= $v['id'] ?>">#<?= $v['id'] ?></a></td>
        <td><?= date_br($v['data_venda']) ?></td>
        <td><a href="cliente.php?id=<?= $v['cliente_id'] ?>"><?= h($v['cliente']) ?></a></td>
        <td><?= h(tipo_venda_label($v['tipo'])) ?><?php if (in_array($v['tipo'], ['combo', 'upgrade_combo'], true) && (!$v['fotos_tiradas'] || !$v['perfil_otimizado'])): ?> <span class="badge text-bg-warning">etapas pendentes</span><?php endif; ?></td>
        <td class="small code-pill"><?= h($v['codigos'] ?? '-') ?></td>
        <td class="small"><?= h(pagamento_label($v['forma_pagamento'])) ?></td>
        <td class="text-end fw-semibold"><?= money($v['valor']) ?></td>
      </tr>
    <?php endforeach; ?></tbody>
    <tfoot><tr><th colspan="6" class="text-end">Total</th><th class="text-end"><?= money($total) ?></th></tr></tfoot>
  </table></div>
  <?php endif; ?>
</div>
<?php layout_footer();
