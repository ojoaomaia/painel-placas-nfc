<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require_login();

$id = get_int('id') ?: post_int('id');
$v = q_one('SELECT v.*, c.nome AS cliente FROM vendas v JOIN clientes c ON c.id = v.cliente_id WHERE v.id = ?', [$id]);
if (!$v) {
    not_found('Venda não encontrada.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = post('acao');
    $volta = 'venda.php?id=' . $id;
    try {
        switch ($acao) {
            case 'etapas':
                q('UPDATE vendas SET fotos_tiradas = ?, perfil_otimizado = ? WHERE id = ?', [post('fotos_tiradas') === '1' ? 1 : 0, post('perfil_otimizado') === '1' ? 1 : 0, $id]);
                flash('success', 'Etapas do combo atualizadas.');
                break;
            case 'editar':
                $data = valid_date(post('data_venda'));
                $valor = parse_money(post('valor'));
                if (!$data || $valor <= 0 || !array_key_exists(post('forma_pagamento'), FORMAS_PAGAMENTO)) {
                    throw new DomainException('Confira valor, forma de pagamento e data.');
                }
                q('UPDATE vendas SET valor = ?, forma_pagamento = ?, data_venda = ?, observacoes = ? WHERE id = ?', [$valor, post('forma_pagamento'), $data, post('observacoes'), $id]);
                if ($v['tipo'] !== 'upgrade_combo') {
                    q('UPDATE placas SET data_venda = ? WHERE venda_id = ?', [$data, $id]);
                }
                flash('success', 'Venda atualizada.');
                break;
            case 'upgrade':
                $novo = registrar_upgrade_combo($id, parse_money(post('valor')), post('forma_pagamento'), post('data_venda'), post('observacoes'));
                flash('success', 'Upgrade para Google Completo registrado. A venda original continua no histórico.');
                $volta = 'venda.php?id=' . $novo;
                break;
            case 'cancelar':
                cancelar_venda($id);
                flash('success', 'Venda cancelada. As placas voltaram para o estoque.');
                $volta = 'cliente.php?id=' . $v['cliente_id'];
                break;
        }
    } catch (DomainException $e) {
        flash('danger', $e->getMessage());
    }
    redirect($volta);
}

$baseId = $v['tipo'] === 'upgrade_combo' ? (int)$v['venda_origem_id'] : $id;
$placas = q_all('SELECT p.*, m.nome AS modelo FROM placas p JOIN modelos m ON m.id = p.modelo_id WHERE p.venda_id = ? ORDER BY p.codigo', [$baseId]);
$upgrade = q_one("SELECT * FROM vendas WHERE venda_origem_id = ? AND tipo = 'upgrade_combo'", [$id]);
$origem = $v['venda_origem_id'] ? q_one('SELECT * FROM vendas WHERE id = ?', [$v['venda_origem_id']]) : null;
$ehCombo = in_array($v['tipo'], ['combo', 'upgrade_combo'], true);
$podeUpgrade = in_array($v['tipo'], ['avulsa', 'kit2'], true) && !$upgrade;

layout_header('Venda #' . $id, 'vendas');
page_title(tipo_venda_label($v['tipo']) . ' · ' . money($v['valor']),
    'Venda #' . $id . ' para <a href="cliente.php?id=' . $v['cliente_id'] . '">' . h($v['cliente']) . '</a> em ' . date_br($v['data_venda']));
?>
<div class="row g-4">
  <div class="col-lg-7">
    <?php if ($ehCombo): ?>
    <div class="card mb-4 border-primary">
      <div class="card-header bg-roxo">Etapas do Google Completo</div>
      <div class="card-body">
        <form method="post" class="d-flex flex-wrap gap-4 align-items-center">
          <?= csrf_field() ?><input type="hidden" name="acao" value="etapas"><input type="hidden" name="id" value="<?= $id ?>">
          <div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" id="ft" name="fotos_tiradas" value="1"<?= $v['fotos_tiradas'] ? ' checked' : '' ?>><label class="form-check-label" for="ft">Fotos tiradas no local</label></div>
          <div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" id="po" name="perfil_otimizado" value="1"<?= $v['perfil_otimizado'] ? ' checked' : '' ?>><label class="form-check-label" for="po">Perfil do Google otimizado</label></div>
          <button class="btn btn-sm btn-primary">Salvar etapas</button>
        </form>
        <div class="form-text mt-2">Enquanto alguma etapa estiver pendente, ela aparece na lista de ações do painel.</div>
      </div>
    </div>
    <?php endif; ?>

    <div class="card mb-4">
      <div class="card-header">Placas desta venda</div>
      <?php if (!$placas): ?><div class="empty">Sem placas vinculadas.</div><?php else: ?>
      <div class="table-responsive"><table class="table align-middle mb-0">
        <thead><tr><th>Código</th><th>Modelo</th><th>Status</th><th>Instalação</th><th>Marco zero</th></tr></thead>
        <tbody><?php foreach ($placas as $p): ?>
          <tr>
            <td><a class="code-pill" href="placa.php?id=<?= $p['id'] ?>"><?= h($p['codigo']) ?></a></td>
            <td class="small"><?= h($p['modelo']) ?></td>
            <td><?= status_placa_badge($p['status']) ?></td>
            <td><?= $p['status'] === 'vendida' ? '<a class="btn btn-sm btn-primary" href="placa.php?id=' . $p['id'] . '">Registrar instalação</a>' : date_br($p['data_instalacao']) ?></td>
            <td class="small"><?= $p['marco_nota'] !== null ? nota_fmt($p['marco_nota']) . ' · ' . (int)$p['marco_avaliacoes'] . ' aval.' : '-' ?></td>
          </tr>
        <?php endforeach; ?></tbody>
      </table></div>
      <?php endif; ?>
    </div>

    <div class="card mb-4">
      <div class="card-header">Histórico</div>
      <ul class="list-group list-group-flush">
        <?php if ($origem): ?><li class="list-group-item">Upgrade da venda <a href="venda.php?id=<?= $origem['id'] ?>">#<?= $origem['id'] ?></a> (<?= h(tipo_venda_label($origem['tipo'])) ?>, <?= money($origem['valor']) ?>, <?= date_br($origem['data_venda']) ?>)</li><?php endif; ?>
        <li class="list-group-item"><?= date_br($v['data_venda']) ?> · <?= h(tipo_venda_label($v['tipo'])) ?> · <?= money($v['valor']) ?> no <?= h(pagamento_label($v['forma_pagamento'])) ?></li>
        <?php if ($upgrade): ?><li class="list-group-item"><?= date_br($upgrade['data_venda']) ?> · Upgrade para Google Completo · <?= money($upgrade['valor']) ?> · <a href="venda.php?id=<?= $upgrade['id'] ?>">ver #<?= $upgrade['id'] ?></a></li><?php endif; ?>
        <?php if ($v['observacoes']): ?><li class="list-group-item small text-secondary"><?= nl2br(h($v['observacoes'])) ?></li><?php endif; ?>
      </ul>
    </div>
  </div>

  <div class="col-lg-5">
    <?php if ($podeUpgrade): $precos = precos_padrao(); ?>
    <div class="card mb-4">
      <div class="card-header">Upgrade para Google Completo</div>
      <div class="card-body">
        <p class="small text-secondary">O cliente já pagou <?= money($v['valor']) ?>. Para completar o combo de <?= money($precos['combo']) ?>, a diferença padrão é <?= money($precos['upgrade_combo']) ?>.</p>
        <form method="post" class="row g-2">
          <?= csrf_field() ?><input type="hidden" name="acao" value="upgrade"><input type="hidden" name="id" value="<?= $id ?>">
          <div class="col-6"><label class="form-label small">Valor</label><input class="form-control" name="valor" value="<?= number_format($precos['upgrade_combo'], 2, ',', '') ?>" inputmode="decimal" required></div>
          <div class="col-6"><label class="form-label small">Pagamento</label><select class="form-select" name="forma_pagamento"><?= options(FORMAS_PAGAMENTO, 'pix') ?></select></div>
          <div class="col-12"><label class="form-label small">Data</label><input type="date" class="form-control" name="data_venda" value="<?= today() ?>" required></div>
          <div class="col-12"><input class="form-control" name="observacoes" placeholder="Observação (opcional)"></div>
          <div class="col-12"><button class="btn btn-primary w-100">Registrar upgrade</button></div>
        </form>
      </div>
    </div>
    <?php endif; ?>
    <div class="card mb-4"><div class="card-body d-flex justify-content-between align-items-center">
      <span class="small">Assinatura mensal do cliente</span>
      <a class="btn btn-sm btn-outline-primary" href="cliente.php?id=<?= $v['cliente_id'] ?>#assinatura">Ver ou iniciar</a>
    </div></div>

    <div class="card mb-4">
      <div class="card-header"><a class="text-reset text-decoration-none" data-bs-toggle="collapse" href="#editarVenda">Editar venda <i class="bi bi-chevron-down small"></i></a></div>
      <div class="collapse" id="editarVenda"><div class="card-body">
        <form method="post" class="row g-2">
          <?= csrf_field() ?><input type="hidden" name="acao" value="editar"><input type="hidden" name="id" value="<?= $id ?>">
          <div class="col-6"><label class="form-label small">Valor</label><input class="form-control" name="valor" value="<?= number_format((float)$v['valor'], 2, ',', '') ?>" required></div>
          <div class="col-6"><label class="form-label small">Pagamento</label><select class="form-select" name="forma_pagamento"><?= options(FORMAS_PAGAMENTO, $v['forma_pagamento']) ?></select></div>
          <div class="col-12"><label class="form-label small">Data</label><input type="date" class="form-control" name="data_venda" value="<?= h($v['data_venda']) ?>" required></div>
          <div class="col-12"><textarea class="form-control" name="observacoes" rows="2"><?= h($v['observacoes']) ?></textarea></div>
          <div class="col-12"><button class="btn btn-outline-primary w-100">Salvar alterações</button></div>
        </form>
        <hr>
        <form method="post" data-confirm="Cancelar esta venda? As placas voltam para o estoque.">
          <?= csrf_field() ?><input type="hidden" name="acao" value="cancelar"><input type="hidden" name="id" value="<?= $id ?>">
          <button class="btn btn-outline-danger w-100"><i class="bi bi-x-circle me-1"></i>Cancelar venda (lançada por engano)</button>
        </form>
      </div></div>
    </div>
  </div>
</div>
<?php layout_footer();
