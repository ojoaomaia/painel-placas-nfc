<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require_login();

$m = metricas_painel();
$pend = pendencias();
$alertas = alertas_estoque();
$ultimas = q_all('SELECT v.id, v.tipo, v.valor, v.data_venda, c.nome FROM vendas v JOIN clientes c ON c.id = v.cliente_id ORDER BY v.data_venda DESC, v.id DESC LIMIT 6');
$mesLabel = mes_nome(date('Y-m'));
$s = $m['status'];

layout_header('Painel', 'painel');
page_title('Painel', 'Resumo de ' . h($mesLabel),
    '<a class="btn btn-outline-primary" href="lotes.php?novo=1"><i class="bi bi-box-seam me-1"></i>Registrar lote</a><a class="btn btn-primary" href="venda_nova.php"><i class="bi bi-cart-plus me-1"></i>Nova venda</a>');
?>
<form class="d-lg-none mb-3" action="busca.php" method="get" role="search">
  <input class="form-control" type="search" name="q" placeholder="Buscar código da placa ou cliente">
</form>

<div class="row g-3 mb-4">
  <div class="col-6 col-xl-3"><a class="text-decoration-none" href="placas.php?status=estoque"><div class="card kpi h-100"><div class="kpi-label">Em estoque</div><div class="kpi-value"><?= $s['estoque'] ?></div><div class="kpi-sub">placas disponíveis</div></div></a></div>
  <div class="col-6 col-xl-3"><a class="text-decoration-none" href="placas.php?status=vendida"><div class="card kpi h-100"><div class="kpi-label">Vendidas</div><div class="kpi-value"><?= $s['vendida'] ?></div><div class="kpi-sub">aguardando instalação</div></div></a></div>
  <div class="col-6 col-xl-3"><a class="text-decoration-none" href="placas.php?status=instalada"><div class="card kpi h-100"><div class="kpi-label">Instaladas</div><div class="kpi-value"><?= $s['instalada'] ?></div><div class="kpi-sub"><?= $s['desativada'] ? $s['desativada'] . ' desativada(s)' : 'em uso nos clientes' ?></div></div></a></div>
  <div class="col-6 col-xl-3"><a class="text-decoration-none" href="assinaturas.php"><div class="card kpi kpi-roxo h-100"><div class="kpi-label">MRR</div><div class="kpi-value"><?= money($m['mrr']) ?></div><div class="kpi-sub"><?= $m['assinaturas_ativas'] ?> assinatura(s) ativa(s)</div></div></a></div>
</div>

<div class="row g-4 mb-4">
  <div class="col-lg-5">
    <div class="card kpi kpi-dark mb-4">
      <div class="kpi-label">Faturamento de <?= h($mesLabel) ?></div>
      <div class="kpi-value"><?= money($m['faturamento_mes']) ?></div>
      <div class="kpi-sub mt-1">Vendas <?= money($m['vendas_mes']) ?> · Mensalidades <?= money($m['mensalidades_mes']) ?></div>
      <div class="kpi-sub">Custo das placas vendidas no mês <?= money($m['custo_placas_mes']) ?> · Margem bruta <?= money($m['faturamento_mes'] - $m['custo_placas_mes']) ?></div>
    </div>

    <div class="card">
      <div class="card-header">Vendas por tipo</div>
      <div class="table-responsive"><table class="table align-middle mb-0">
        <thead><tr><th>Oferta</th><th class="text-end">No mês</th><th class="text-end">Total</th></tr></thead>
        <tbody>
        <?php $precos = precos_padrao(); foreach (['combo', 'avulsa', 'kit2', 'upgrade_combo'] as $t): $r = $m['por_tipo'][$t]; ?>
          <tr>
            <td><a class="text-reset" href="vendas.php?mes=todos&tipo=<?= $t ?>"><?= h(tipo_venda_label($t)) ?></a><div class="small text-secondary"><?= $t !== 'upgrade_combo' ? money($precos[$t]) : 'avulsa para combo' ?></div></td>
            <td class="text-end text-nowrap"><span class="fw-semibold"><?= $r['qtd_mes'] ?></span><div class="small text-secondary"><?= money($r['valor_mes']) ?></div></td>
            <td class="text-end text-nowrap"><span class="fw-semibold"><?= $r['qtd_total'] ?></span><div class="small text-secondary"><?= money($r['valor_total']) ?></div></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    </div>
  </div>

  <div class="col-lg-7">
    <div class="card h-100">
      <div class="card-header d-flex justify-content-between align-items-center">
        <span>Ações pendentes</span>
        <span class="badge <?= $pend ? 'text-bg-danger' : 'text-bg-success' ?>"><?= count($pend) ?></span>
      </div>
      <?php if (!$pend && !$alertas): ?>
        <div class="empty"><i class="bi bi-check2-circle fs-2 d-block mb-2 text-success"></i>Nada pendente. Tudo em dia.</div>
      <?php else: ?>
        <div>
          <?php foreach ($alertas as $a): ?>
            <a class="pend-item text-reset text-decoration-none" href="lotes.php?novo=1">
              <span class="pend-icon danger"><i class="bi bi-exclamation-triangle"></i></span>
              <span><span class="fw-semibold d-block">Estoque baixo: <?= h($a['nome']) ?></span><span class="small text-secondary"><?= (int)$a['em_estoque'] ?> em estoque, mínimo <?= (int)$a['estoque_minimo'] ?></span></span>
            </a>
          <?php endforeach; ?>
          <?php foreach (array_slice($pend, 0, 15) as $p): ?>
            <a class="pend-item text-reset text-decoration-none" href="<?= h($p['link']) ?>">
              <span class="pend-icon<?= $p['urgente'] ? ' danger' : '' ?>"><i class="bi <?= h($p['icone']) ?>"></i></span>
              <span><span class="fw-semibold d-block"><?= h($p['titulo']) ?></span><span class="small text-secondary"><?= h($p['cliente']) ?> · <?= h($p['detalhe']) ?></span></span>
            </a>
          <?php endforeach; ?>
          <?php if (count($pend) > 15): ?><div class="p-3 small text-secondary">E mais <?= count($pend) - 15 ?> item(ns).</div><?php endif; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header d-flex justify-content-between"><span>Últimas vendas</span><a class="small fw-normal" href="vendas.php">ver todas</a></div>
  <?php if (!$ultimas): ?><div class="empty">Nenhuma venda registrada ainda.</div><?php else: ?>
  <div class="table-responsive"><table class="table table-hover align-middle mb-0">
    <tbody><?php foreach ($ultimas as $v): ?>
      <tr><td class="text-secondary small" style="width:110px"><?= date_br($v['data_venda']) ?></td><td><a href="venda.php?id=<?= $v['id'] ?>"><?= h($v['nome']) ?></a></td><td class="small"><?= h(tipo_venda_label($v['tipo'])) ?></td><td class="text-end fw-semibold"><?= money($v['valor']) ?></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <?php endif; ?>
</div>
<?php layout_footer();
