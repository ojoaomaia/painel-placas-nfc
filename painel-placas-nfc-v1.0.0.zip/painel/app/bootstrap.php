<?php
declare(strict_types=1);

/**
 * Inicialização comum a todas as páginas.
 * Uso: require __DIR__ . '/app/bootstrap.php'; e depois require_login();
 */

define('APP_DIR', __DIR__);
define('ROOT_DIR', dirname(__DIR__));
define('APP_VERSION', '1.0.0');

date_default_timezone_set('America/Sao_Paulo');
mb_internal_encoding('UTF-8');

$configFile = APP_DIR . '/config.php';
if (!is_file($configFile)) {
    header('Location: install/');
    exit;
}
$GLOBALS['config'] = require $configFile;

$debug = !empty($GLOBALS['config']['debug']);
error_reporting(E_ALL);
ini_set('display_errors', $debug ? '1' : '0');
ini_set('log_errors', '1');

require APP_DIR . '/helpers.php';
require APP_DIR . '/db.php';
require APP_DIR . '/auth.php';
require APP_DIR . '/layout.php';
require APP_DIR . '/domain.php';

security_headers();
force_https_if_needed();
start_secure_session();

// Toda requisição POST precisa de token CSRF válido.
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    verify_csrf();
}
