-- Painel de Gestão de Placas NFC
-- Schema MySQL / MariaDB (utf8mb4). Executado automaticamente pelo instalador.
-- Também pode ser importado manualmente pelo phpMyAdmin da Hostinger.

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario VARCHAR(60) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ultimo_login DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_tentativas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ip VARCHAR(45) NOT NULL,
  usuario VARCHAR(60) NOT NULL DEFAULT '',
  sucesso TINYINT(1) NOT NULL DEFAULT 0,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ip_data (ip, criado_em),
  INDEX idx_usuario_data (usuario, criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS configuracoes (
  chave VARCHAR(60) PRIMARY KEY,
  valor TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS modelos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(80) NOT NULL,
  tipo ENUM('google','instagram') NOT NULL,
  cor VARCHAR(30) NOT NULL,
  estoque_minimo INT UNSIGNED NOT NULL DEFAULT 3,
  foto VARCHAR(120) NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  ordem INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lotes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  data_compra DATE NOT NULL,
  modelo_id INT UNSIGNED NOT NULL,
  quantidade INT UNSIGNED NOT NULL,
  custo_unitario DECIMAL(10,2) NOT NULL,
  fornecedor VARCHAR(80) NOT NULL DEFAULT 'PlacasOn',
  observacoes TEXT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_lote_modelo FOREIGN KEY (modelo_id) REFERENCES modelos(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS clientes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  nicho VARCHAR(60) NOT NULL DEFAULT '',
  bairro VARCHAR(80) NOT NULL DEFAULT '',
  whatsapp VARCHAR(30) NOT NULL DEFAULT '',
  origem ENUM('porta_a_porta','maps','indicacao','outro') NOT NULL DEFAULT 'porta_a_porta',
  link_google VARCHAR(255) NOT NULL DEFAULT '',
  observacoes TEXT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_cliente_nome (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS vendas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT UNSIGNED NOT NULL,
  tipo ENUM('avulsa','combo','kit2','upgrade_combo') NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  forma_pagamento ENUM('pix','dinheiro','cartao','outro') NOT NULL DEFAULT 'pix',
  data_venda DATE NOT NULL,
  venda_origem_id INT UNSIGNED NULL,
  fotos_tiradas TINYINT(1) NOT NULL DEFAULT 0,
  perfil_otimizado TINYINT(1) NOT NULL DEFAULT 0,
  observacoes TEXT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_venda_data (data_venda),
  CONSTRAINT fk_venda_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id),
  CONSTRAINT fk_venda_origem FOREIGN KEY (venda_origem_id) REFERENCES vendas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS placas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(20) NOT NULL UNIQUE,
  lote_id INT UNSIGNED NOT NULL,
  modelo_id INT UNSIGNED NOT NULL,
  placason_id VARCHAR(80) NOT NULL DEFAULT '',
  status ENUM('estoque','vendida','instalada','desativada') NOT NULL DEFAULT 'estoque',
  cliente_id INT UNSIGNED NULL,
  venda_id INT UNSIGNED NULL,
  data_venda DATE NULL,
  data_instalacao DATE NULL,
  local_instalacao VARCHAR(120) NOT NULL DEFAULT '',
  marco_nota DECIMAL(2,1) NULL,
  marco_avaliacoes INT UNSIGNED NULL,
  observacoes TEXT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_placa_status (status),
  INDEX idx_placason (placason_id),
  CONSTRAINT fk_placa_lote FOREIGN KEY (lote_id) REFERENCES lotes(id),
  CONSTRAINT fk_placa_modelo FOREIGN KEY (modelo_id) REFERENCES modelos(id),
  CONSTRAINT fk_placa_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id),
  CONSTRAINT fk_placa_venda FOREIGN KEY (venda_id) REFERENCES vendas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS checagens (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  placa_id INT UNSIGNED NOT NULL,
  data_checagem DATE NOT NULL,
  nota DECIMAL(2,1) NOT NULL,
  avaliacoes INT UNSIGNED NOT NULL,
  scans INT UNSIGNED NULL,
  observacoes TEXT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_checagem_placa (placa_id, data_checagem),
  CONSTRAINT fk_checagem_placa FOREIGN KEY (placa_id) REFERENCES placas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS assinaturas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT UNSIGNED NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  status ENUM('ativa','inativa') NOT NULL DEFAULT 'ativa',
  data_inicio DATE NOT NULL,
  data_fim DATE NULL,
  proximo_relatorio DATE NOT NULL,
  observacoes TEXT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_assinatura_status (status),
  CONSTRAINT fk_assinatura_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS pagamentos_assinatura (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  assinatura_id INT UNSIGNED NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  data_pagamento DATE NOT NULL,
  forma_pagamento ENUM('pix','dinheiro','cartao','outro') NOT NULL DEFAULT 'pix',
  referencia VARCHAR(7) NOT NULL DEFAULT '',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_pag_data (data_pagamento),
  CONSTRAINT fk_pag_assinatura FOREIGN KEY (assinatura_id) REFERENCES assinaturas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS relatorios_enviados (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  assinatura_id INT UNSIGNED NOT NULL,
  referencia DATE NOT NULL,
  enviado_em DATE NOT NULL,
  observacoes TEXT NULL,
  CONSTRAINT fk_rel_assinatura FOREIGN KEY (assinatura_id) REFERENCES assinaturas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Modelos de placa (catálogo inicial)
INSERT INTO modelos (nome, tipo, cor, estoque_minimo, ordem) VALUES
 ('Google Avaliações Preto', 'google', 'preto', 3, 1),
 ('Google Avaliações Branco', 'google', 'branco', 3, 2),
 ('Google Avaliações Azul', 'google', 'azul', 2, 3),
 ('Instagram Preto', 'instagram', 'preto', 2, 4),
 ('Instagram Colorido', 'instagram', 'colorido', 2, 5);

-- Configurações padrão (editáveis em Configurações)
INSERT INTO configuracoes (chave, valor) VALUES
 ('preco_avulsa', '80.00'),
 ('preco_combo', '250.00'),
 ('preco_kit2', '140.00'),
 ('preco_upgrade_combo', '170.00'),
 ('mensalidade_padrao', '24.90'),
 ('placason_url', 'https://placason.com.br/cliente'),
 ('nome_comercial', 'João Maia | Google para Comércios'),
 ('whatsapp_contato', ''),
 ('instagram_contato', ''),
 ('cidade', 'Ribeirão Preto, SP');
