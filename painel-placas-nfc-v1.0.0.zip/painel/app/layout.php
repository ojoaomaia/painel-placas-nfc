<?php
declare(strict_types=1);

function layout_header(string $title, string $active = ''): void
{
    $nav = [
        'painel' => ['index.php', 'bi-speedometer2', 'Painel'],
        'placas' => ['placas.php', 'bi-tags', 'Placas'],
        'lotes' => ['lotes.php', 'bi-box-seam', 'Lotes'],
        'clientes' => ['clientes.php', 'bi-shop', 'Clientes'],
        'vendas' => ['vendas.php', 'bi-cash-coin', 'Vendas'],
        'assinaturas' => ['assinaturas.php', 'bi-arrow-repeat', 'Assinaturas'],
        'materiais' => ['materiais.php', 'bi-easel2', 'Materiais'],
    ];
    $q = h(get('q'));
    ?>
<!doctype html>
<html lang="pt-BR" data-bs-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= h($title) ?> · Placas NFC</title>
<link rel="icon" href="assets/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="assets/vendor/bootstrap/bootstrap.min.css">
<link rel="stylesheet" href="assets/vendor/bootstrap-icons/bootstrap-icons.min.css">
<link rel="stylesheet" href="assets/app.css?v=<?= APP_VERSION ?>">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark app-nav sticky-top">
  <div class="container-xl">
    <a class="navbar-brand d-flex align-items-center gap-2" href="index.php">
      <span class="brand-mark"><i class="bi bi-broadcast"></i></span>
      <span class="fw-semibold">Placas NFC</span>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Abrir menu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav me-auto">
        <?php foreach ($nav as $key => [$href, $icon, $label]): ?>
          <li class="nav-item">
            <a class="nav-link<?= $active === $key ? ' active' : '' ?>" href="<?= $href ?>"><i class="bi <?= $icon ?> me-1"></i><?= $label ?></a>
          </li>
        <?php endforeach; ?>
      </ul>
      <form class="d-flex my-2 my-lg-0 me-lg-2" role="search" action="busca.php" method="get">
        <input class="form-control form-control-sm search-input" type="search" name="q" value="<?= $q ?>" placeholder="Código da placa ou cliente" aria-label="Buscar">
      </form>
      <div class="d-flex gap-1">
        <a class="nav-link px-2<?= $active === 'config' ? ' active' : '' ?>" href="configuracoes.php" title="Configurações"><i class="bi bi-gear"></i><span class="d-lg-none ms-1">Configurações</span></a>
        <form action="logout.php" method="post" class="d-inline"><?= csrf_field() ?>
          <button class="btn btn-link nav-link px-2" type="submit" title="Sair"><i class="bi bi-box-arrow-right"></i><span class="d-lg-none ms-1">Sair</span></button>
        </form>
      </div>
    </div>
  </div>
</nav>
<main class="container-xl py-4">
<?php foreach (take_flashes() as $f): ?>
  <div class="alert alert-<?= h($f['type']) ?> alert-dismissible fade show" role="alert">
    <?= h($f['msg']) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
  </div>
<?php endforeach;
}

function layout_footer(): void
{
    ?>
</main>
<footer class="container-xl pb-4 text-secondary small">Painel de Placas NFC · v<?= APP_VERSION ?></footer>
<script src="assets/vendor/bootstrap/bootstrap.bundle.min.js"></script>
<script src="assets/app.js?v=<?= APP_VERSION ?>"></script>
</body>
</html>
<?php
}

function page_title(string $title, string $subtitle = '', string $actions = ''): void
{
    echo '<div class="d-flex flex-wrap align-items-end justify-content-between gap-2 mb-4">';
    echo '<div><h1 class="h3 mb-1">' . h($title) . '</h1>';
    if ($subtitle !== '') {
        echo '<div class="text-secondary">' . $subtitle . '</div>';
    }
    echo '</div>';
    if ($actions !== '') {
        echo '<div class="d-flex flex-wrap gap-2">' . $actions . '</div>';
    }
    echo '</div>';
}
