<?php
declare(strict_types=1);

const LOGIN_MAX_TENTATIVAS = 5;      // falhas permitidas na janela
const LOGIN_JANELA_MIN = 15;         // janela e tempo de bloqueio, em minutos

function is_https(): bool
{
    if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') {
        return true;
    }
    if (strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https') {
        return true;
    }
    return (int)($_SERVER['SERVER_PORT'] ?? 0) === 443;
}

function force_https_if_needed(): void
{
    if (!empty($GLOBALS['config']['force_https']) && !is_https() && PHP_SAPI !== 'cli') {
        $host = $_SERVER['HTTP_HOST'] ?? '';
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        header('Location: https://' . $host . $uri, true, 301);
        exit;
    }
}

function security_headers(): void
{
    if (headers_sent()) {
        return;
    }
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; font-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'self'");
    if (is_https()) {
        header('Strict-Transport-Security: max-age=31536000');
    }
}

function start_secure_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    session_name('PNF_SESSION');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_start();

    if (!empty($_SESSION['uid'])) {
        $idle = (int)($GLOBALS['config']['session_idle_min'] ?? 60) * 60;
        $max = (int)($GLOBALS['config']['session_max_horas'] ?? 12) * 3600;
        $now = time();
        $expirada = ($now - (int)($_SESSION['last_seen'] ?? 0) > $idle)
            || ($now - (int)($_SESSION['login_at'] ?? 0) > $max);
        if ($expirada) {
            $_SESSION = [];
            session_regenerate_id(true);
            $_SESSION['flash'][] = ['type' => 'warning', 'msg' => 'Sua sessão expirou. Entre novamente.'];
        } else {
            $_SESSION['last_seen'] = $now;
        }
    }
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . h(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $sent = $_POST['_csrf'] ?? '';
    if (!is_string($sent) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $sent)) {
        http_response_code(419);
        exit('Sessão inválida ou expirada. Volte, recarregue a página e tente novamente.');
    }
}

function current_user_id(): int
{
    return (int)($_SESSION['uid'] ?? 0);
}

function require_login(): void
{
    if (current_user_id() <= 0) {
        $back = $_SERVER['REQUEST_URI'] ?? '';
        redirect('login.php' . ($back ? '?next=' . rawurlencode($back) : ''));
    }
}

function password_algo(): string|int
{
    return defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
}

function hash_password(string $plain): string
{
    return password_hash($plain, password_algo());
}

function client_ip(): string
{
    return substr((string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 45);
}

/** Minutos restantes de bloqueio (0 = liberado). */
function login_bloqueio_restante(string $usuario): int
{
    $janela = LOGIN_JANELA_MIN;
    $sql = "SELECT COUNT(*) AS n, MAX(criado_em) AS ultima FROM login_tentativas
            WHERE sucesso = 0 AND criado_em > (NOW() - INTERVAL {$janela} MINUTE) AND %s = ?";
    foreach ([['ip', client_ip()], ['usuario', mb_strtolower($usuario)]] as [$col, $val]) {
        if ($val === '') {
            continue;
        }
        $r = q_one(sprintf($sql, $col), [$val]);
        if ($r && (int)$r['n'] >= LOGIN_MAX_TENTATIVAS) {
            $libera = strtotime((string)$r['ultima']) + $janela * 60;
            return max(1, (int)ceil(($libera - time()) / 60));
        }
    }
    return 0;
}

function registrar_tentativa(string $usuario, bool $sucesso): void
{
    q('INSERT INTO login_tentativas (ip, usuario, sucesso) VALUES (?, ?, ?)', [client_ip(), mb_strtolower($usuario), $sucesso ? 1 : 0]);
    if (random_int(1, 50) === 1) {
        q('DELETE FROM login_tentativas WHERE criado_em < (NOW() - INTERVAL 30 DAY)');
    }
}

/**
 * Tenta autenticar. Devolve null em caso de sucesso ou a mensagem de erro.
 */
function attempt_login(string $usuario, string $senha): ?string
{
    $usuario = trim($usuario);
    $restante = login_bloqueio_restante($usuario);
    if ($restante > 0) {
        return "Muitas tentativas erradas. Aguarde {$restante} min para tentar de novo.";
    }
    $u = q_one('SELECT * FROM usuarios WHERE usuario = ?', [$usuario]);
    // Verifica mesmo sem usuário, para não revelar pelo tempo de resposta se o usuário existe.
    $hash = $u['senha_hash'] ?? '$2y$10$jXmRTtnOScmkGUQ9oLdwzu7bA2/86bG.FOgIIroT8OzzDs0ccNTx.';
    $ok = password_verify($senha, $hash) && $u !== null;
    registrar_tentativa($usuario, $ok);
    if (!$ok) {
        return 'Usuário ou senha incorretos.';
    }
    if (password_needs_rehash($u['senha_hash'], password_algo())) {
        q('UPDATE usuarios SET senha_hash = ? WHERE id = ?', [hash_password($senha), $u['id']]);
    }
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$u['id'];
    $_SESSION['usuario'] = $u['usuario'];
    $_SESSION['login_at'] = time();
    $_SESSION['last_seen'] = time();
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    q('UPDATE usuarios SET ultimo_login = NOW() WHERE id = ?', [$u['id']]);
    return null;
}

function logout(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 3600, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/** Regras mínimas de senha. Devolve mensagem de erro ou null. */
function senha_fraca(string $senha): ?string
{
    if (mb_strlen($senha) < 10) {
        return 'A senha precisa ter pelo menos 10 caracteres.';
    }
    if (!preg_match('/[A-Za-z]/', $senha) || !preg_match('/\d/', $senha)) {
        return 'Use letras e números na senha.';
    }
    return null;
}
