<?php
declare(strict_types=1);

/**
 * Gerador de PDF mínimo, sem dependências (Helvetica padrão, A4, uma ou mais páginas).
 * Suficiente para o resumo de ofertas: retângulos coloridos, textos e quebra de linha.
 * Coordenadas em pontos, com origem no canto SUPERIOR esquerdo (y cresce para baixo).
 */
final class SimplePdf
{
    public const W = 595.28;
    public const H = 841.89;

    private array $pages = [];
    private string $cur = '';

    private const REG = [
        ' ' => 278, '!' => 278, '"' => 355, '#' => 556, '$' => 556, '%' => 889, '&' => 667, "'" => 191, '(' => 333, ')' => 333,
        '*' => 389, '+' => 584, ',' => 278, '-' => 333, '.' => 278, '/' => 278, ':' => 278, ';' => 278, '<' => 584, '=' => 584,
        '>' => 584, '?' => 556, '@' => 1015, 'A' => 667, 'B' => 667, 'C' => 722, 'D' => 722, 'E' => 667, 'F' => 611, 'G' => 778,
        'H' => 722, 'I' => 278, 'J' => 500, 'K' => 667, 'L' => 556, 'M' => 833, 'N' => 722, 'O' => 778, 'P' => 667, 'Q' => 778,
        'R' => 722, 'S' => 667, 'T' => 611, 'U' => 722, 'V' => 667, 'W' => 944, 'X' => 667, 'Y' => 667, 'Z' => 611, '[' => 278,
        '\\' => 278, ']' => 278, '^' => 469, '_' => 556, 'a' => 556, 'b' => 556, 'c' => 500, 'd' => 556, 'e' => 556, 'f' => 278,
        'g' => 556, 'h' => 556, 'i' => 222, 'j' => 222, 'k' => 500, 'l' => 222, 'm' => 833, 'n' => 556, 'o' => 556, 'p' => 556,
        'q' => 556, 'r' => 333, 's' => 500, 't' => 278, 'u' => 556, 'v' => 500, 'w' => 722, 'x' => 500, 'y' => 500, 'z' => 500,
        '|' => 260, '•' => 350,
    ];
    private const BOLD = [
        ' ' => 278, '!' => 333, '"' => 474, '#' => 556, '$' => 556, '%' => 889, '&' => 722, "'" => 238, '(' => 333, ')' => 333,
        '*' => 389, '+' => 584, ',' => 278, '-' => 333, '.' => 278, '/' => 278, ':' => 333, ';' => 333, '<' => 584, '=' => 584,
        '>' => 584, '?' => 611, '@' => 975, 'A' => 722, 'B' => 722, 'C' => 722, 'D' => 722, 'E' => 667, 'F' => 611, 'G' => 778,
        'H' => 722, 'I' => 278, 'J' => 556, 'K' => 722, 'L' => 611, 'M' => 833, 'N' => 722, 'O' => 778, 'P' => 667, 'Q' => 778,
        'R' => 722, 'S' => 667, 'T' => 611, 'U' => 722, 'V' => 667, 'W' => 944, 'X' => 667, 'Y' => 667, 'Z' => 611, '[' => 333,
        '\\' => 278, ']' => 333, '^' => 584, '_' => 556, 'a' => 556, 'b' => 611, 'c' => 556, 'd' => 611, 'e' => 556, 'f' => 333,
        'g' => 611, 'h' => 611, 'i' => 278, 'j' => 278, 'k' => 556, 'l' => 278, 'm' => 889, 'n' => 611, 'o' => 611, 'p' => 611,
        'q' => 611, 'r' => 389, 's' => 556, 't' => 333, 'u' => 611, 'v' => 556, 'w' => 778, 'x' => 556, 'y' => 556, 'z' => 500,
        '|' => 280, '•' => 350,
    ];

    public function addPage(): void
    {
        if ($this->cur !== '' || $this->pages) {
            $this->pages[] = $this->cur;
        }
        $this->cur = '';
    }

    private static function rgb(string $hex): string
    {
        $hex = ltrim($hex, '#');
        return sprintf('%.3F %.3F %.3F', hexdec(substr($hex, 0, 2)) / 255, hexdec(substr($hex, 2, 2)) / 255, hexdec(substr($hex, 4, 2)) / 255);
    }

    public function rect(float $x, float $y, float $w, float $h, string $fill, ?string $stroke = null): void
    {
        $py = self::H - $y - $h;
        $op = 'f';
        $this->cur .= self::rgb($fill) . " rg\n";
        if ($stroke !== null) {
            $this->cur .= self::rgb($stroke) . " RG 0.8 w\n";
            $op = 'B';
        }
        $this->cur .= sprintf("%.2F %.2F %.2F %.2F re %s\n", $x, $py, $w, $h, $op);
    }

    public static function width(string $text, float $size, bool $bold = false): float
    {
        $table = $bold ? self::BOLD : self::REG;
        $base = self::fold($text);
        $w = 0;
        foreach (mb_str_split($base) as $ch) {
            $w += $table[$ch] ?? ($table[mb_strtolower($ch)] ?? 556);
        }
        return $w * $size / 1000;
    }

    /** Remove acentos só para medir a largura. */
    private static function fold(string $s): string
    {
        return strtr($s, [
            'á' => 'a', 'à' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'é' => 'e', 'ê' => 'e', 'è' => 'e', 'í' => 'i', 'ó' => 'o', 'ô' => 'o',
            'õ' => 'o', 'ö' => 'o', 'ú' => 'u', 'ü' => 'u', 'ç' => 'c', 'Á' => 'A', 'À' => 'A', 'Â' => 'A', 'Ã' => 'A', 'É' => 'E', 'Ê' => 'E',
            'Í' => 'I', 'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ú' => 'U', 'Ç' => 'C',
        ]);
    }

    private static function encode(string $text): string
    {
        $enc = mb_convert_encoding($text, 'Windows-1252', 'UTF-8');
        return strtr($enc, ['\\' => '\\\\', '(' => '\\(', ')' => '\\)', "\r" => '', "\n" => ' ']);
    }

    /** $y é a linha de base do texto, medida a partir do topo. */
    public function text(float $x, float $y, string $text, float $size = 11, bool $bold = false, string $color = '#111111', string $align = 'L', float $boxW = 0): void
    {
        if ($align !== 'L') {
            $tw = self::width($text, $size, $bold);
            $x = $align === 'C' ? $x + ($boxW - $tw) / 2 : $x + $boxW - $tw;
        }
        $this->cur .= sprintf("BT /%s %.2F Tf %s rg %.2F %.2F Td (%s) Tj ET\n",
            $bold ? 'F2' : 'F1', $size, self::rgb($color), $x, self::H - $y, self::encode($text));
    }

    /** Quebra o texto em linhas que cabem em $maxW. */
    public static function wrap(string $text, float $maxW, float $size, bool $bold = false): array
    {
        $lines = [];
        $line = '';
        foreach (preg_split('/\s+/u', trim($text)) ?: [] as $word) {
            $try = $line === '' ? $word : $line . ' ' . $word;
            if ($line !== '' && self::width($try, $size, $bold) > $maxW) {
                $lines[] = $line;
                $line = $word;
            } else {
                $line = $try;
            }
        }
        if ($line !== '') {
            $lines[] = $line;
        }
        return $lines;
    }

    /** Escreve um parágrafo com quebra e devolve o y depois do último texto. */
    public function paragraph(float $x, float $y, float $maxW, string $text, float $size = 11, bool $bold = false, string $color = '#111111', float $leading = 1.35): float
    {
        foreach (self::wrap($text, $maxW, $size, $bold) as $l) {
            $this->text($x, $y, $l, $size, $bold, $color);
            $y += $size * $leading;
        }
        return $y;
    }

    public function output(string $title = 'Documento'): string
    {
        $pages = $this->pages;
        $pages[] = $this->cur;

        $objs = [];
        $objs[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $objs[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objs[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        $info = 5;
        $objs[$info] = '<< /Title (' . self::encode($title) . ') /Producer (Painel Placas NFC) /CreationDate (D:' . date('YmdHis') . ') >>';
        $kids = [];
        $n = 6;
        foreach ($pages as $content) {
            $pageId = $n++;
            $contId = $n++;
            $kids[] = "$pageId 0 R";
            $objs[$pageId] = sprintf('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2F %.2F] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents %d 0 R >>', self::W, self::H, $contId);
            $objs[$contId] = '<< /Length ' . strlen($content) . " >>\nstream\n" . $content . "\nendstream";
        }
        $objs[2] = '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . count($kids) . ' >>';
        ksort($objs);

        $out = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $offsets = [];
        foreach ($objs as $id => $body) {
            $offsets[$id] = strlen($out);
            $out .= "$id 0 obj\n$body\nendobj\n";
        }
        $xref = strlen($out);
        $max = max(array_keys($objs));
        $out .= "xref\n0 " . ($max + 1) . "\n0000000000 65535 f \n";
        for ($i = 1; $i <= $max; $i++) {
            $out .= isset($offsets[$i]) ? sprintf("%010d 00000 n \n", $offsets[$i]) : "0000000000 65535 f \n";
        }
        $out .= "trailer\n<< /Size " . ($max + 1) . " /Root 1 0 R /Info $info 0 R >>\nstartxref\n$xref\n%%EOF";
        return $out;
    }
}
