<?php
declare(strict_types=1);

/**
 * Textos das ofertas, usados no card 1080x1080 e no PDF de resumo.
 * Edite aqui se quiser mudar a copy de venda.
 */
function ofertas_conteudo(): array
{
    $p = precos_padrao();
    return [
        'combo' => [
            'nome' => 'Google Completo',
            'preco' => $p['combo'],
            'nota_preco' => 'pagamento único',
            'chamada' => 'Seu comércio encontrado e bem avaliado no Google',
            'descricao' => 'A solução completa: a plaquinha traz as avaliações e o perfil otimizado faz o cliente escolher você.',
            'itens' => ['Plaquinha NFC + QR code no balcão', 'Perfil do Google otimizado: categoria, descrição e serviços', 'Fotos novas tiradas no seu comércio'],
            'arquivo' => 'card-oferta-google-completo-1080x1080.png',
        ],
        'avulsa' => [
            'nome' => 'Plaquinha de Avaliação',
            'preco' => $p['avulsa'],
            'nota_preco' => 'paga na entrega',
            'chamada' => 'Seu cliente avalia você no Google em 10 segundos',
            'descricao' => 'O cliente aproxima o celular ou lê o QR code e já cai na tela de avaliar. Ideal para quem já tem o perfil bem arrumado.',
            'itens' => ['Funciona por aproximação (NFC) e QR code', 'Sem baixar aplicativo e sem procurar nada', 'Instalada no seu balcão ou caixa'],
            'arquivo' => 'card-oferta-plaquinha-avaliacao-1080x1080.png',
        ],
        'kit2' => [
            'nome' => 'Kit 2 Plaquinhas',
            'preco' => $p['kit2'],
            'nota_preco' => 'paga na entrega',
            'chamada' => 'Mais pontos de avaliação no seu espaço',
            'descricao' => 'Uma placa no caixa e outra nas mesas ou na recepção. Ótimo para restaurantes, bares e salões grandes.',
            'itens' => ['2 plaquinhas NFC + QR code', 'Uma no caixa, outra nas mesas ou recepção', 'Mais clientes avaliando no momento certo'],
            'arquivo' => 'card-oferta-kit-2-plaquinhas-1080x1080.png',
        ],
    ];
}
