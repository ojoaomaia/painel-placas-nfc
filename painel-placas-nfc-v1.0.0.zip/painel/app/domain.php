<?php
declare(strict_types=1);

/**
 * Regras de negócio: estoque, vendas, instalação, checagens, assinaturas e pendências.
 * Funções que alteram dados lançam DomainException com mensagem amigável quando algo não é permitido.
 */

const PLACAS_POR_TIPO = ['avulsa' => 1, 'combo' => 1, 'kit2' => 2];

function precos_padrao(): array
{
    return [
        'avulsa' => (float)cfg('preco_avulsa', '80'),
        'combo' => (float)cfg('preco_combo', '250'),
        'kit2' => (float)cfg('preco_kit2', '140'),
        'upgrade_combo' => (float)cfg('preco_upgrade_combo', '170'),
    ];
}

function transaction(callable $fn): mixed
{
    $pdo = db();
    if ($pdo->inTransaction()) {
        return $fn(); // já dentro de uma transação externa
    }
    $pdo->beginTransaction();
    try {
        $r = $fn();
        $pdo->commit();
        return $r;
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/* ------------------------------------------------------------------ */
/* Lotes e estoque                                                     */
/* ------------------------------------------------------------------ */

function proximo_numero_placa(): int
{
    // Trava as linhas lidas para evitar código duplicado em gravações simultâneas.
    $max = q_val("SELECT MAX(CAST(SUBSTRING(codigo, 5) AS UNSIGNED)) FROM placas WHERE codigo LIKE 'PNF-%' FOR UPDATE");
    return ((int)$max) + 1;
}

function formatar_codigo(int $n): string
{
    return sprintf('PNF-%04d', $n);
}

/**
 * Cria o lote e gera uma placa por unidade, com códigos sequenciais.
 * $placasonIds: lista opcional de IDs da PlacasOn, na mesma ordem das placas.
 * @return array{lote_id:int, codigos:string[]}
 */
function criar_lote(string $data, int $modeloId, int $qtd, float $custo, string $fornecedor, string $obs, array $placasonIds = []): array
{
    if (!valid_date($data)) {
        throw new DomainException('Data do lote inválida.');
    }
    if ($qtd < 1 || $qtd > 500) {
        throw new DomainException('Quantidade deve ser entre 1 e 500.');
    }
    if ($custo < 0) {
        throw new DomainException('Custo unitário inválido.');
    }
    if (!q_one('SELECT id FROM modelos WHERE id = ?', [$modeloId])) {
        throw new DomainException('Modelo não encontrado.');
    }
    return transaction(function () use ($data, $modeloId, $qtd, $custo, $fornecedor, $obs, $placasonIds) {
        q('INSERT INTO lotes (data_compra, modelo_id, quantidade, custo_unitario, fornecedor, observacoes) VALUES (?,?,?,?,?,?)',
            [$data, $modeloId, $qtd, $custo, $fornecedor !== '' ? $fornecedor : 'PlacasOn', $obs]);
        $loteId = (int)db()->lastInsertId();
        $n = proximo_numero_placa();
        $codigos = [];
        $ins = db()->prepare('INSERT INTO placas (codigo, lote_id, modelo_id, placason_id) VALUES (?,?,?,?)');
        for ($i = 0; $i < $qtd; $i++) {
            $codigo = formatar_codigo($n + $i);
            $ins->execute([$codigo, $loteId, $modeloId, mb_substr(trim((string)($placasonIds[$i] ?? '')), 0, 80)]);
            $codigos[] = $codigo;
        }
        return ['lote_id' => $loteId, 'codigos' => $codigos];
    });
}

/** Estoque por modelo, com flag de alerta quando abaixo ou igual ao mínimo. */
function estoque_por_modelo(): array
{
    return q_all("SELECT m.id, m.nome, m.tipo, m.cor, m.estoque_minimo, m.ativo,
            COALESCE(SUM(p.status = 'estoque'), 0) AS em_estoque,
            COALESCE(SUM(p.status IN ('vendida','instalada')), 0) AS saidas
        FROM modelos m LEFT JOIN placas p ON p.modelo_id = m.id
        GROUP BY m.id ORDER BY m.ordem, m.nome");
}

function alertas_estoque(): array
{
    return array_values(array_filter(estoque_por_modelo(), fn($m) => (int)$m['ativo'] === 1 && (int)$m['em_estoque'] <= (int)$m['estoque_minimo']));
}

/* ------------------------------------------------------------------ */
/* Vendas                                                              */
/* ------------------------------------------------------------------ */

/**
 * Registra venda de avulsa, combo ou kit2 e vincula as placas ao cliente.
 */
function registrar_venda(int $clienteId, string $tipo, array $placaIds, float $valor, string $forma, string $data, string $obs): int
{
    if (!isset(PLACAS_POR_TIPO[$tipo])) {
        throw new DomainException('Tipo de venda inválido.');
    }
    if (!q_one('SELECT id FROM clientes WHERE id = ?', [$clienteId])) {
        throw new DomainException('Selecione um cliente.');
    }
    if (!valid_date($data)) {
        throw new DomainException('Data da venda inválida.');
    }
    if ($valor <= 0) {
        throw new DomainException('Informe o valor da venda.');
    }
    if (!in_array($forma, ['pix', 'dinheiro', 'cartao', 'outro'], true)) {
        throw new DomainException('Forma de pagamento inválida.');
    }
    $placaIds = array_values(array_unique(array_filter(array_map('intval', $placaIds))));
    $esperado = PLACAS_POR_TIPO[$tipo];
    if (count($placaIds) !== $esperado) {
        throw new DomainException(sprintf('%s precisa de %d placa%s.', tipo_venda_label($tipo), $esperado, $esperado > 1 ? 's' : ''));
    }

    return transaction(function () use ($clienteId, $tipo, $placaIds, $valor, $forma, $data, $obs) {
        $in = implode(',', array_fill(0, count($placaIds), '?'));
        $placas = q_all("SELECT id, codigo, status FROM placas WHERE id IN ($in) FOR UPDATE", $placaIds);
        if (count($placas) !== count($placaIds)) {
            throw new DomainException('Placa não encontrada.');
        }
        foreach ($placas as $p) {
            if ($p['status'] !== 'estoque') {
                throw new DomainException("A placa {$p['codigo']} não está em estoque.");
            }
        }
        q('INSERT INTO vendas (cliente_id, tipo, valor, forma_pagamento, data_venda, observacoes) VALUES (?,?,?,?,?,?)',
            [$clienteId, $tipo, $valor, $forma, $data, $obs]);
        $vendaId = (int)db()->lastInsertId();
        q("UPDATE placas SET status = 'vendida', cliente_id = ?, venda_id = ?, data_venda = ? WHERE id IN ($in)",
            array_merge([$clienteId, $vendaId, $data], $placaIds));
        return $vendaId;
    });
}

/** Upgrade de uma venda avulsa (ou kit) para o combo Google Completo. Mantém a venda original no histórico. */
function registrar_upgrade_combo(int $vendaOrigemId, float $valor, string $forma, string $data, string $obs): int
{
    $orig = q_one('SELECT * FROM vendas WHERE id = ?', [$vendaOrigemId]);
    if (!$orig) {
        throw new DomainException('Venda original não encontrada.');
    }
    if (!in_array($orig['tipo'], ['avulsa', 'kit2'], true)) {
        throw new DomainException('Só vendas avulsas ou kits podem receber upgrade para o Google Completo.');
    }
    if (q_one("SELECT id FROM vendas WHERE venda_origem_id = ? AND tipo = 'upgrade_combo'", [$vendaOrigemId])) {
        throw new DomainException('Essa venda já recebeu upgrade.');
    }
    if (!valid_date($data) || $valor <= 0) {
        throw new DomainException('Informe data e valor do upgrade.');
    }
    if (!in_array($forma, ['pix', 'dinheiro', 'cartao', 'outro'], true)) {
        throw new DomainException('Forma de pagamento inválida.');
    }
    q('INSERT INTO vendas (cliente_id, tipo, valor, forma_pagamento, data_venda, venda_origem_id, observacoes) VALUES (?,?,?,?,?,?,?)',
        [$orig['cliente_id'], 'upgrade_combo', $valor, $forma, $data, $vendaOrigemId, $obs]);
    return (int)db()->lastInsertId();
}

/** Cancela uma venda lançada por engano. Só é permitido antes da instalação. */
function cancelar_venda(int $vendaId): void
{
    $v = q_one('SELECT * FROM vendas WHERE id = ?', [$vendaId]);
    if (!$v) {
        throw new DomainException('Venda não encontrada.');
    }
    if (q_one('SELECT id FROM vendas WHERE venda_origem_id = ?', [$vendaId])) {
        throw new DomainException('Essa venda tem um upgrade vinculado. Cancele o upgrade primeiro.');
    }
    if ($v['tipo'] !== 'upgrade_combo' && q_one("SELECT id FROM placas WHERE venda_id = ? AND status <> 'vendida'", [$vendaId])) {
        throw new DomainException('Há placa já instalada ou desativada nessa venda. Não é possível cancelar.');
    }
    transaction(function () use ($vendaId) {
        q("UPDATE placas SET status = 'estoque', cliente_id = NULL, venda_id = NULL, data_venda = NULL WHERE venda_id = ?", [$vendaId]);
        q('DELETE FROM vendas WHERE id = ?', [$vendaId]);
    });
}

/* ------------------------------------------------------------------ */
/* Instalação, checagens e ciclo de vida da placa                      */
/* ------------------------------------------------------------------ */

function parse_nota(string $v): ?float
{
    $v = str_replace(',', '.', trim($v));
    if ($v === '' || !is_numeric($v)) {
        return null;
    }
    $n = round((float)$v, 1);
    return ($n >= 1.0 && $n <= 5.0) ? $n : null;
}

function registrar_instalacao(int $placaId, string $data, string $nota, string $avaliacoes, string $local): void
{
    $p = q_one('SELECT * FROM placas WHERE id = ?', [$placaId]);
    if (!$p) {
        throw new DomainException('Placa não encontrada.');
    }
    if ($p['status'] !== 'vendida') {
        throw new DomainException('Só placas vendidas (ainda não instaladas) podem ser instaladas.');
    }
    if (!valid_date($data)) {
        throw new DomainException('Data de instalação inválida.');
    }
    if ($p['data_venda'] && $data < $p['data_venda']) {
        throw new DomainException('A instalação não pode ser antes da venda.');
    }
    $n = parse_nota($nota);
    if ($n === null) {
        throw new DomainException('Nota do Google inválida. Use um valor de 1,0 a 5,0.');
    }
    if (!ctype_digit($avaliacoes)) {
        throw new DomainException('Total de avaliações inválido.');
    }
    q("UPDATE placas SET status = 'instalada', data_instalacao = ?, marco_nota = ?, marco_avaliacoes = ?, local_instalacao = ? WHERE id = ?",
        [$data, $n, (int)$avaliacoes, mb_substr($local, 0, 120), $placaId]);
}

function registrar_checagem(int $placaId, string $data, string $nota, string $avaliacoes, string $scans, string $obs): void
{
    $p = q_one('SELECT * FROM placas WHERE id = ?', [$placaId]);
    if (!$p || !in_array($p['status'], ['instalada', 'desativada'], true) || !$p['data_instalacao']) {
        throw new DomainException('Registre a instalação (marco zero) antes das checagens.');
    }
    if (!valid_date($data) || $data < $p['data_instalacao']) {
        throw new DomainException('Data da checagem inválida (precisa ser igual ou depois da instalação).');
    }
    $n = parse_nota($nota);
    if ($n === null) {
        throw new DomainException('Nota do Google inválida. Use um valor de 1,0 a 5,0.');
    }
    if (!ctype_digit($avaliacoes)) {
        throw new DomainException('Total de avaliações inválido.');
    }
    if ($scans !== '' && !ctype_digit($scans)) {
        throw new DomainException('Número de scans inválido.');
    }
    q('INSERT INTO checagens (placa_id, data_checagem, nota, avaliacoes, scans, observacoes) VALUES (?,?,?,?,?,?)',
        [$placaId, $data, $n, (int)$avaliacoes, $scans === '' ? null : (int)$scans, $obs]);
}

/** Troca uma placa com defeito por outra do estoque, mantendo cliente e venda. */
function substituir_placa(int $placaId, int $novaId, string $motivo): void
{
    transaction(function () use ($placaId, $novaId, $motivo) {
        $velha = q_one('SELECT * FROM placas WHERE id = ? FOR UPDATE', [$placaId]);
        $nova = q_one('SELECT * FROM placas WHERE id = ? FOR UPDATE', [$novaId]);
        if (!$velha || !$nova) {
            throw new DomainException('Placa não encontrada.');
        }
        if (!in_array($velha['status'], ['vendida', 'instalada'], true)) {
            throw new DomainException('Só placas vendidas ou instaladas podem ser substituídas.');
        }
        if ($nova['status'] !== 'estoque') {
            throw new DomainException('A placa nova precisa estar em estoque.');
        }
        $nota = trim("Substituída por {$nova['codigo']} em " . date('d/m/Y') . ($motivo !== '' ? ". Motivo: {$motivo}" : ''));
        q("UPDATE placas SET status = 'desativada', observacoes = CONCAT(COALESCE(observacoes,''), IF(COALESCE(observacoes,'') = '', '', '\n'), ?) WHERE id = ?", [$nota, $placaId]);
        q("UPDATE placas SET status = 'vendida', cliente_id = ?, venda_id = ?, data_venda = ?, observacoes = ? WHERE id = ?",
            [$velha['cliente_id'], $velha['venda_id'], $velha['data_venda'], "Substitui {$velha['codigo']}", $novaId]);
    });
}

function desativar_placa(int $placaId, string $motivo): void
{
    $p = q_one('SELECT * FROM placas WHERE id = ?', [$placaId]);
    if (!$p || !in_array($p['status'], ['vendida', 'instalada'], true)) {
        throw new DomainException('Só placas vendidas ou instaladas podem ser desativadas.');
    }
    $nota = 'Desativada em ' . date('d/m/Y') . ($motivo !== '' ? ". Motivo: {$motivo}" : '');
    q("UPDATE placas SET status = 'desativada', observacoes = CONCAT(COALESCE(observacoes,''), IF(COALESCE(observacoes,'') = '', '', '\n'), ?) WHERE id = ?", [$nota, $placaId]);
}

function reativar_placa(int $placaId): void
{
    $p = q_one('SELECT * FROM placas WHERE id = ?', [$placaId]);
    if (!$p || $p['status'] !== 'desativada') {
        throw new DomainException('A placa não está desativada.');
    }
    if (!$p['cliente_id']) {
        throw new DomainException('Placa sem cliente vinculado.');
    }
    $novo = $p['data_instalacao'] ? 'instalada' : 'vendida';
    $nota = 'Reativada em ' . date('d/m/Y');
    q("UPDATE placas SET status = ?, observacoes = CONCAT(COALESCE(observacoes,''), IF(COALESCE(observacoes,'') = '', '', '\n'), ?) WHERE id = ?", [$novo, $nota, $placaId]);
}

/* ------------------------------------------------------------------ */
/* Assinaturas                                                         */
/* ------------------------------------------------------------------ */

function criar_assinatura(int $clienteId, float $valor, string $inicio, string $obs): int
{
    if (!q_one('SELECT id FROM clientes WHERE id = ?', [$clienteId])) {
        throw new DomainException('Cliente não encontrado.');
    }
    if (q_one("SELECT id FROM assinaturas WHERE cliente_id = ? AND status = 'ativa'", [$clienteId])) {
        throw new DomainException('Esse cliente já tem uma assinatura ativa.');
    }
    if (!valid_date($inicio) || $valor <= 0) {
        throw new DomainException('Informe data de início e valor da mensalidade.');
    }
    q('INSERT INTO assinaturas (cliente_id, valor, status, data_inicio, proximo_relatorio, observacoes) VALUES (?,?,?,?,?,?)',
        [$clienteId, $valor, 'ativa', $inicio, add_months($inicio, 1), $obs]);
    return (int)db()->lastInsertId();
}

function encerrar_assinatura(int $id, string $fim): void
{
    $a = q_one('SELECT * FROM assinaturas WHERE id = ?', [$id]);
    if (!$a || $a['status'] !== 'ativa') {
        throw new DomainException('Assinatura não está ativa.');
    }
    if (!valid_date($fim) || $fim < $a['data_inicio']) {
        throw new DomainException('Data de encerramento inválida.');
    }
    q("UPDATE assinaturas SET status = 'inativa', data_fim = ? WHERE id = ?", [$fim, $id]);
}

function registrar_relatorio(int $id, string $data, string $obs): void
{
    $a = q_one('SELECT * FROM assinaturas WHERE id = ?', [$id]);
    if (!$a || $a['status'] !== 'ativa') {
        throw new DomainException('Assinatura não está ativa.');
    }
    if (!valid_date($data)) {
        throw new DomainException('Data de envio inválida.');
    }
    transaction(function () use ($a, $data, $obs) {
        q('INSERT INTO relatorios_enviados (assinatura_id, referencia, enviado_em, observacoes) VALUES (?,?,?,?)',
            [$a['id'], $a['proximo_relatorio'], $data, $obs]);
        q('UPDATE assinaturas SET proximo_relatorio = ? WHERE id = ?', [add_months($a['proximo_relatorio'], 1), $a['id']]);
    });
}

function registrar_pagamento_assinatura(int $id, float $valor, string $data, string $forma, string $ref): void
{
    if (!q_one('SELECT id FROM assinaturas WHERE id = ?', [$id])) {
        throw new DomainException('Assinatura não encontrada.');
    }
    if (!valid_date($data) || $valor <= 0) {
        throw new DomainException('Informe data e valor do pagamento.');
    }
    if (!in_array($forma, ['pix', 'dinheiro', 'cartao', 'outro'], true)) {
        throw new DomainException('Forma de pagamento inválida.');
    }
    if ($ref !== '' && !preg_match('/^\d{4}-\d{2}$/', $ref)) {
        throw new DomainException('Mês de referência inválido.');
    }
    q('INSERT INTO pagamentos_assinatura (assinatura_id, valor, data_pagamento, forma_pagamento, referencia) VALUES (?,?,?,?,?)',
        [$id, $valor, $data, $forma, $ref]);
}

/* ------------------------------------------------------------------ */
/* Pendências e métricas                                               */
/* ------------------------------------------------------------------ */

/**
 * Lista de ações pendentes, da mais urgente para a menos urgente.
 * Cada item: tipo, titulo, detalhe, link, urgente(bool), cliente
 */
function pendencias(): array
{
    $hoje = today();
    $out = [];

    foreach (q_all("SELECT v.id, v.tipo, v.data_venda, v.fotos_tiradas, v.perfil_otimizado, c.id AS cid, c.nome
            FROM vendas v JOIN clientes c ON c.id = v.cliente_id
            WHERE v.tipo IN ('combo','upgrade_combo') AND (v.fotos_tiradas = 0 OR v.perfil_otimizado = 0)
            ORDER BY v.data_venda") as $v) {
        $dias = days_between($v['data_venda'], $hoje);
        if (!$v['fotos_tiradas']) {
            $out[] = ['tipo' => 'fotos', 'icone' => 'bi-camera', 'titulo' => 'Fotos do combo não tiradas',
                'cliente' => $v['nome'], 'detalhe' => "Combo vendido há {$dias} dia(s)", 'link' => "venda.php?id={$v['id']}", 'urgente' => $dias > 7];
        }
        if (!$v['perfil_otimizado']) {
            $out[] = ['tipo' => 'perfil', 'icone' => 'bi-google', 'titulo' => 'Otimização do perfil pendente',
                'cliente' => $v['nome'], 'detalhe' => "Combo vendido há {$dias} dia(s)", 'link' => "venda.php?id={$v['id']}", 'urgente' => $dias > 14];
        }
    }

    foreach (q_all("SELECT a.id, a.proximo_relatorio, c.nome FROM assinaturas a JOIN clientes c ON c.id = a.cliente_id
            WHERE a.status = 'ativa' AND a.proximo_relatorio <= ? ORDER BY a.proximo_relatorio", [$hoje]) as $a) {
        $atraso = days_between($a['proximo_relatorio'], $hoje);
        $out[] = ['tipo' => 'relatorio', 'icone' => 'bi-file-earmark-bar-graph', 'titulo' => $atraso > 0 ? 'Relatório mensal atrasado' : 'Relatório mensal vence hoje',
            'cliente' => $a['nome'], 'detalhe' => $atraso > 0 ? "Venceu em " . date_br($a['proximo_relatorio']) . " ({$atraso} dia(s) de atraso)" : 'Previsto para hoje',
            'link' => "assinaturas.php?id={$a['id']}", 'urgente' => $atraso > 0];
    }

    foreach (q_all("SELECT p.id, p.codigo, p.data_venda, c.nome FROM placas p JOIN clientes c ON c.id = p.cliente_id
            WHERE p.status = 'vendida' ORDER BY p.data_venda") as $p) {
        $dias = days_between($p['data_venda'], $hoje);
        $out[] = ['tipo' => 'instalacao', 'icone' => 'bi-tools', 'titulo' => "Instalar {$p['codigo']} e registrar marco zero",
            'cliente' => $p['nome'], 'detalhe' => "Vendida há {$dias} dia(s)", 'link' => "placa.php?id={$p['id']}", 'urgente' => $dias > 3];
    }

    // Checagens de acompanhamento: 7 e 30 dias após a instalação.
    foreach ([[7, 5], [30, 25]] as [$marco, $tolerancia]) {
        $rows = q_all("SELECT p.id, p.codigo, p.data_instalacao, c.nome FROM placas p JOIN clientes c ON c.id = p.cliente_id
            WHERE p.status = 'instalada' AND p.data_instalacao <= (? - INTERVAL {$marco} DAY)
              AND p.data_instalacao > (? - INTERVAL 120 DAY)
              AND NOT EXISTS (SELECT 1 FROM checagens k WHERE k.placa_id = p.id
                              AND k.data_checagem >= (p.data_instalacao + INTERVAL {$tolerancia} DAY))
            ORDER BY p.data_instalacao", [$hoje, $hoje]);
        foreach ($rows as $p) {
            $dias = days_between($p['data_instalacao'], $hoje);
            if ($marco === 7 && $dias >= 30) {
                continue; // a de 30 dias já cobre
            }
            $out[] = ['tipo' => 'checagem', 'icone' => 'bi-graph-up-arrow', 'titulo' => "Checagem de {$marco} dias ({$p['codigo']})",
                'cliente' => $p['nome'], 'detalhe' => "Instalada há {$dias} dia(s)", 'link' => "placa.php?id={$p['id']}#checagem", 'urgente' => $dias > $marco + 5];
        }
    }

    usort($out, fn($a, $b) => (int)$b['urgente'] <=> (int)$a['urgente']);
    return $out;
}

function metricas_painel(): array
{
    $ini = date('Y-m-01');
    $fim = date('Y-m-t');

    $status = ['estoque' => 0, 'vendida' => 0, 'instalada' => 0, 'desativada' => 0];
    foreach (q_all('SELECT status, COUNT(*) n FROM placas GROUP BY status') as $r) {
        $status[$r['status']] = (int)$r['n'];
    }

    $porTipo = [];
    foreach (['avulsa', 'combo', 'kit2', 'upgrade_combo'] as $t) {
        $porTipo[$t] = ['qtd_mes' => 0, 'valor_mes' => 0.0, 'qtd_total' => 0, 'valor_total' => 0.0];
    }
    foreach (q_all('SELECT tipo, COUNT(*) qtd, SUM(valor) valor, SUM(data_venda BETWEEN ? AND ?) qtd_mes,
            SUM(IF(data_venda BETWEEN ? AND ?, valor, 0)) valor_mes FROM vendas GROUP BY tipo', [$ini, $fim, $ini, $fim]) as $r) {
        $porTipo[$r['tipo']] = ['qtd_mes' => (int)$r['qtd_mes'], 'valor_mes' => (float)$r['valor_mes'], 'qtd_total' => (int)$r['qtd'], 'valor_total' => (float)$r['valor']];
    }

    $vendasMes = (float)q_val('SELECT COALESCE(SUM(valor),0) FROM vendas WHERE data_venda BETWEEN ? AND ?', [$ini, $fim]);
    $mensalidadesMes = (float)q_val('SELECT COALESCE(SUM(valor),0) FROM pagamentos_assinatura WHERE data_pagamento BETWEEN ? AND ?', [$ini, $fim]);
    $custoMes = (float)q_val('SELECT COALESCE(SUM(l.custo_unitario),0) FROM placas p JOIN lotes l ON l.id = p.lote_id
            WHERE p.data_venda BETWEEN ? AND ? AND p.venda_id IS NOT NULL', [$ini, $fim]);
    $assin = q_one("SELECT COUNT(*) n, COALESCE(SUM(valor),0) mrr FROM assinaturas WHERE status = 'ativa'");

    return [
        'status' => $status,
        'por_tipo' => $porTipo,
        'vendas_mes' => $vendasMes,
        'mensalidades_mes' => $mensalidadesMes,
        'faturamento_mes' => $vendasMes + $mensalidadesMes,
        'custo_placas_mes' => $custoMes,
        'assinaturas_ativas' => (int)$assin['n'],
        'mrr' => (float)$assin['mrr'],
    ];
}

/** Última checagem de uma placa, ou null. */
function ultima_checagem(int $placaId): ?array
{
    return q_one('SELECT * FROM checagens WHERE placa_id = ? ORDER BY data_checagem DESC, id DESC LIMIT 1', [$placaId]);
}

/** Bloco HTML com variação colorida. */
function delta_html(float $v, int $dec = 0, bool $ocultarZero = false): string
{
    if ($ocultarZero && abs($v) < 0.05) {
        return '';
    }
    $cls = $v > 0 ? 'delta-up' : ($v < 0 ? 'delta-down' : 'text-secondary');
    return '<span class="' . $cls . '">' . h(delta($v, $dec)) . '</span>';
}
