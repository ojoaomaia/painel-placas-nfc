<?php
declare(strict_types=1);

function h(mixed $v): string
{
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function money(mixed $v): string
{
    return 'R$ ' . number_format((float)$v, 2, ',', '.');
}

function num(mixed $v, int $dec = 0): string
{
    return number_format((float)$v, $dec, ',', '.');
}

function nota_fmt(mixed $v): string
{
    return $v === null || $v === '' ? '-' : number_format((float)$v, 1, ',', '');
}

function date_br(?string $d): string
{
    if (!$d) {
        return '-';
    }
    $ts = strtotime($d);
    return $ts ? date('d/m/Y', $ts) : '-';
}

function mes_nome(string $ym): string
{
    $meses = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
    [$y, $m] = array_map('intval', explode('-', $ym));
    return ($meses[$m - 1] ?? '') . ' de ' . $y;
}

function today(): string
{
    return date('Y-m-d');
}

/** Converte "24,90", "R$ 1.250,00" ou "24.90" em float. */
function parse_money(mixed $v): float
{
    $s = trim((string)$v);
    $s = preg_replace('/[^\d,.\-]/', '', $s) ?? '';
    if ($s === '') {
        return 0.0;
    }
    if (str_contains($s, ',')) {
        $s = str_replace('.', '', $s);
        $s = str_replace(',', '.', $s);
    }
    return round((float)$s, 2);
}

/** Valida e normaliza data Y-m-d. Devolve null se inválida. */
function valid_date(mixed $v): ?string
{
    $s = trim((string)$v);
    $dt = DateTime::createFromFormat('!Y-m-d', $s);
    return ($dt && $dt->format('Y-m-d') === $s) ? $s : null;
}

function post(string $key, string $default = ''): string
{
    $v = $_POST[$key] ?? $default;
    return is_string($v) ? trim($v) : $default;
}

function get(string $key, string $default = ''): string
{
    $v = $_GET[$key] ?? $default;
    return is_string($v) ? trim($v) : $default;
}

function get_int(string $key): int
{
    return max(0, (int)($_GET[$key] ?? 0));
}

function post_int(string $key): int
{
    return max(0, (int)($_POST[$key] ?? 0));
}

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

function flash(string $type, string $msg): void
{
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $msg];
}

function take_flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

function not_found(string $msg = 'Registro não encontrado.'): never
{
    http_response_code(404);
    flash('danger', $msg);
    redirect('index.php');
}

/* ---------- Rótulos ---------- */

const ORIGENS = ['porta_a_porta' => 'Porta a porta', 'maps' => 'Google Maps', 'indicacao' => 'Indicação', 'outro' => 'Outro'];
const FORMAS_PAGAMENTO = ['pix' => 'Pix', 'dinheiro' => 'Dinheiro', 'cartao' => 'Cartão', 'outro' => 'Outro'];

function tipo_venda_label(string $t): string
{
    return [
        'avulsa' => 'Avulsa',
        'combo' => 'Google Completo',
        'kit2' => 'Kit 2 Plaquinhas',
        'upgrade_combo' => 'Upgrade para Google Completo',
    ][$t] ?? $t;
}

function status_placa_label(string $s): string
{
    return [
        'estoque' => 'Em estoque',
        'vendida' => 'Vendida',
        'instalada' => 'Instalada',
        'desativada' => 'Desativada',
    ][$s] ?? $s;
}

function status_placa_badge(string $s): string
{
    $cls = [
        'estoque' => 'text-bg-secondary',
        'vendida' => 'text-bg-warning',
        'instalada' => 'text-bg-success',
        'desativada' => 'text-bg-dark',
    ][$s] ?? 'text-bg-light';
    return '<span class="badge ' . $cls . '">' . h(status_placa_label($s)) . '</span>';
}

function origem_label(string $o): string
{
    return [
        'porta_a_porta' => 'Porta a porta',
        'maps' => 'Google Maps',
        'indicacao' => 'Indicação',
        'outro' => 'Outro',
    ][$o] ?? $o;
}

function pagamento_label(string $p): string
{
    return ['pix' => 'Pix', 'dinheiro' => 'Dinheiro', 'cartao' => 'Cartão', 'outro' => 'Outro'][$p] ?? $p;
}

function options(array $map, string $selected): string
{
    $out = '';
    foreach ($map as $k => $label) {
        $sel = ((string)$k === $selected) ? ' selected' : '';
        $out .= '<option value="' . h($k) . '"' . $sel . '>' . h($label) . '</option>';
    }
    return $out;
}

/** Link para o painel de scans da PlacasOn. Use {id} na URL configurada para inserir o código da placa. */
function placason_link(string $placasonId): string
{
    $base = cfg('placason_url', 'https://placason.com.br/cliente');
    if (str_contains($base, '{id}')) {
        return str_replace('{id}', rawurlencode($placasonId), $base);
    }
    return $base;
}

/** Diferença de dias entre duas datas Y-m-d. */
function days_between(string $from, string $to): int
{
    return (int)(new DateTime($from))->diff(new DateTime($to))->format('%r%a');
}

function add_months(string $date, int $months): string
{
    $d = new DateTime($date);
    $day = (int)$d->format('d');
    $d->modify('first day of this month')->modify("+{$months} month");
    $last = (int)$d->format('t');
    $d->setDate((int)$d->format('Y'), (int)$d->format('m'), min($day, $last));
    return $d->format('Y-m-d');
}

/** Aceita só links http(s); qualquer outra coisa vira string vazia. */
function clean_url(string $url): string
{
    $url = trim($url);
    if ($url === '' || !preg_match('#^https?://#i', $url) || filter_var($url, FILTER_VALIDATE_URL) === false) {
        return '';
    }
    return mb_substr($url, 0, 255);
}

function whatsapp_link(string $num): string
{
    $digits = preg_replace('/\D/', '', $num) ?? '';
    if ($digits === '') {
        return '';
    }
    if (strlen($digits) <= 11) {
        $digits = '55' . $digits;
    }
    return 'https://wa.me/' . $digits;
}

/** Variação formatada com sinal: +3, -1, 0 */
function delta(float|int $v, int $dec = 0): string
{
    $s = number_format(abs((float)$v), $dec, ',', '.');
    if ($v > 0) {
        return '+' . $s;
    }
    if ($v < 0) {
        return '-' . $s;
    }
    return $s;
}
