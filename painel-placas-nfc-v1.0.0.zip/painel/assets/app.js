(function () {
  'use strict';

  // Confirmação antes de enviar formulários sensíveis: <form data-confirm="Mensagem?">
  document.addEventListener('submit', function (ev) {
    var form = ev.target;
    var msg = form.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) {
      ev.preventDefault();
    }
  });

  // Formulário de nova venda: preço sugerido por tipo, 2ª placa só no kit, modo do cliente.
  var venda = document.getElementById('formVenda');
  if (venda) {
    var precos = {};
    try { precos = JSON.parse(venda.getAttribute('data-precos') || '{}'); } catch (e) { precos = {}; }
    var valor = document.getElementById('valorVenda');
    var fmt = function (n) { return Number(n).toFixed(2).replace('.', ','); };
    var valorEditado = false;
    valor.addEventListener('input', function () { valorEditado = true; });

    var syncTipo = function (mudouTipo) {
      var tipo = (venda.querySelector('input[name="tipo"]:checked') || {}).value;
      venda.querySelectorAll('[data-kit-only]').forEach(function (el) {
        el.style.display = tipo === 'kit2' ? '' : 'none';
        var sel = el.querySelector('select');
        if (sel && tipo !== 'kit2') { sel.value = ''; }
      });
      if (mudouTipo && !valorEditado && precos[tipo] !== undefined) {
        valor.value = fmt(precos[tipo]);
      }
    };
    var syncModo = function () {
      var modo = (venda.querySelector('input[name="cliente_modo"]:checked') || {}).value;
      venda.querySelectorAll('[data-modo]').forEach(function (el) {
        el.style.display = el.getAttribute('data-modo') === modo ? '' : 'none';
      });
    };
    venda.querySelectorAll('input[name="tipo"]').forEach(function (r) {
      r.addEventListener('change', function () { valorEditado = false; syncTipo(true); });
    });
    venda.querySelectorAll('input[name="cliente_modo"]').forEach(function (r) {
      r.addEventListener('change', syncModo);
    });
    syncTipo(false);
    syncModo();
  }
})();
