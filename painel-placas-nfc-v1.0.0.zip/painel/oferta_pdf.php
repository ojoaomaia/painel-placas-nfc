<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require_login();
require APP_DIR . '/pdf.php';
require APP_DIR . '/ofertas.php';

$ofertas = ofertas_conteudo();
$nome = cfg('nome_comercial', 'Google para Comércios');
$cidade = cfg('cidade', 'Ribeirão Preto, SP');
$whats = cfg('whatsapp_contato');
$insta = cfg('instagram_contato');

const ROXO = '#7C3AED';
const ROXO_CLARO = '#C4B5FD';
const PRETO = '#0D0B12';
const CINZA = '#5B5566';

$pdf = new SimplePdf();
$pdf->addPage();
$m = 40.0;
$w = SimplePdf::W - 2 * $m;

// Cabeçalho
$pdf->rect(0, 0, SimplePdf::W, 108, PRETO);
$pdf->rect(0, 108, SimplePdf::W, 5, ROXO);
$pdf->text($m, 52, $nome, 22, true, '#FFFFFF');
$pdf->text($m, 78, 'Avaliações e perfil do Google para comércios · ' . $cidade, 11, false, ROXO_CLARO);

$y = 146.0;
$pdf->text($m, $y, 'Como funciona e valores', 20, true, PRETO);
$y += 20;
$y = $pdf->paragraph($m, $y, $w, 'Quem pesquisa no Google já quer comprar. A pessoa compara 3 ou 4 opções no mapa e escolhe pela nota, pela quantidade de avaliações e pelas fotos. A plaquinha transforma o cliente satisfeito em avaliação, e o perfil otimizado faz o seu comércio parecer a melhor opção.', 10.5, false, CINZA);
$y += 10;

// Blocos de oferta (combo primeiro, em destaque)
foreach (['combo', 'avulsa', 'kit2'] as $k) {
    $o = $ofertas[$k];
    $dest = $k === 'combo';
    $descLines = SimplePdf::wrap($o['descricao'], $w - 150, 9.5);
    $h = 34 + count($descLines) * 12.5 + count($o['itens']) * 13.5 + 6;
    $pdf->rect($m, $y, $w, $h, $dest ? ROXO : '#F4F2F8', $dest ? null : '#E2DDEB');
    $txt = $dest ? '#FFFFFF' : PRETO;
    $sub = $dest ? '#EDE9FE' : CINZA;

    $pdf->text($m + 16, $y + 24, $o['nome'], 15, true, $txt);
    if ($dest) {
        $tw = SimplePdf::width($o['nome'], 15, true);
        $pdf->rect($m + 24 + $tw, $y + 12, 82, 16, PRETO);
        $pdf->text($m + 24 + $tw, $y + 23.5, 'RECOMENDADO', 7.5, true, '#FFFFFF', 'C', 82);
    }
    $pdf->text($m, $y + 28, 'R$ ' . number_format($o['preco'], 2, ',', '.'), 20, true, $txt, 'R', $w - 16);
    $pdf->text($m, $y + 42, $o['nota_preco'], 8.5, false, $sub, 'R', $w - 16);

    $ly = $y + 42;
    foreach ($descLines as $l) {
        $pdf->text($m + 16, $ly, $l, 9.5, false, $sub);
        $ly += 12.5;
    }
    $ly += 3;
    foreach ($o['itens'] as $item) {
        $pdf->text($m + 16, $ly, '•', 10, true, $dest ? '#FFFFFF' : ROXO);
        $pdf->text($m + 28, $ly, $item, 10, false, $txt);
        $ly += 13.5;
    }
    $y += $h + 9;
}

// Como funciona
$y += 10;
$pdf->text($m, $y, 'Como funciona', 13, true, PRETO);
$y += 18;
$passos = [
    'Combinamos o melhor horário e eu vou até o seu comércio instalar a plaquinha.',
    'No Google Completo, eu tiro as fotos no local e otimizo o perfil. Você só aprova um acesso de gerente pelo próprio Google, sem passar senha.',
    'Com o cliente satisfeito, é só pedir: ele aproxima o celular e avalia em segundos.',
];
foreach ($passos as $i => $passo) {
    $pdf->rect($m, $y - 11, 16, 16, ROXO);
    $pdf->text($m, $y + 0.5, (string)($i + 1), 9, true, '#FFFFFF', 'C', 16);
    $y = $pdf->paragraph($m + 26, $y, $w - 26, $passo, 10, false, PRETO) + 4;
}

// Garantias
$y += 4;
$pdf->text($m, $y, 'Garantias', 13, true, PRETO);
$y += 18;
$garantias = [
    'Plaquinha avulsa: você paga só quando ela estiver na sua mão.',
    'Defeito: se a placa parar de funcionar, a troca é sem custo.',
    'Fotos: se não gostar, eu refaço uma vez.',
    'Acesso ao perfil: pelo próprio Google, sem senha, e você pode remover quando quiser.',
];
foreach ($garantias as $g) {
    $pdf->text($m, $y, '•', 10, true, ROXO);
    $y = $pdf->paragraph($m + 12, $y, $w - 12, $g, 10, false, PRETO) + 1;
}
$y += 4;
$pdf->paragraph($m, $y, $w, 'Importante: ninguém pode prometer primeiro lugar no Google. O que eu entrego é o perfil completo e as avaliações entrando todo mês, que é o que faz o cliente escolher você.', 9, false, CINZA);

// Rodapé
$pdf->rect(0, SimplePdf::H - 54, SimplePdf::W, 54, PRETO);
$contato = implode('   ·   ', array_filter([$whats !== '' ? 'WhatsApp ' . $whats : '', $insta, $cidade]));
$pdf->text(0, SimplePdf::H - 22, $contato !== '' ? $contato : $nome, 10, true, '#FFFFFF', 'C', SimplePdf::W);

$bytes = $pdf->output('Ofertas · ' . $nome);
$arquivo = 'ofertas-google-completo-plaquinha.pdf';
header('Content-Type: application/pdf');
header('Content-Length: ' . strlen($bytes));
header('Content-Disposition: ' . (get('download') === '1' ? 'attachment' : 'inline') . '; filename="' . $arquivo . '"');
header('Cache-Control: private, no-store');
echo $bytes;
