<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';

if (current_user_id() > 0) {
    redirect('index.php');
}

$erro = null;
$usuario = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = post('usuario');
    $erro = attempt_login($usuario, (string)($_POST['senha'] ?? ''));
    if ($erro === null) {
        $next = get('next');
        // Só aceita caminho relativo interno, para não virar redirecionamento aberto.
        $ok = $next !== '' && preg_match('#^/?[A-Za-z0-9_\-./]*\.php(\?[^\s<>"\']*)?$#', $next) && !str_contains($next, '//');
        redirect($ok ? $next : 'index.php');
    }
}
$flashes = take_flashes();
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>Entrar · Placas NFC</title>
<link rel="icon" href="assets/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="assets/vendor/bootstrap/bootstrap.min.css">
<link rel="stylesheet" href="assets/app.css?v=<?= APP_VERSION ?>">
</head>
<body class="login-wrap">
<div class="card login-card">
  <div class="card-body p-4">
    <div class="d-flex align-items-center gap-2 mb-4">
      <span class="brand-mark">
        <svg width="18" height="18" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M3.05 3.05a7 7 0 0 0 0 9.9.5.5 0 0 1-.707.707 8 8 0 0 1 0-11.314.5.5 0 0 1 .707.707m2.122 2.122a4 4 0 0 0 0 5.656.5.5 0 1 1-.708.708 5 5 0 0 1 0-7.072.5.5 0 0 1 .708.708m5.656-.708a.5.5 0 0 1 .708 0 5 5 0 0 1 0 7.072.5.5 0 1 1-.708-.708 4 4 0 0 0 0-5.656.5.5 0 0 1 0-.708m2.122-2.12a.5.5 0 0 1 .707 0 8 8 0 0 1 0 11.313.5.5 0 0 1-.707-.707 7 7 0 0 0 0-9.9.5.5 0 0 1 0-.707zM6 8a2 2 0 1 1 2.5 1.937V15.5a.5.5 0 0 1-1 0V9.937A2 2 0 0 1 6 8"/></svg>
      </span>
      <div>
        <div class="fw-semibold">Placas NFC</div>
        <div class="small text-secondary">Painel de gestão</div>
      </div>
    </div>
    <?php foreach ($flashes as $f): ?>
      <div class="alert alert-<?= h($f['type']) ?> py-2"><?= h($f['msg']) ?></div>
    <?php endforeach; ?>
    <?php if ($erro): ?>
      <div class="alert alert-danger py-2"><?= h($erro) ?></div>
    <?php endif; ?>
    <form method="post" novalidate>
      <?= csrf_field() ?>
      <div class="mb-3">
        <label class="form-label" for="usuario">Usuário</label>
        <input class="form-control" id="usuario" name="usuario" value="<?= h($usuario) ?>" autocomplete="username" required autofocus>
      </div>
      <div class="mb-4">
        <label class="form-label" for="senha">Senha</label>
        <input class="form-control" id="senha" type="password" name="senha" autocomplete="current-password" required>
      </div>
      <button class="btn btn-primary w-100" type="submit">Entrar</button>
    </form>
  </div>
</div>
</body>
</html>
