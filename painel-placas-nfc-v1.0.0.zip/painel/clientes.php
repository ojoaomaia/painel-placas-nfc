<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && post('acao') === 'criar') {
    $nome = post('nome');
    if ($nome === '') {
        flash('danger', 'Informe o nome do comércio.');
        redirect('clientes.php?novo=1');
    }
    $origem = array_key_exists(post('origem'), ORIGENS) ? post('origem') : 'outro';
    q('INSERT INTO clientes (nome, nicho, bairro, whatsapp, origem, link_google, observacoes) VALUES (?,?,?,?,?,?,?)',
        [mb_substr($nome, 0, 120), mb_substr(post('nicho'), 0, 60), mb_substr(post('bairro'), 0, 80), mb_substr(post('whatsapp'), 0, 30), $origem, clean_url(post('link_google')), post('observacoes')]);
    $cid = (int)db()->lastInsertId();
    flash('success', "Cliente {$nome} cadastrado.");
    redirect('cliente.php?id=' . $cid);
}

$busca = get('q');
$params = [];
$where = '';
if ($busca !== '') {
    $where = 'WHERE c.nome LIKE ? OR c.bairro LIKE ? OR c.nicho LIKE ? OR c.whatsapp LIKE ?';
    $params = array_fill(0, 4, "%$busca%");
}
$clientes = q_all("SELECT c.*,
        (SELECT COUNT(*) FROM placas p WHERE p.cliente_id = c.id AND p.status IN ('vendida','instalada')) AS placas,
        (SELECT COALESCE(SUM(v.valor),0) FROM vendas v WHERE v.cliente_id = c.id) AS total_vendas,
        (SELECT GROUP_CONCAT(DISTINCT v.tipo) FROM vendas v WHERE v.cliente_id = c.id) AS tipos,
        (SELECT a.valor FROM assinaturas a WHERE a.cliente_id = c.id AND a.status = 'ativa' LIMIT 1) AS mensalidade
    FROM clientes c $where ORDER BY c.nome", $params);
$nichos = array_column(q_all("SELECT DISTINCT nicho FROM clientes WHERE nicho <> '' ORDER BY nicho"), 'nicho');
$abrir = get('novo') === '1';

layout_header('Clientes', 'clientes');
page_title('Clientes', count($clientes) . ' comércio(s) cadastrados.',
    '<button class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#novoCliente"><i class="bi bi-plus-lg me-1"></i>Novo cliente</button>');
?>
<div class="collapse<?= $abrir ? ' show' : '' ?> mb-4" id="novoCliente">
  <div class="card"><div class="card-header">Novo cliente</div><div class="card-body">
    <form method="post" class="row g-3">
      <?= csrf_field() ?><input type="hidden" name="acao" value="criar">
      <div class="col-md-6"><label class="form-label">Nome do comércio</label><input class="form-control" name="nome" required maxlength="120"></div>
      <div class="col-6 col-md-3"><label class="form-label">Nicho</label><input class="form-control" name="nicho" list="nichos" placeholder="Barbearia"><datalist id="nichos"><?php foreach (array_unique(array_merge($nichos, ['Barbearia', 'Salão de beleza', 'Restaurante', 'Lanchonete', 'Pizzaria', 'Bar', 'Oficina', 'Pet shop', 'Clínica', 'Academia'])) as $n): ?><option value="<?= h($n) ?>"><?php endforeach; ?></datalist></div>
      <div class="col-6 col-md-3"><label class="form-label">Bairro</label><input class="form-control" name="bairro"></div>
      <div class="col-6 col-md-3"><label class="form-label">WhatsApp</label><input class="form-control" name="whatsapp" inputmode="tel" placeholder="(16) 99999-9999"></div>
      <div class="col-6 col-md-3"><label class="form-label">Origem do lead</label><select class="form-select" name="origem"><?= options(ORIGENS, 'porta_a_porta') ?></select></div>
      <div class="col-md-6"><label class="form-label">Link do perfil no Google <span class="text-secondary small">(opcional)</span></label><input class="form-control" name="link_google" type="url" placeholder="https://maps.app.goo.gl/..."></div>
      <div class="col-12"><label class="form-label">Observações</label><textarea class="form-control" name="observacoes" rows="2"></textarea></div>
      <div class="col-12"><button class="btn btn-primary">Cadastrar cliente</button></div>
    </form>
  </div></div>
</div>

<form class="row g-2 mb-3" method="get">
  <div class="col-sm-8 col-md-5"><input class="form-control" name="q" value="<?= h($busca) ?>" placeholder="Nome, bairro, nicho ou WhatsApp"></div>
  <div class="col-sm-4 col-md-2"><button class="btn btn-dark w-100">Buscar</button></div>
</form>

<div class="card">
  <?php if (!$clientes): ?>
    <div class="empty">Nenhum cliente encontrado.</div>
  <?php else: ?>
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead><tr><th>Comércio</th><th>Nicho</th><th>Bairro</th><th>Origem</th><th>Ofertas</th><th class="text-end">Placas</th><th class="text-end">Vendido</th><th>Assinatura</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($clientes as $c): ?>
        <tr>
          <td><a class="fw-semibold" href="cliente.php?id=<?= $c['id'] ?>"><?= h($c['nome']) ?></a></td>
          <td class="small"><?= h($c['nicho'] ?: '-') ?></td>
          <td class="small"><?= h($c['bairro'] ?: '-') ?></td>
          <td class="small"><?= h(origem_label($c['origem'])) ?></td>
          <td class="small"><?= $c['tipos'] ? h(implode(', ', array_map('tipo_venda_label', explode(',', $c['tipos'])))) : '<span class="text-secondary">sem venda</span>' ?></td>
          <td class="text-end"><?= (int)$c['placas'] ?></td>
          <td class="text-end"><?= money($c['total_vendas']) ?></td>
          <td><?= $c['mensalidade'] !== null ? '<span class="badge bg-roxo">' . money($c['mensalidade']) . '/mês</span>' : '<span class="text-secondary small">-</span>' ?></td>
          <td class="text-end"><?php if ($w = whatsapp_link($c['whatsapp'])): ?><a class="btn btn-sm btn-outline-success" href="<?= h($w) ?>" target="_blank" rel="noopener noreferrer" title="Abrir WhatsApp"><i class="bi bi-whatsapp"></i></a><?php endif; ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php layout_footer();
