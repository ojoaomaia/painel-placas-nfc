<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = post('acao');
    $id = post_int('id');
    $clienteId = post_int('cliente_id') ?: (int)q_val('SELECT cliente_id FROM assinaturas WHERE id = ?', [$id]);
    try {
        switch ($acao) {
            case 'criar':
                $id = criar_assinatura($clienteId, parse_money(post('valor')), post('data_inicio'), post('observacoes'));
                flash('success', 'Assinatura iniciada. O primeiro relatório fica previsto para daqui a 1 mês.');
                break;
            case 'valor':
                $valor = parse_money(post('valor'));
                if ($valor <= 0) {
                    throw new DomainException('Valor inválido.');
                }
                q('UPDATE assinaturas SET valor = ?, observacoes = ? WHERE id = ?', [$valor, post('observacoes'), $id]);
                flash('success', 'Assinatura atualizada.');
                break;
            case 'proximo':
                if (!$d = valid_date(post('proximo_relatorio'))) {
                    throw new DomainException('Data inválida.');
                }
                q('UPDATE assinaturas SET proximo_relatorio = ? WHERE id = ?', [$d, $id]);
                flash('success', 'Data do próximo relatório ajustada.');
                break;
            case 'relatorio':
                registrar_relatorio($id, post('data', today()), post('observacoes'));
                flash('success', 'Relatório marcado como enviado. Próximo previsto para ' . date_br((string)q_val('SELECT proximo_relatorio FROM assinaturas WHERE id = ?', [$id])) . '.');
                break;
            case 'pagamento':
                registrar_pagamento_assinatura($id, parse_money(post('valor')), post('data', today()), post('forma_pagamento', 'pix'), post('referencia'));
                flash('success', 'Pagamento da mensalidade registrado.');
                break;
            case 'excluir_pagamento':
                q('DELETE FROM pagamentos_assinatura WHERE id = ? AND assinatura_id = ?', [post_int('pagamento_id'), $id]);
                flash('success', 'Pagamento excluído.');
                break;
            case 'encerrar':
                encerrar_assinatura($id, post('data_fim', today()));
                flash('success', 'Assinatura encerrada. O histórico fica guardado na ficha do cliente.');
                break;
        }
    } catch (DomainException $e) {
        flash('danger', $e->getMessage());
    }
    if (post('volta') === 'cliente' && $clienteId) {
        redirect('cliente.php?id=' . $clienteId . '#assinatura');
    }
    redirect($id ? 'assinaturas.php?id=' . $id : 'assinaturas.php');
}

$id = get_int('id');
if ($id) {
    $a = q_one('SELECT a.*, c.nome AS cliente, c.whatsapp FROM assinaturas a JOIN clientes c ON c.id = a.cliente_id WHERE a.id = ?', [$id]);
    if (!$a) {
        not_found('Assinatura não encontrada.');
    }
    $relatorios = q_all('SELECT * FROM relatorios_enviados WHERE assinatura_id = ? ORDER BY referencia DESC', [$id]);
    $pagamentos = q_all('SELECT * FROM pagamentos_assinatura WHERE assinatura_id = ? ORDER BY data_pagamento DESC', [$id]);
    $ativa = $a['status'] === 'ativa';

    layout_header('Assinatura · ' . $a['cliente'], 'assinaturas');
    page_title('Assinatura · ' . $a['cliente'],
        ($ativa ? '<span class="badge bg-roxo">Ativa</span>' : '<span class="badge text-bg-secondary">Encerrada em ' . date_br($a['data_fim']) . '</span>') . ' · ' . money($a['valor']) . '/mês desde ' . date_br($a['data_inicio']),
        '<a class="btn btn-outline-dark" href="cliente.php?id=' . $a['cliente_id'] . '">Ficha do cliente</a>');
    ?>
    <div class="row g-4">
      <div class="col-lg-6">
        <?php if ($ativa): ?>
        <div class="card mb-4 border-primary"><div class="card-header bg-roxo">Relatório mensal</div><div class="card-body">
          <p class="mb-3">Próximo previsto: <strong class="<?= $a['proximo_relatorio'] < today() ? 'text-danger' : '' ?>"><?= date_br($a['proximo_relatorio']) ?></strong>
            <?php if ($a['proximo_relatorio'] < today()): ?><span class="badge text-bg-danger ms-1">atrasado <?= days_between($a['proximo_relatorio'], today()) ?> dia(s)</span><?php endif; ?></p>
          <form method="post" class="row g-2 align-items-end mb-3">
            <?= csrf_field() ?><input type="hidden" name="acao" value="relatorio"><input type="hidden" name="id" value="<?= $id ?>">
            <div class="col-sm-4"><label class="form-label small">Enviado em</label><input type="date" class="form-control" name="data" value="<?= today() ?>" required></div>
            <div class="col-sm-8"><label class="form-label small">Observação</label><input class="form-control" name="observacoes" placeholder="Ex.: +8 avaliações, 23 scans"></div>
            <div class="col-12"><button class="btn btn-primary">Marcar relatório como enviado</button></div>
          </form>
          <form method="post" class="row g-2 align-items-end">
            <?= csrf_field() ?><input type="hidden" name="acao" value="proximo"><input type="hidden" name="id" value="<?= $id ?>">
            <div class="col-sm-6"><label class="form-label small">Ajustar data do próximo</label><input type="date" class="form-control form-control-sm" name="proximo_relatorio" value="<?= h($a['proximo_relatorio']) ?>"></div>
            <div class="col-sm-6"><button class="btn btn-sm btn-outline-secondary">Ajustar</button></div>
          </form>
        </div></div>
        <?php endif; ?>

        <div class="card mb-4"><div class="card-header">Relatórios enviados</div>
          <?php if (!$relatorios): ?><div class="empty">Nenhum relatório enviado ainda.</div><?php else: ?>
          <ul class="list-group list-group-flush"><?php foreach ($relatorios as $r): ?>
            <li class="list-group-item d-flex justify-content-between"><span>Ref. <?= date_br($r['referencia']) ?><?= $r['observacoes'] ? ' · <span class="text-secondary small">' . h($r['observacoes']) . '</span>' : '' ?></span><span class="small text-secondary">enviado <?= date_br($r['enviado_em']) ?></span></li>
          <?php endforeach; ?></ul>
          <?php endif; ?>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="card mb-4"><div class="card-header">Pagamentos da mensalidade</div><div class="card-body">
          <form method="post" class="row g-2 align-items-end">
            <?= csrf_field() ?><input type="hidden" name="acao" value="pagamento"><input type="hidden" name="id" value="<?= $id ?>">
            <div class="col-6 col-md-3"><label class="form-label small">Valor</label><input class="form-control" name="valor" value="<?= number_format((float)$a['valor'], 2, ',', '') ?>" required></div>
            <div class="col-6 col-md-3"><label class="form-label small">Data</label><input type="date" class="form-control" name="data" value="<?= today() ?>" required></div>
            <div class="col-6 col-md-3"><label class="form-label small">Forma</label><select class="form-select" name="forma_pagamento"><?= options(FORMAS_PAGAMENTO, 'pix') ?></select></div>
            <div class="col-6 col-md-3"><label class="form-label small">Mês ref.</label><input type="month" class="form-control" name="referencia" value="<?= date('Y-m') ?>"></div>
            <div class="col-12"><button class="btn btn-outline-success">Registrar pagamento</button></div>
          </form>
        </div>
          <?php if ($pagamentos): ?>
          <div class="table-responsive"><table class="table align-middle mb-0">
            <thead><tr><th>Data</th><th>Ref.</th><th>Forma</th><th class="text-end">Valor</th><th></th></tr></thead>
            <tbody><?php foreach ($pagamentos as $pg): ?>
              <tr><td><?= date_br($pg['data_pagamento']) ?></td><td><?= h($pg['referencia'] ?: '-') ?></td><td><?= h(pagamento_label($pg['forma_pagamento'])) ?></td><td class="text-end"><?= money($pg['valor']) ?></td>
                <td class="text-end"><form method="post" data-confirm="Excluir este pagamento?"><?= csrf_field() ?><input type="hidden" name="acao" value="excluir_pagamento"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="pagamento_id" value="<?= $pg['id'] ?>"><button class="btn btn-sm btn-link text-danger p-0"><i class="bi bi-x-circle"></i></button></form></td></tr>
            <?php endforeach; ?></tbody>
            <tfoot><tr><th colspan="3" class="text-end">Total recebido</th><th class="text-end"><?= money(array_sum(array_column($pagamentos, 'valor'))) ?></th><th></th></tr></tfoot>
          </table></div>
          <?php endif; ?>
        </div>

        <?php if ($ativa): ?>
        <div class="card mb-4"><div class="card-header">Valor e encerramento</div><div class="card-body">
          <form method="post" class="row g-2 mb-3">
            <?= csrf_field() ?><input type="hidden" name="acao" value="valor"><input type="hidden" name="id" value="<?= $id ?>">
            <div class="col-5"><label class="form-label small">Mensalidade</label><input class="form-control" name="valor" value="<?= number_format((float)$a['valor'], 2, ',', '') ?>" required></div>
            <div class="col-7"><label class="form-label small">Observação</label><input class="form-control" name="observacoes" value="<?= h($a['observacoes']) ?>"></div>
            <div class="col-12"><button class="btn btn-sm btn-outline-primary">Salvar</button></div>
          </form>
          <form method="post" class="row g-2 align-items-end" data-confirm="Encerrar esta assinatura?">
            <?= csrf_field() ?><input type="hidden" name="acao" value="encerrar"><input type="hidden" name="id" value="<?= $id ?>">
            <div class="col-7"><label class="form-label small">Encerrar em</label><input type="date" class="form-control" name="data_fim" value="<?= today() ?>"></div>
            <div class="col-5"><button class="btn btn-outline-danger w-100">Encerrar</button></div>
          </form>
        </div></div>
        <?php endif; ?>
      </div>
    </div>
    <?php
    layout_footer();
    exit;
}

$filtro = get('status', 'ativa');
$lista = q_all('SELECT a.*, c.nome AS cliente,
        (SELECT MAX(data_pagamento) FROM pagamentos_assinatura p WHERE p.assinatura_id = a.id) AS ult_pag
    FROM assinaturas a JOIN clientes c ON c.id = a.cliente_id'
    . ($filtro === 'todas' ? '' : ' WHERE a.status = ?') . ' ORDER BY a.status, a.proximo_relatorio', $filtro === 'todas' ? [] : [$filtro === 'inativa' ? 'inativa' : 'ativa']);
$mrr = (float)q_val("SELECT COALESCE(SUM(valor),0) FROM assinaturas WHERE status = 'ativa'");
$nAtivas = (int)q_val("SELECT COUNT(*) FROM assinaturas WHERE status = 'ativa'");

layout_header('Assinaturas', 'assinaturas');
page_title('Assinaturas', $nAtivas . ' ativa(s) · MRR ' . money($mrr) . ' · mensalidade padrão ' . money(cfg('mensalidade_padrao', '24.90')));
?>
<ul class="nav nav-pills mb-3">
  <?php foreach (['ativa' => 'Ativas', 'inativa' => 'Encerradas', 'todas' => 'Todas'] as $k => $l): ?>
    <li class="nav-item"><a class="nav-link<?= $filtro === $k ? ' active bg-roxo' : '' ?>" href="assinaturas.php?status=<?= $k ?>"><?= $l ?></a></li>
  <?php endforeach; ?>
</ul>
<div class="card">
  <?php if (!$lista): ?><div class="empty">Nenhuma assinatura aqui. Inicie uma pela ficha do cliente.</div><?php else: ?>
  <div class="table-responsive"><table class="table table-hover align-middle mb-0">
    <thead><tr><th>Cliente</th><th>Status</th><th>Início</th><th>Próximo relatório</th><th>Último pagamento</th><th class="text-end">Mensalidade</th></tr></thead>
    <tbody><?php foreach ($lista as $a): $atrasado = $a['status'] === 'ativa' && $a['proximo_relatorio'] < today(); ?>
      <tr>
        <td><a class="fw-semibold" href="assinaturas.php?id=<?= $a['id'] ?>"><?= h($a['cliente']) ?></a></td>
        <td><?= $a['status'] === 'ativa' ? '<span class="badge bg-roxo">Ativa</span>' : '<span class="badge text-bg-secondary">Encerrada</span>' ?></td>
        <td><?= date_br($a['data_inicio']) ?></td>
        <td class="<?= $atrasado ? 'text-danger fw-semibold' : '' ?>"><?= $a['status'] === 'ativa' ? date_br($a['proximo_relatorio']) . ($atrasado ? ' (atrasado)' : '') : '-' ?></td>
        <td><?= date_br($a['ult_pag']) ?></td>
        <td class="text-end"><?= money($a['valor']) ?></td>
      </tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <?php endif; ?>
</div>
<?php layout_footer();
