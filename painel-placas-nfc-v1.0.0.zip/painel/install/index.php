<?php
declare(strict_types=1);

/**
 * Instalador do Painel de Placas NFC.
 * Cria as tabelas, o usuário de acesso e o arquivo app/config.php.
 * Depois de instalar, apague a pasta /install do servidor.
 */

const MIN_PHP = '8.2.0';
$root = dirname(__DIR__);
$configFile = $root . '/app/config.php';
$schemaFile = $root . '/app/schema.sql';

date_default_timezone_set('America/Sao_Paulo');
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

session_name('PNF_INSTALL');
session_start();
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function e(mixed $v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';

$checks = [
    ['PHP ' . MIN_PHP . ' ou superior (atual: ' . PHP_VERSION . ')', version_compare(PHP_VERSION, MIN_PHP, '>=')],
    ['Extensão pdo_mysql', extension_loaded('pdo_mysql')],
    ['Extensão mbstring', extension_loaded('mbstring')],
    ['Pasta app/ com permissão de escrita', is_writable($root . '/app')],
    ['Pasta uploads/ com permissão de escrita', is_writable($root . '/uploads')],
    ['Arquivo app/schema.sql presente', is_file($schemaFile)],
];
$checksOk = !in_array(false, array_column($checks, 1), true);
$installed = is_file($configFile);

$errors = [];
$done = false;
$v = [
    'db_host' => 'localhost', 'db_port' => '3306', 'db_name' => '', 'db_user' => '',
    'usuario' => 'joao', 'force_https' => $isHttps ? '1' : '',
];

if (!$installed && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'], (string)($_POST['_csrf'] ?? ''))) {
        $errors[] = 'Sessão expirada. Recarregue a página.';
    }
    foreach ($v as $k => $_) {
        $v[$k] = trim((string)($_POST[$k] ?? ''));
    }
    $dbPass = (string)($_POST['db_pass'] ?? '');
    $senha = (string)($_POST['senha'] ?? '');
    $senha2 = (string)($_POST['senha2'] ?? '');

    if (!$checksOk) {
        $errors[] = 'Corrija os requisitos do servidor antes de instalar.';
    }
    if ($v['db_name'] === '' || $v['db_user'] === '') {
        $errors[] = 'Informe nome e usuário do banco de dados.';
    }
    if (!preg_match('/^[A-Za-z0-9_.@-]{3,60}$/', $v['usuario'])) {
        $errors[] = 'Usuário de acesso: 3 a 60 caracteres, sem espaços.';
    }
    if (mb_strlen($senha) < 10 || !preg_match('/[A-Za-z]/', $senha) || !preg_match('/\d/', $senha)) {
        $errors[] = 'A senha de acesso precisa ter pelo menos 10 caracteres, com letras e números.';
    }
    if ($senha !== $senha2) {
        $errors[] = 'As senhas não conferem.';
    }

    if (!$errors) {
        try {
            $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $v['db_host'], (int)$v['db_port'], $v['db_name']);
            $pdo = new PDO($dsn, $v['db_user'], $dbPass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            if ($pdo->query("SHOW TABLES LIKE 'usuarios'")->fetch()) {
                throw new RuntimeException('Esse banco já tem as tabelas do painel. Use um banco vazio ou restaure o app/config.php anterior.');
            }
            $sql = (string)file_get_contents($schemaFile);
            $sql = preg_replace('/^--.*$/m', '', $sql) ?? '';
            foreach (preg_split('/;\s*\n/', $sql) ?: [] as $stmt) {
                if (trim($stmt) !== '') {
                    $pdo->exec($stmt);
                }
            }
            $algo = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
            $st = $pdo->prepare('INSERT INTO usuarios (usuario, senha_hash) VALUES (?, ?)');
            $st->execute([$v['usuario'], password_hash($senha, $algo)]);

            $config = [
                'db' => [
                    'host' => $v['db_host'],
                    'port' => (int)$v['db_port'],
                    'name' => $v['db_name'],
                    'user' => $v['db_user'],
                    'pass' => $dbPass,
                ],
                'force_https' => $v['force_https'] === '1',
                'session_idle_min' => 60,
                'session_max_horas' => 12,
                'debug' => false,
                'installed_at' => date('c'),
            ];
            $php = "<?php\n// Gerado pelo instalador em " . date('d/m/Y H:i') . ". Não compartilhe este arquivo.\nreturn " . var_export($config, true) . ";\n";
            if (file_put_contents($configFile, $php, LOCK_EX) === false) {
                throw new RuntimeException('Não foi possível gravar app/config.php. Verifique as permissões da pasta app/.');
            }
            @chmod($configFile, 0640);
            $done = true;
            $installed = true;
        } catch (PDOException $ex) {
            $errors[] = 'Erro no banco de dados: ' . $ex->getMessage();
        } catch (Throwable $ex) {
            $errors[] = $ex->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>Instalação · Painel de Placas NFC</title>
<link rel="stylesheet" href="../assets/vendor/bootstrap/bootstrap.min.css">
<link rel="stylesheet" href="../assets/app.css">
</head>
<body class="login-wrap">
<div class="card login-card" style="max-width:560px">
  <div class="card-body p-4">
    <h1 class="h4 mb-1">Instalação do painel</h1>
    <p class="text-secondary mb-4">Placas NFC · gestão de estoque, vendas e clientes</p>

    <?php if ($done): ?>
      <div class="alert alert-success">Instalação concluída. O usuário <strong><?= e($v['usuario']) ?></strong> foi criado.</div>
      <div class="alert alert-warning"><strong>Importante:</strong> apague a pasta <code>install/</code> do servidor pelo Gerenciador de Arquivos da Hostinger antes de usar o painel.</div>
      <a class="btn btn-primary w-100" href="../login.php">Ir para o login</a>
    <?php elseif ($installed): ?>
      <div class="alert alert-info">O painel já está instalado. Por segurança, apague a pasta <code>install/</code> do servidor.</div>
      <a class="btn btn-primary w-100" href="../login.php">Ir para o login</a>
    <?php else: ?>
      <ul class="list-unstyled small mb-4">
        <?php foreach ($checks as [$label, $ok]): ?>
          <li class="<?= $ok ? 'text-success' : 'text-danger fw-semibold' ?>"><?= $ok ? '✓' : '✗' ?> <?= e($label) ?></li>
        <?php endforeach; ?>
      </ul>
      <?php foreach ($errors as $err): ?>
        <div class="alert alert-danger py-2"><?= e($err) ?></div>
      <?php endforeach; ?>
      <form method="post" autocomplete="off">
        <input type="hidden" name="_csrf" value="<?= e($_SESSION['csrf']) ?>">
        <h2 class="h6 text-uppercase text-secondary">Banco de dados MySQL</h2>
        <div class="row g-2 mb-2">
          <div class="col-8"><label class="form-label small">Servidor</label><input class="form-control" name="db_host" value="<?= e($v['db_host']) ?>" required></div>
          <div class="col-4"><label class="form-label small">Porta</label><input class="form-control" name="db_port" value="<?= e($v['db_port']) ?>" inputmode="numeric" required></div>
        </div>
        <div class="mb-2"><label class="form-label small">Nome do banco</label><input class="form-control" name="db_name" value="<?= e($v['db_name']) ?>" placeholder="u123456789_placas" required></div>
        <div class="mb-2"><label class="form-label small">Usuário do banco</label><input class="form-control" name="db_user" value="<?= e($v['db_user']) ?>" placeholder="u123456789_joao" required></div>
        <div class="mb-4"><label class="form-label small">Senha do banco</label><input class="form-control" type="password" name="db_pass"></div>

        <h2 class="h6 text-uppercase text-secondary">Seu acesso ao painel</h2>
        <div class="mb-2"><label class="form-label small">Usuário</label><input class="form-control" name="usuario" value="<?= e($v['usuario']) ?>" required></div>
        <div class="row g-2 mb-2">
          <div class="col-sm-6"><label class="form-label small">Senha (mín. 10, letras e números)</label><input class="form-control" type="password" name="senha" minlength="10" required></div>
          <div class="col-sm-6"><label class="form-label small">Repita a senha</label><input class="form-control" type="password" name="senha2" minlength="10" required></div>
        </div>
        <div class="form-check mb-4">
          <input class="form-check-input" type="checkbox" name="force_https" value="1" id="fh" <?= $v['force_https'] === '1' ? 'checked' : '' ?>>
          <label class="form-check-label small" for="fh">Forçar HTTPS (deixe marcado na Hostinger com SSL ativo)</label>
        </div>
        <button class="btn btn-primary w-100" <?= $checksOk ? '' : 'disabled' ?>>Instalar</button>
      </form>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
