<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = post('acao');
    try {
        if ($acao === 'precos') {
            foreach (['preco_avulsa', 'preco_combo', 'preco_kit2', 'preco_upgrade_combo', 'mensalidade_padrao'] as $k) {
                $v = parse_money(post($k));
                if ($v <= 0) {
                    throw new DomainException('Todos os preços precisam ser maiores que zero.');
                }
                cfg_set($k, number_format($v, 2, '.', ''));
            }
            flash('success', 'Preços salvos. Vendas e assinaturas já registradas mantêm o valor original.');
        } elseif ($acao === 'geral') {
            $url = post('placason_url');
            if (!preg_match('#^https?://[^\s"\'<>]+$#i', $url)) {
                throw new DomainException('Endereço da PlacasOn inválido. Use um link começando com https://');
            }
            cfg_set('placason_url', mb_substr($url, 0, 255));
            foreach (['nome_comercial' => 80, 'whatsapp_contato' => 30, 'instagram_contato' => 60, 'cidade' => 60] as $k => $len) {
                cfg_set($k, mb_substr(post($k), 0, $len));
            }
            flash('success', 'Configurações salvas.');
        } elseif ($acao === 'modelos') {
            foreach ((array)($_POST['modelo'] ?? []) as $mid => $dados) {
                if (!is_array($dados)) {
                    continue;
                }
                $nome = trim((string)($dados['nome'] ?? ''));
                if ($nome === '') {
                    continue;
                }
                q('UPDATE modelos SET nome = ?, estoque_minimo = ?, ativo = ? WHERE id = ?',
                    [mb_substr($nome, 0, 80), max(0, (int)($dados['minimo'] ?? 0)), !empty($dados['ativo']) ? 1 : 0, (int)$mid]);
            }
            if (post('novo_nome') !== '') {
                $tipo = post('novo_tipo') === 'instagram' ? 'instagram' : 'google';
                $ordem = (int)q_val('SELECT COALESCE(MAX(ordem), 0) + 1 FROM modelos');
                q('INSERT INTO modelos (nome, tipo, cor, estoque_minimo, ordem) VALUES (?,?,?,?,?)',
                    [mb_substr(post('novo_nome'), 0, 80), $tipo, mb_substr(post('novo_cor') ?: 'preto', 0, 30), max(0, (int)post('novo_minimo', '2')), $ordem]);
            }
            flash('success', 'Modelos atualizados.');
        } elseif ($acao === 'senha') {
            $u = q_one('SELECT * FROM usuarios WHERE id = ?', [current_user_id()]);
            if (!$u || !password_verify((string)($_POST['senha_atual'] ?? ''), $u['senha_hash'])) {
                throw new DomainException('Senha atual incorreta.');
            }
            $nova = (string)($_POST['senha_nova'] ?? '');
            if ($err = senha_fraca($nova)) {
                throw new DomainException($err);
            }
            if ($nova !== (string)($_POST['senha_conf'] ?? '')) {
                throw new DomainException('A confirmação não confere com a nova senha.');
            }
            q('UPDATE usuarios SET senha_hash = ? WHERE id = ?', [hash_password($nova), $u['id']]);
            session_regenerate_id(true);
            flash('success', 'Senha alterada.');
        }
    } catch (DomainException $e) {
        flash('danger', $e->getMessage());
    }
    redirect('configuracoes.php');
}

$modelos = q_all('SELECT * FROM modelos ORDER BY ordem, nome');
$money = fn(string $k, string $d) => number_format((float)cfg($k, $d), 2, ',', '');

layout_header('Configurações', 'config');
page_title('Configurações');
?>
<div class="row g-4">
  <div class="col-lg-6">
    <div class="card mb-4"><div class="card-header">Preços padrão</div><div class="card-body">
      <form method="post" class="row g-3">
        <?= csrf_field() ?><input type="hidden" name="acao" value="precos">
        <?php foreach (['preco_combo' => ['Google Completo', '250'], 'preco_avulsa' => ['Plaquinha avulsa', '80'], 'preco_kit2' => ['Kit 2 Plaquinhas', '140'], 'preco_upgrade_combo' => ['Upgrade avulsa para combo', '170'], 'mensalidade_padrao' => ['Mensalidade padrão', '24.90']] as $k => [$label, $def]): ?>
          <div class="col-6"><label class="form-label small"><?= h($label) ?></label><div class="input-group"><span class="input-group-text">R$</span><input class="form-control" name="<?= $k ?>" value="<?= $money($k, $def) ?>" inputmode="decimal" required></div></div>
        <?php endforeach; ?>
        <div class="col-12"><button class="btn btn-primary">Salvar preços</button></div>
      </form>
    </div></div>

    <div class="card mb-4"><div class="card-header">Dados comerciais e PlacasOn</div><div class="card-body">
      <form method="post" class="row g-3">
        <?= csrf_field() ?><input type="hidden" name="acao" value="geral">
        <div class="col-12"><label class="form-label small">Nome comercial (aparece no card e no PDF)</label><input class="form-control" name="nome_comercial" value="<?= h(cfg('nome_comercial')) ?>"></div>
        <div class="col-6"><label class="form-label small">WhatsApp de contato</label><input class="form-control" name="whatsapp_contato" value="<?= h(cfg('whatsapp_contato')) ?>" placeholder="(16) 99999-9999"></div>
        <div class="col-6"><label class="form-label small">Instagram</label><input class="form-control" name="instagram_contato" value="<?= h(cfg('instagram_contato')) ?>" placeholder="@seuinstagram"></div>
        <div class="col-12"><label class="form-label small">Cidade</label><input class="form-control" name="cidade" value="<?= h(cfg('cidade')) ?>"></div>
        <div class="col-12"><label class="form-label small">Endereço do painel de scans da PlacasOn</label><input class="form-control font-monospace" name="placason_url" value="<?= h(cfg('placason_url')) ?>">
          <div class="form-text">Se o painel da PlacasOn tiver um endereço por placa, use <code>{id}</code> no lugar do código (ex.: <code>https://placason.com.br/cliente/placa/{id}</code>). Sem <code>{id}</code>, o botão abre o painel geral.</div></div>
        <div class="col-12"><button class="btn btn-primary">Salvar</button></div>
      </form>
    </div></div>
  </div>

  <div class="col-lg-6">
    <div class="card mb-4" id="modelos"><div class="card-header">Modelos de placa e estoque mínimo</div><div class="card-body">
      <form method="post">
        <?= csrf_field() ?><input type="hidden" name="acao" value="modelos">
        <div class="table-responsive"><table class="table table-sm align-middle">
          <thead><tr><th>Nome</th><th style="width:90px">Mínimo</th><th style="width:60px">Ativo</th></tr></thead>
          <tbody><?php foreach ($modelos as $m): ?>
            <tr>
              <td><input class="form-control form-control-sm" name="modelo[<?= $m['id'] ?>][nome]" value="<?= h($m['nome']) ?>"></td>
              <td><input type="number" min="0" class="form-control form-control-sm" name="modelo[<?= $m['id'] ?>][minimo]" value="<?= (int)$m['estoque_minimo'] ?>"></td>
              <td class="text-center"><input class="form-check-input" type="checkbox" name="modelo[<?= $m['id'] ?>][ativo]" value="1"<?= $m['ativo'] ? ' checked' : '' ?>></td>
            </tr>
          <?php endforeach; ?></tbody>
        </table></div>
        <div class="row g-2 mb-3">
          <div class="col-12 small text-secondary">Adicionar modelo</div>
          <div class="col-md-5"><input class="form-control form-control-sm" name="novo_nome" placeholder="Ex.: Google Avaliações Rosa"></div>
          <div class="col-4 col-md-3"><select class="form-select form-select-sm" name="novo_tipo"><option value="google">Google</option><option value="instagram">Instagram</option></select></div>
          <div class="col-4 col-md-2"><input class="form-control form-control-sm" name="novo_cor" placeholder="cor"></div>
          <div class="col-4 col-md-2"><input type="number" min="0" class="form-control form-control-sm" name="novo_minimo" value="2"></div>
        </div>
        <button class="btn btn-primary">Salvar modelos</button>
      </form>
    </div></div>

    <div class="card"><div class="card-header">Trocar senha</div><div class="card-body">
      <form method="post" class="row g-2">
        <?= csrf_field() ?><input type="hidden" name="acao" value="senha">
        <div class="col-12"><input class="form-control" type="password" name="senha_atual" placeholder="Senha atual" autocomplete="current-password" required></div>
        <div class="col-6"><input class="form-control" type="password" name="senha_nova" placeholder="Nova senha" autocomplete="new-password" minlength="10" required></div>
        <div class="col-6"><input class="form-control" type="password" name="senha_conf" placeholder="Repita" autocomplete="new-password" minlength="10" required></div>
        <div class="col-12 form-text">Mínimo 10 caracteres, com letras e números.</div>
        <div class="col-12"><button class="btn btn-outline-primary">Alterar senha</button></div>
      </form>
    </div></div>
  </div>
</div>
<?php layout_footer();
