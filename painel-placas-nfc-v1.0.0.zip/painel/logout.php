<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';

// Só aceita POST (com CSRF verificado no bootstrap), para que um link externo não derrube a sessão.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    logout();
    start_secure_session();
    flash('success', 'Você saiu do painel.');
}
redirect('login.php');
