<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require_login();

$precos = precos_padrao();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $vendaId = transaction(function () {
            $clienteId = post_int('cliente_id');
            if (post('cliente_modo') === 'novo') {
                $nome = post('novo_nome');
                if ($nome === '') {
                    throw new DomainException('Informe o nome do novo cliente.');
                }
                $origem = array_key_exists(post('novo_origem'), ORIGENS) ? post('novo_origem') : 'outro';
                q('INSERT INTO clientes (nome, nicho, bairro, whatsapp, origem) VALUES (?,?,?,?,?)',
                    [mb_substr($nome, 0, 120), mb_substr(post('novo_nicho'), 0, 60), mb_substr(post('novo_bairro'), 0, 80), mb_substr(post('novo_whatsapp'), 0, 30), $origem]);
                $clienteId = (int)db()->lastInsertId();
            }
            $tipo = post('tipo');
            $placas = [post_int('placa_1')];
            if ($tipo === 'kit2') {
                $placas[] = post_int('placa_2');
            }
            return registrar_venda($clienteId, $tipo, $placas, parse_money(post('valor')), post('forma_pagamento'), post('data_venda'), post('observacoes'));
        });
        flash('success', 'Venda registrada. Próximo passo: instalar a placa e anotar o marco zero.');
        redirect('venda.php?id=' . $vendaId);
    } catch (DomainException $e) {
        flash('danger', $e->getMessage());
        $_SESSION['venda_form'] = $_POST;
        redirect('venda_nova.php');
    }
}

$old = $_SESSION['venda_form'] ?? [];
unset($_SESSION['venda_form']);
$o = fn(string $k, string $d = '') => is_string($old[$k] ?? null) ? $old[$k] : $d;

$clientes = q_all('SELECT id, nome, bairro FROM clientes ORDER BY nome');
$estoque = q_all("SELECT p.id, p.codigo, m.nome AS modelo FROM placas p JOIN modelos m ON m.id = p.modelo_id WHERE p.status = 'estoque' ORDER BY m.ordem, p.codigo");
$tipo = $o('tipo', in_array(get('tipo'), ['avulsa', 'combo', 'kit2'], true) ? get('tipo') : 'combo');
$clienteSel = $o('cliente_id', (string)get_int('cliente'));
$placaSel = $o('placa_1', (string)get_int('placa'));
$modo = $o('cliente_modo', $clientes ? 'existente' : 'novo');

layout_header('Nova venda', 'vendas');
page_title('Nova venda', 'Vincula placas do estoque a um cliente e registra o pagamento.');

if (!$estoque): ?>
  <div class="alert alert-warning">Não há placas em estoque. <a href="lotes.php?novo=1">Registre um lote</a> antes de vender.</div>
<?php layout_footer(); exit; endif; ?>

<form method="post" id="formVenda" class="row g-4" data-precos='<?= h(json_encode($precos)) ?>'>
  <?= csrf_field() ?>
  <div class="col-lg-7">
    <div class="card mb-4"><div class="card-header">1. Oferta</div><div class="card-body">
      <div class="row g-2">
        <?php foreach (['combo' => ['Google Completo', 'Placa + perfil otimizado + fotos no local'], 'avulsa' => ['Plaquinha avulsa', 'Só a placa NFC + QR'], 'kit2' => ['Kit 2 Plaquinhas', 'Caixa + mesas ou recepção']] as $k => [$label, $desc]): ?>
          <div class="col-md-4">
            <input type="radio" class="btn-check" name="tipo" id="tipo_<?= $k ?>" value="<?= $k ?>"<?= $tipo === $k ? ' checked' : '' ?>>
            <label class="btn btn-outline-primary w-100 h-100 text-start p-3" for="tipo_<?= $k ?>">
              <span class="d-block fw-semibold"><?= $label ?></span>
              <span class="d-block fs-5"><?= money($precos[$k]) ?></span>
              <span class="d-block small opacity-75"><?= $desc ?></span>
            </label>
          </div>
        <?php endforeach; ?>
      </div>
    </div></div>

    <div class="card mb-4"><div class="card-header">2. Cliente</div><div class="card-body">
      <div class="btn-group mb-3" role="group">
        <input type="radio" class="btn-check" name="cliente_modo" id="cm_ex" value="existente"<?= $modo === 'existente' ? ' checked' : '' ?><?= $clientes ? '' : ' disabled' ?>>
        <label class="btn btn-outline-dark btn-sm" for="cm_ex">Cliente cadastrado</label>
        <input type="radio" class="btn-check" name="cliente_modo" id="cm_novo" value="novo"<?= $modo === 'novo' ? ' checked' : '' ?>>
        <label class="btn btn-outline-dark btn-sm" for="cm_novo">Novo cliente</label>
      </div>
      <div data-modo="existente">
        <select class="form-select" name="cliente_id">
          <option value="">Selecione...</option>
          <?php foreach ($clientes as $c): ?><option value="<?= $c['id'] ?>"<?= $clienteSel === (string)$c['id'] ? ' selected' : '' ?>><?= h($c['nome'] . ($c['bairro'] ? ' · ' . $c['bairro'] : '')) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div data-modo="novo" class="row g-2">
        <div class="col-md-6"><input class="form-control" name="novo_nome" value="<?= h($o('novo_nome')) ?>" placeholder="Nome do comércio"></div>
        <div class="col-6 col-md-3"><input class="form-control" name="novo_nicho" value="<?= h($o('novo_nicho')) ?>" placeholder="Nicho"></div>
        <div class="col-6 col-md-3"><input class="form-control" name="novo_bairro" value="<?= h($o('novo_bairro')) ?>" placeholder="Bairro"></div>
        <div class="col-6"><input class="form-control" name="novo_whatsapp" value="<?= h($o('novo_whatsapp')) ?>" placeholder="WhatsApp" inputmode="tel"></div>
        <div class="col-6"><select class="form-select" name="novo_origem"><?= options(ORIGENS, $o('novo_origem', 'porta_a_porta')) ?></select></div>
      </div>
    </div></div>

    <div class="card"><div class="card-header">3. Placa(s) do estoque</div><div class="card-body row g-2">
      <?php foreach ([1, 2] as $n): ?>
        <div class="col-md-6"<?= $n === 2 ? ' data-kit-only' : '' ?>>
          <label class="form-label small text-secondary">Placa <?= $n ?></label>
          <select class="form-select" name="placa_<?= $n ?>">
            <option value="">Selecione...</option>
            <?php $sel = $n === 1 ? $placaSel : $o('placa_2');
            foreach ($estoque as $e): ?><option value="<?= $e['id'] ?>"<?= $sel === (string)$e['id'] ? ' selected' : '' ?>><?= h($e['codigo'] . ' · ' . $e['modelo']) ?></option><?php endforeach; ?>
          </select>
        </div>
      <?php endforeach; ?>
    </div></div>
  </div>

  <div class="col-lg-5">
    <div class="card position-sticky" style="top:80px"><div class="card-header">4. Pagamento</div><div class="card-body">
      <label class="form-label">Valor</label>
      <div class="input-group mb-3"><span class="input-group-text">R$</span><input class="form-control form-control-lg" name="valor" id="valorVenda" value="<?= h($o('valor', number_format($precos[$tipo], 2, ',', ''))) ?>" inputmode="decimal" required></div>
      <label class="form-label">Forma de pagamento</label>
      <select class="form-select mb-3" name="forma_pagamento"><?= options(FORMAS_PAGAMENTO, $o('forma_pagamento', 'pix')) ?></select>
      <label class="form-label">Data da venda</label>
      <input type="date" class="form-control mb-3" name="data_venda" value="<?= h($o('data_venda', today())) ?>" required>
      <label class="form-label">Observações</label>
      <textarea class="form-control mb-3" name="observacoes" rows="2" placeholder="Ex.: metade no Pix agora, metade no dia das fotos"><?= h($o('observacoes')) ?></textarea>
      <button class="btn btn-primary btn-lg w-100"><i class="bi bi-check2-circle me-1"></i>Registrar venda</button>
    </div></div>
  </div>
</form>
<?php layout_footer();
