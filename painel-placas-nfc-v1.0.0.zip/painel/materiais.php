<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require_login();
require APP_DIR . '/ofertas.php';

/** Ilustração genérica de placa (sem logotipos de terceiros), usada quando o modelo não tem foto. */
function modelo_svg(array $m): string
{
    $paletas = [
        'preto' => ['#111111', '#ffffff', '#c4b5fd'],
        'branco' => ['#ffffff', '#111111', '#7c3aed'],
        'azul' => ['#1d4ed8', '#ffffff', '#bfdbfe'],
        'colorido' => ['url(#grad' . $m['id'] . ')', '#ffffff', '#fde68a'],
    ];
    [$fundo, $texto, $destaque] = $paletas[$m['cor']] ?? ['#2a2236', '#ffffff', '#c4b5fd'];
    $titulo = $m['tipo'] === 'instagram' ? 'Siga a gente' : 'Avalie a gente';
    $sub = $m['tipo'] === 'instagram' ? 'no Instagram' : 'no Google';
    // QR ilustrativo determinístico
    $qr = '';
    $seed = crc32($m['nome']);
    for ($r = 0; $r < 9; $r++) {
        for ($c = 0; $c < 9; $c++) {
            $canto = ($r < 3 && $c < 3) || ($r < 3 && $c > 5) || ($r > 5 && $c < 3);
            $on = $canto ? !($r % 3 === 1 && $c % 3 === 1) : (($seed >> (($r * 9 + $c) % 31)) & 1);
            if ($on) {
                $qr .= sprintf('<rect x="%d" y="%d" width="6" height="6"/>', 88 + $c * 6, 196 + $r * 6);
            }
        }
    }
    $stars = $m['tipo'] === 'google'
        ? '<g fill="' . $destaque . '">' . implode('', array_map(fn($i) => sprintf('<path transform="translate(%d 150) scale(.9)" d="M10 0l3 6.5 7 .8-5.2 4.8 1.4 7L10 15.6 3.8 19l1.4-7L0 7.3l7-.8z"/>', 47 + $i * 22), range(0, 4))) . '</g>'
        : '<rect x="106" y="148" width="28" height="28" rx="9" fill="none" stroke="' . $destaque . '" stroke-width="4"/><circle cx="120" cy="162" r="6" fill="none" stroke="' . $destaque . '" stroke-width="4"/>';
    $borda = $m['cor'] === 'branco' ? ' stroke="#d9d3e4" stroke-width="2"' : '';
    return '<svg viewBox="0 0 240 320" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="' . h($m['nome']) . '">'
        . '<defs><linearGradient id="grad' . $m['id'] . '" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f59e0b"/><stop offset=".5" stop-color="#db2777"/><stop offset="1" stop-color="#7c3aed"/></linearGradient></defs>'
        . '<rect x="4" y="4" width="232" height="312" rx="22" fill="' . $fundo . '"' . $borda . '/>'
        . '<g fill="none" stroke="' . $destaque . '" stroke-width="5" stroke-linecap="round"><path d="M104 46a22 22 0 0 0 0 30"/><path d="M136 46a22 22 0 0 1 0 30"/><path d="M93 36a36 36 0 0 0 0 50"/><path d="M147 36a36 36 0 0 1 0 50"/></g>'
        . '<circle cx="120" cy="61" r="5" fill="' . $destaque . '"/>'
        . '<text x="120" y="116" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700" font-size="20" fill="' . $texto . '">' . $titulo . '</text>'
        . '<text x="120" y="136" text-anchor="middle" font-family="Arial, sans-serif" font-size="14" fill="' . $texto . '" opacity=".85">' . $sub . '</text>'
        . $stars
        . '<rect x="80" y="188" width="70" height="70" rx="6" fill="#ffffff"/><g fill="#111111">' . $qr . '</g>'
        . '<text x="120" y="290" text-anchor="middle" font-family="Arial, sans-serif" font-size="11" fill="' . $texto . '" opacity=".75">Aproxime o celular ou leia o QR</text>'
        . '</svg>';
}

function salvar_foto_modelo(int $modeloId, array $file): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) {
        throw new DomainException('Envie uma imagem.');
    }
    if ($file['size'] > 5 * 1024 * 1024) {
        throw new DomainException('Imagem muito grande (máximo 5 MB).');
    }
    $info = @getimagesize($file['tmp_name']);
    $tipos = [IMAGETYPE_JPEG => 'jpeg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
    if (!$info || !isset($tipos[$info[2]])) {
        throw new DomainException('Formato não aceito. Use JPG, PNG ou WEBP.');
    }
    $nome = 'modelo-' . $modeloId . '-' . bin2hex(random_bytes(4)) . '.jpg';
    $destino = ROOT_DIR . '/uploads/' . $nome;
    if (function_exists('imagecreatefromstring')) {
        // Recodifica a imagem: remove metadados e qualquer conteúdo que não seja imagem.
        $img = @imagecreatefromstring((string)file_get_contents($file['tmp_name']));
        if (!$img) {
            throw new DomainException('Não foi possível ler a imagem.');
        }
        $w = imagesx($img);
        $h = imagesy($img);
        $max = 1200;
        if ($w > $max || $h > $max) {
            $esc = $max / max($w, $h);
            $nova = imagecreatetruecolor((int)($w * $esc), (int)($h * $esc));
            imagefill($nova, 0, 0, imagecolorallocate($nova, 255, 255, 255));
            imagecopyresampled($nova, $img, 0, 0, 0, 0, (int)($w * $esc), (int)($h * $esc), $w, $h);
            $img = $nova;
        }
        imagejpeg($img, $destino, 85);
    } else {
        if (!move_uploaded_file($file['tmp_name'], $destino)) {
            throw new DomainException('Falha ao salvar a imagem.');
        }
    }
    return $nome;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mid = post_int('modelo_id');
    $modelo = q_one('SELECT * FROM modelos WHERE id = ?', [$mid]);
    try {
        if (!$modelo) {
            throw new DomainException('Modelo não encontrado.');
        }
        if (post('acao') === 'foto') {
            $nome = salvar_foto_modelo($mid, $_FILES['foto'] ?? []);
            if ($modelo['foto'] && is_file(ROOT_DIR . '/uploads/' . basename($modelo['foto']))) {
                @unlink(ROOT_DIR . '/uploads/' . basename($modelo['foto']));
            }
            q('UPDATE modelos SET foto = ? WHERE id = ?', [$nome, $mid]);
            flash('success', 'Foto do modelo atualizada.');
        } elseif (post('acao') === 'remover_foto') {
            if ($modelo['foto']) {
                @unlink(ROOT_DIR . '/uploads/' . basename($modelo['foto']));
            }
            q('UPDATE modelos SET foto = NULL WHERE id = ?', [$mid]);
            flash('success', 'Foto removida. O catálogo volta a mostrar a ilustração.');
        }
    } catch (DomainException $e) {
        flash('danger', $e->getMessage());
    }
    redirect('materiais.php#catalogo');
}

$modelos = q_all("SELECT m.*, COALESCE(SUM(p.status = 'estoque'), 0) AS em_estoque FROM modelos m LEFT JOIN placas p ON p.modelo_id = m.id WHERE m.ativo = 1 GROUP BY m.id ORDER BY m.ordem, m.nome");
$ofertas = ofertas_conteudo();
$rodape = implode('  ·  ', array_filter([cfg('nome_comercial'), cfg('whatsapp_contato'), cfg('instagram_contato')]));

$fotoOuSvg = function (array $m): string {
    if ($m['foto'] && is_file(ROOT_DIR . '/uploads/' . basename($m['foto']))) {
        return '<img src="uploads/' . h(basename($m['foto'])) . '" alt="' . h($m['nome']) . '" loading="lazy">';
    }
    return modelo_svg($m);
};

/* ---------------- Modo apresentação (para mostrar ao cliente no celular) ---------------- */
if (get('apresentar') === '1') { ?>
<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>Modelos de plaquinha</title>
<link rel="stylesheet" href="assets/vendor/bootstrap/bootstrap.min.css"><link rel="stylesheet" href="assets/app.css?v=<?= APP_VERSION ?>">
<style>body{background:#0d0b12;color:#fff}.modelo-card{background:#1a1625;border-radius:1rem;padding:1rem}.oferta{background:#1a1625;border-radius:1rem;padding:1.25rem;height:100%}.oferta.dest{background:#7c3aed}</style>
</head><body>
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-4"><div><div class="small text-uppercase" style="color:#c4b5fd">Plaquinha de avaliação NFC + QR</div><h1 class="h3 mb-0">Escolha o modelo</h1></div><a class="btn btn-sm btn-outline-light" href="materiais.php">Sair</a></div>
  <div class="row g-3 mb-5">
    <?php foreach ($modelos as $m): ?><div class="col-6 col-md-4 col-lg-3"><div class="modelo-card"><?= $fotoOuSvg($m) ?><div class="mt-2 fw-semibold"><?= h($m['nome']) ?></div></div></div><?php endforeach; ?>
  </div>
  <h2 class="h4 mb-3">Opções</h2>
  <div class="row g-3">
    <?php foreach (['combo', 'avulsa', 'kit2'] as $k): $o = $ofertas[$k]; ?>
      <div class="col-md-4"><div class="oferta<?= $k === 'combo' ? ' dest' : '' ?>">
        <div class="fw-bold fs-5"><?= h($o['nome']) ?></div>
        <div class="display-6 fw-bold my-2"><?= money($o['preco']) ?></div>
        <div class="small opacity-75 mb-2"><?= h($o['nota_preco']) ?></div>
        <ul class="mb-0 ps-3"><?php foreach ($o['itens'] as $i): ?><li><?= h($i) ?></li><?php endforeach; ?></ul>
      </div></div>
    <?php endforeach; ?>
  </div>
</div></body></html>
<?php exit; }

layout_header('Materiais de venda', 'materiais');
page_title('Materiais de venda', 'Catálogo para mostrar ao cliente, cards para o catálogo do WhatsApp Business e PDF de ofertas.',
    '<a class="btn btn-dark" href="materiais.php?apresentar=1"><i class="bi bi-phone me-1"></i>Modo apresentação</a>');
?>
<div class="card mb-4" id="catalogo">
  <div class="card-header">Catálogo de modelos</div>
  <div class="card-body">
    <p class="small text-secondary">Sem foto, o catálogo mostra uma ilustração genérica do modelo. Envie a foto real da placa para ficar mais fiel (JPG, PNG ou WEBP).</p>
    <div class="row g-4">
      <?php foreach ($modelos as $m): ?>
        <div class="col-6 col-md-4 col-xl-3">
          <div class="modelo-card">
            <?= $fotoOuSvg($m) ?>
            <div class="fw-semibold mt-2"><?= h($m['nome']) ?></div>
            <div class="small text-secondary mb-2"><?= (int)$m['em_estoque'] ?> em estoque</div>
            <form method="post" enctype="multipart/form-data" class="d-flex gap-1">
              <?= csrf_field() ?><input type="hidden" name="acao" value="foto"><input type="hidden" name="modelo_id" value="<?= $m['id'] ?>">
              <input class="form-control form-control-sm" type="file" name="foto" accept="image/jpeg,image/png,image/webp" required>
              <button class="btn btn-sm btn-outline-primary" title="Enviar foto"><i class="bi bi-upload"></i></button>
            </form>
            <?php if ($m['foto']): ?>
              <form method="post" class="mt-1"><?= csrf_field() ?><input type="hidden" name="acao" value="remover_foto"><input type="hidden" name="modelo_id" value="<?= $m['id'] ?>"><button class="btn btn-sm btn-link p-0 text-danger">remover foto</button></form>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<div class="card mb-4" id="card">
  <div class="card-header">Card de oferta 1080x1080 (PNG)</div>
  <div class="card-body">
    <div class="row g-4">
      <div class="col-lg-5">
        <div class="btn-group w-100 mb-3" role="group">
          <?php foreach (['combo' => 'Google Completo', 'avulsa' => 'Avulsa', 'kit2' => 'Kit 2'] as $k => $l): ?>
            <input type="radio" class="btn-check" name="cardTipo" id="ct_<?= $k ?>" value="<?= $k ?>"<?= $k === 'combo' ? ' checked' : '' ?>>
            <label class="btn btn-outline-primary" for="ct_<?= $k ?>"><?= $l ?></label>
          <?php endforeach; ?>
        </div>
        <div class="mb-2"><label class="form-label small">Título</label><input class="form-control" id="cTitulo"></div>
        <div class="mb-2"><label class="form-label small">Chamada</label><input class="form-control" id="cChamada"></div>
        <div class="mb-2"><label class="form-label small">Itens (um por linha)</label><textarea class="form-control" id="cItens" rows="3"></textarea></div>
        <div class="row g-2 mb-2">
          <div class="col-6"><label class="form-label small">Preço</label><input class="form-control" id="cPreco"></div>
          <div class="col-6"><label class="form-label small">Abaixo do preço</label><input class="form-control" id="cNota"></div>
        </div>
        <div class="mb-3"><label class="form-label small">Rodapé</label><input class="form-control" id="cRodape" value="<?= h($rodape) ?>"></div>
        <div class="mb-1"><label class="form-label small">Nome do arquivo</label><input class="form-control font-monospace form-control-sm" id="cArquivo"></div>
        <button class="btn btn-primary w-100 mt-2" type="button" id="cBaixar"><i class="bi bi-download me-1"></i>Baixar PNG 1080x1080</button>
        <div class="form-text">Use no catálogo do WhatsApp Business. O texto pode ser ajustado antes de baixar.</div>
      </div>
      <div class="col-lg-7 text-center">
        <canvas id="cardCanvas" width="1080" height="1080" class="canvas-preview"></canvas>
      </div>
    </div>
  </div>
</div>

<div class="card mb-4">
  <div class="card-header">PDF de ofertas (para quem pede "manda por escrito")</div>
  <div class="card-body d-flex flex-wrap gap-2 align-items-center">
    <a class="btn btn-primary" href="oferta_pdf.php?download=1"><i class="bi bi-file-earmark-pdf me-1"></i>Baixar PDF</a>
    <a class="btn btn-outline-dark" href="oferta_pdf.php" target="_blank">Ver no navegador</a>
    <span class="small text-secondary">Arquivo: ofertas-google-completo-plaquinha.pdf · usa os preços e contatos de Configurações. A mensalidade fica de fora de propósito: ela entra só no pós-venda.</span>
  </div>
</div>

<script>
(function () {
  var ofertas = <?= json_encode(array_map(fn($o) => [
      'titulo' => $o['nome'], 'chamada' => $o['chamada'], 'itens' => $o['itens'],
      'preco' => 'R$ ' . number_format($o['preco'], fmod((float)$o['preco'], 1.0) == 0.0 ? 0 : 2, ',', '.'),
      'nota' => $o['nota_preco'], 'arquivo' => $o['arquivo'],
  ], $ofertas), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
  var cv = document.getElementById('cardCanvas'), ctx = cv.getContext('2d');
  var $ = function (id) { return document.getElementById(id); };
  var FONT = '"Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';

  function wrap(text, maxW, font) {
    ctx.font = font;
    var words = String(text).split(/\s+/), lines = [], line = '';
    words.forEach(function (w) {
      var t = line ? line + ' ' + w : w;
      if (line && ctx.measureText(t).width > maxW) { lines.push(line); line = w; } else { line = t; }
    });
    if (line) lines.push(line);
    return lines;
  }

  function draw() {
    var W = 1080, P = 84;
    ctx.clearRect(0, 0, W, W);
    ctx.fillStyle = '#0d0b12'; ctx.fillRect(0, 0, W, W);
    var g = ctx.createRadialGradient(900, 120, 40, 900, 120, 720);
    g.addColorStop(0, 'rgba(124,58,237,.75)'); g.addColorStop(1, 'rgba(124,58,237,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, W);

    // Ícone NFC
    ctx.strokeStyle = '#c4b5fd'; ctx.lineWidth = 9; ctx.lineCap = 'round';
    [[34, 0.9], [62, 0.9], [90, 0.9]].forEach(function (a) {
      ctx.beginPath(); ctx.arc(W - P - 110, P + 70, a[0], -a[1], a[1]); ctx.stroke();
    });
    ctx.fillStyle = '#c4b5fd'; ctx.beginPath(); ctx.arc(W - P - 110, P + 70, 9, 0, Math.PI * 2); ctx.fill();

    // Selo
    ctx.fillStyle = '#7c3aed';
    ctx.beginPath(); ctx.roundRect ? ctx.roundRect(P, P, 270, 58, 29) : ctx.rect(P, P, 270, 58); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.font = '700 28px ' + FONT; ctx.textBaseline = 'middle';
    ctx.fillText('NFC + QR CODE', P + 30, P + 30);
    ctx.textBaseline = 'alphabetic';

    var y = P + 190;
    wrap($('cTitulo').value, W - 2 * P, '800 92px ' + FONT).forEach(function (l) {
      ctx.fillStyle = '#fff'; ctx.font = '800 92px ' + FONT; ctx.fillText(l, P, y); y += 100;
    });
    y += 6;
    wrap($('cChamada').value, W - 2 * P, '500 42px ' + FONT).forEach(function (l) {
      ctx.fillStyle = '#c4b5fd'; ctx.font = '500 42px ' + FONT; ctx.fillText(l, P, y); y += 54;
    });
    y += 34;
    $('cItens').value.split('\n').filter(function (s) { return s.trim(); }).slice(0, 4).forEach(function (item) {
      ctx.fillStyle = '#7c3aed'; ctx.beginPath(); ctx.arc(P + 20, y - 13, 20, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(P + 10, y - 13); ctx.lineTo(P + 18, y - 5); ctx.lineTo(P + 31, y - 22); ctx.stroke();
      var ls = wrap(item.trim(), W - 2 * P - 64, '500 36px ' + FONT);
      ls.forEach(function (l, i) { ctx.fillStyle = '#fff'; ctx.font = '500 36px ' + FONT; ctx.fillText(l, P + 62, y + i * 44); });
      y += 44 * ls.length + 22;
    });

    // Preço
    var baseY = W - 170;
    ctx.fillStyle = '#fff'; ctx.font = '800 128px ' + FONT; ctx.fillText($('cPreco').value, P, baseY);
    ctx.fillStyle = '#c4b5fd'; ctx.font = '500 34px ' + FONT; ctx.fillText($('cNota').value, P + 6, baseY + 46);

    // Rodapé
    ctx.fillStyle = '#7c3aed'; ctx.fillRect(0, W - 64, W, 64);
    ctx.fillStyle = '#fff'; ctx.font = '600 28px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText($('cRodape').value, W / 2, W - 32);
    ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  }

  function load(tipo) {
    var o = ofertas[tipo];
    $('cTitulo').value = o.titulo; $('cChamada').value = o.chamada; $('cItens').value = o.itens.join('\n');
    $('cPreco').value = o.preco; $('cNota').value = o.nota; $('cArquivo').value = o.arquivo;
    draw();
  }

  document.querySelectorAll('input[name="cardTipo"]').forEach(function (r) { r.addEventListener('change', function () { load(r.value); }); });
  ['cTitulo', 'cChamada', 'cItens', 'cPreco', 'cNota', 'cRodape'].forEach(function (id) { $(id).addEventListener('input', draw); });
  $('cBaixar').addEventListener('click', function () {
    cv.toBlob(function (blob) {
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = ($('cArquivo').value || 'card-oferta-1080x1080.png').replace(/[^\w.\-]/g, '-');
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
    }, 'image/png');
  });
  (document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve()).then(function () { load('combo'); });
})();
</script>
<?php layout_footer();
