<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require_login();

$id = get_int('id') ?: post_int('id');
$c = q_one('SELECT * FROM clientes WHERE id = ?', [$id]);
if (!$c) {
    not_found('Cliente não encontrado.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = post('acao');
    if ($acao === 'editar') {
        if (post('nome') === '') {
            flash('danger', 'O nome não pode ficar vazio.');
        } else {
            $origem = array_key_exists(post('origem'), ORIGENS) ? post('origem') : 'outro';
            q('UPDATE clientes SET nome = ?, nicho = ?, bairro = ?, whatsapp = ?, origem = ?, link_google = ?, observacoes = ? WHERE id = ?',
                [mb_substr(post('nome'), 0, 120), mb_substr(post('nicho'), 0, 60), mb_substr(post('bairro'), 0, 80), mb_substr(post('whatsapp'), 0, 30), $origem, clean_url(post('link_google')), post('observacoes'), $id]);
            flash('success', 'Cliente atualizado.');
        }
        redirect('cliente.php?id=' . $id);
    }
    if ($acao === 'excluir') {
        $temVinculo = q_val('SELECT COUNT(*) FROM vendas WHERE cliente_id = ?', [$id]) + q_val('SELECT COUNT(*) FROM assinaturas WHERE cliente_id = ?', [$id]);
        if ($temVinculo > 0) {
            flash('danger', 'Cliente com vendas ou assinaturas não pode ser excluído.');
            redirect('cliente.php?id=' . $id);
        }
        q('DELETE FROM clientes WHERE id = ?', [$id]);
        flash('success', 'Cliente excluído.');
        redirect('clientes.php');
    }
}

$placas = q_all('SELECT p.*, m.nome AS modelo,
        (SELECT k.nota FROM checagens k WHERE k.placa_id = p.id ORDER BY k.data_checagem DESC, k.id DESC LIMIT 1) AS ult_nota,
        (SELECT k.avaliacoes FROM checagens k WHERE k.placa_id = p.id ORDER BY k.data_checagem DESC, k.id DESC LIMIT 1) AS ult_aval,
        (SELECT k.data_checagem FROM checagens k WHERE k.placa_id = p.id ORDER BY k.data_checagem DESC, k.id DESC LIMIT 1) AS ult_data
    FROM placas p JOIN modelos m ON m.id = p.modelo_id WHERE p.cliente_id = ? ORDER BY p.codigo', [$id]);
$vendas = q_all('SELECT v.*, (SELECT u.id FROM vendas u WHERE u.venda_origem_id = v.id LIMIT 1) AS upgrade_id FROM vendas v WHERE v.cliente_id = ? ORDER BY v.data_venda, v.id', [$id]);
$assinaturas = q_all('SELECT * FROM assinaturas WHERE cliente_id = ? ORDER BY data_inicio DESC, id DESC', [$id]);
$ativa = null;
foreach ($assinaturas as $a) {
    if ($a['status'] === 'ativa') {
        $ativa = $a;
        break;
    }
}
$pagamentos = $ativa ? q_all('SELECT * FROM pagamentos_assinatura WHERE assinatura_id = ? ORDER BY data_pagamento DESC LIMIT 6', [$ativa['id']]) : [];

// Linha do tempo: vendas, instalações, checagens e assinaturas
$timeline = [];
foreach ($vendas as $v) {
    $timeline[] = [$v['data_venda'], 'bi-cash-coin', tipo_venda_label($v['tipo']) . ' · ' . money($v['valor']), 'venda.php?id=' . $v['id']];
}
foreach ($placas as $p) {
    if ($p['data_instalacao']) {
        $timeline[] = [$p['data_instalacao'], 'bi-tools', "Instalação {$p['codigo']} · marco zero " . nota_fmt($p['marco_nota']) . " / {$p['marco_avaliacoes']} aval.", 'placa.php?id=' . $p['id']];
    }
}
foreach (q_all('SELECT k.*, p.codigo, p.id AS pid FROM checagens k JOIN placas p ON p.id = k.placa_id WHERE p.cliente_id = ?', [$id]) as $k) {
    $timeline[] = [$k['data_checagem'], 'bi-graph-up-arrow', "Checagem {$k['codigo']} · " . nota_fmt($k['nota']) . " / {$k['avaliacoes']} aval.", 'placa.php?id=' . $k['pid']];
}
foreach ($assinaturas as $a) {
    $timeline[] = [$a['data_inicio'], 'bi-arrow-repeat', 'Assinatura iniciada · ' . money($a['valor']) . '/mês', 'assinaturas.php?id=' . $a['id']];
    if ($a['data_fim']) {
        $timeline[] = [$a['data_fim'], 'bi-stop-circle', 'Assinatura encerrada', 'assinaturas.php?id=' . $a['id']];
    }
}
usort($timeline, fn($x, $y) => strcmp($y[0], $x[0]));

layout_header($c['nome'], 'clientes');
$acoes = '<a class="btn btn-primary" href="venda_nova.php?cliente=' . $id . '"><i class="bi bi-cart-plus me-1"></i>Nova venda</a>';
if ($w = whatsapp_link($c['whatsapp'])) {
    $acoes = '<a class="btn btn-outline-success" href="' . h($w) . '" target="_blank" rel="noopener noreferrer"><i class="bi bi-whatsapp me-1"></i>WhatsApp</a>' . $acoes;
}
if ($c['link_google'] !== '') {
    $acoes = '<a class="btn btn-outline-dark" href="' . h($c['link_google']) . '" target="_blank" rel="noopener noreferrer"><i class="bi bi-geo-alt me-1"></i>Perfil Google</a>' . $acoes;
}
page_title($c['nome'], h(implode(' · ', array_filter([$c['nicho'], $c['bairro'], origem_label($c['origem'])]))), $acoes);
?>
<div class="row g-4">
  <div class="col-lg-8">
    <div class="card mb-4">
      <div class="card-header">Placas</div>
      <?php if (!$placas): ?><div class="empty">Nenhuma placa vinculada ainda.</div><?php else: ?>
      <div class="table-responsive"><table class="table align-middle mb-0">
        <thead><tr><th>Código</th><th>Status</th><th>Instalação</th><th>Marco zero</th><th>Última checagem</th><th class="text-end">Evolução</th></tr></thead>
        <tbody><?php foreach ($placas as $p): ?>
          <tr>
            <td><a class="code-pill" href="placa.php?id=<?= $p['id'] ?>"><?= h($p['codigo']) ?></a><div class="small text-secondary"><?= h($p['modelo']) ?></div></td>
            <td><?= status_placa_badge($p['status']) ?></td>
            <td class="small"><?= date_br($p['data_instalacao']) ?></td>
            <td class="small"><?= $p['marco_nota'] !== null ? nota_fmt($p['marco_nota']) . ' · ' . (int)$p['marco_avaliacoes'] : '-' ?></td>
            <td class="small"><?= $p['ult_data'] ? nota_fmt($p['ult_nota']) . ' · ' . (int)$p['ult_aval'] . ' <span class="text-secondary">(' . date_br($p['ult_data']) . ')</span>' : '-' ?></td>
            <td class="text-end"><?= ($p['ult_data'] && $p['marco_avaliacoes'] !== null) ? delta_html((int)$p['ult_aval'] - (int)$p['marco_avaliacoes']) . ' aval.' : '-' ?></td>
          </tr>
        <?php endforeach; ?></tbody>
      </table></div>
      <?php endif; ?>
    </div>

    <div class="card mb-4">
      <div class="card-header">Vendas</div>
      <?php if (!$vendas): ?><div class="empty">Nenhuma venda ainda. <a href="venda_nova.php?cliente=<?= $id ?>">Registrar venda</a>.</div><?php else: ?>
      <div class="table-responsive"><table class="table align-middle mb-0">
        <thead><tr><th>Data</th><th>Oferta</th><th>Pagamento</th><th class="text-end">Valor</th><th></th></tr></thead>
        <tbody><?php foreach ($vendas as $v): ?>
          <tr>
            <td><?= date_br($v['data_venda']) ?></td>
            <td><a href="venda.php?id=<?= $v['id'] ?>"><?= h(tipo_venda_label($v['tipo'])) ?></a></td>
            <td class="small"><?= h(pagamento_label($v['forma_pagamento'])) ?></td>
            <td class="text-end"><?= money($v['valor']) ?></td>
            <td class="text-end"><?php if (in_array($v['tipo'], ['avulsa', 'kit2'], true) && !$v['upgrade_id']): ?><a class="btn btn-sm btn-outline-primary" href="venda.php?id=<?= $v['id'] ?>">Upgrade p/ combo</a><?php endif; ?></td>
          </tr>
        <?php endforeach; ?></tbody>
        <tfoot><tr><th colspan="3" class="text-end">Total vendido</th><th class="text-end"><?= money(array_sum(array_column($vendas, 'valor'))) ?></th><th></th></tr></tfoot>
      </table></div>
      <?php endif; ?>
    </div>

    <div class="card mb-4" id="assinatura">
      <div class="card-header d-flex justify-content-between"><span>Assinatura mensal</span><?php if ($ativa): ?><span class="badge bg-roxo"><?= money($ativa['valor']) ?>/mês</span><?php endif; ?></div>
      <div class="card-body">
        <?php if ($ativa): ?>
          <div class="row g-3 mb-3">
            <div class="col-6 col-md-3"><div class="small text-secondary">Início</div><div class="fw-semibold"><?= date_br($ativa['data_inicio']) ?></div></div>
            <div class="col-6 col-md-3"><div class="small text-secondary">Próximo relatório</div><div class="fw-semibold<?= $ativa['proximo_relatorio'] < today() ? ' text-danger' : '' ?>"><?= date_br($ativa['proximo_relatorio']) ?></div></div>
            <div class="col-6 col-md-3"><div class="small text-secondary">Último pagamento</div><div class="fw-semibold"><?= $pagamentos ? date_br($pagamentos[0]['data_pagamento']) : '-' ?></div></div>
            <div class="col-6 col-md-3"><a class="btn btn-sm btn-outline-primary w-100" href="assinaturas.php?id=<?= $ativa['id'] ?>">Gerenciar</a></div>
          </div>
          <div class="d-flex flex-wrap gap-2">
            <form method="post" action="assinaturas.php"><?= csrf_field() ?><input type="hidden" name="acao" value="relatorio"><input type="hidden" name="id" value="<?= $ativa['id'] ?>"><input type="hidden" name="data" value="<?= today() ?>"><input type="hidden" name="volta" value="cliente">
              <button class="btn btn-sm btn-primary"><i class="bi bi-send-check me-1"></i>Relatório enviado hoje</button></form>
            <form method="post" action="assinaturas.php"><?= csrf_field() ?><input type="hidden" name="acao" value="pagamento"><input type="hidden" name="id" value="<?= $ativa['id'] ?>"><input type="hidden" name="valor" value="<?= h($ativa['valor']) ?>"><input type="hidden" name="data" value="<?= today() ?>"><input type="hidden" name="forma_pagamento" value="pix"><input type="hidden" name="referencia" value="<?= date('Y-m') ?>"><input type="hidden" name="volta" value="cliente">
              <button class="btn btn-sm btn-outline-success"><i class="bi bi-cash me-1"></i>Mensalidade paga hoje (<?= money($ativa['valor']) ?>, Pix)</button></form>
          </div>
        <?php else: ?>
          <p class="text-secondary small mb-3">Sem assinatura ativa. A assinatura mantém a placa ativa com relatório mensal e respostas às avaliações.</p>
          <form method="post" action="assinaturas.php" class="row g-2 align-items-end">
            <?= csrf_field() ?><input type="hidden" name="acao" value="criar"><input type="hidden" name="cliente_id" value="<?= $id ?>"><input type="hidden" name="volta" value="cliente">
            <div class="col-6 col-md-4"><label class="form-label small">Mensalidade</label><div class="input-group"><span class="input-group-text">R$</span><input class="form-control" name="valor" value="<?= number_format((float)cfg('mensalidade_padrao', '24.90'), 2, ',', '') ?>" inputmode="decimal" required></div></div>
            <div class="col-6 col-md-4"><label class="form-label small">Início</label><input type="date" class="form-control" name="data_inicio" value="<?= today() ?>" required></div>
            <div class="col-md-4"><button class="btn btn-primary w-100">Iniciar assinatura</button></div>
          </form>
        <?php endif; ?>
        <?php $antigas = array_filter($assinaturas, fn($a) => $a['status'] !== 'ativa'); if ($antigas): ?>
          <div class="small text-secondary mt-3">Assinaturas anteriores: <?php foreach ($antigas as $a): ?><a href="assinaturas.php?id=<?= $a['id'] ?>"><?= date_br($a['data_inicio']) ?> a <?= date_br($a['data_fim']) ?> (<?= money($a['valor']) ?>)</a> <?php endforeach; ?></div>
        <?php endif; ?>
      </div>
    </div>

    <div class="card">
      <div class="card-header">Linha do tempo</div>
      <?php if (!$timeline): ?><div class="empty">Sem eventos ainda.</div><?php else: ?>
      <ul class="list-group list-group-flush">
        <?php foreach ($timeline as [$data, $icone, $texto, $link]): ?>
          <li class="list-group-item d-flex gap-3 align-items-center"><span class="text-secondary small" style="min-width:80px"><?= date_br($data) ?></span><i class="bi <?= $icone ?> text-roxo"></i><a class="text-reset" href="<?= h($link) ?>"><?= h($texto) ?></a></li>
        <?php endforeach; ?>
      </ul>
      <?php endif; ?>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card mb-4"><div class="card-header">Dados do cliente</div><div class="card-body">
      <form method="post" class="row g-2">
        <?= csrf_field() ?><input type="hidden" name="acao" value="editar"><input type="hidden" name="id" value="<?= $id ?>">
        <div class="col-12"><label class="form-label small">Nome do comércio</label><input class="form-control" name="nome" value="<?= h($c['nome']) ?>" required></div>
        <div class="col-6"><label class="form-label small">Nicho</label><input class="form-control" name="nicho" value="<?= h($c['nicho']) ?>"></div>
        <div class="col-6"><label class="form-label small">Bairro</label><input class="form-control" name="bairro" value="<?= h($c['bairro']) ?>"></div>
        <div class="col-6"><label class="form-label small">WhatsApp</label><input class="form-control" name="whatsapp" value="<?= h($c['whatsapp']) ?>" inputmode="tel"></div>
        <div class="col-6"><label class="form-label small">Origem</label><select class="form-select" name="origem"><?= options(ORIGENS, $c['origem']) ?></select></div>
        <div class="col-12"><label class="form-label small">Link do perfil Google</label><input class="form-control" type="url" name="link_google" value="<?= h($c['link_google']) ?>"></div>
        <div class="col-12"><label class="form-label small">Observações</label><textarea class="form-control" name="observacoes" rows="4"><?= h($c['observacoes']) ?></textarea></div>
        <div class="col-12"><button class="btn btn-outline-primary w-100">Salvar</button></div>
      </form>
      <?php if (!$vendas && !$assinaturas): ?>
        <form method="post" class="mt-3" data-confirm="Excluir este cliente?"><?= csrf_field() ?><input type="hidden" name="acao" value="excluir"><input type="hidden" name="id" value="<?= $id ?>">
          <button class="btn btn-sm btn-link text-danger p-0">Excluir cliente</button></form>
      <?php endif; ?>
    </div></div>
    <div class="small text-secondary">Cliente desde <?= date_br($c['criado_em']) ?></div>
  </div>
</div>
<?php layout_footer();
