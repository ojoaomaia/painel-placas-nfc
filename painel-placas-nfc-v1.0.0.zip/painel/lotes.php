<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = post('acao');
    try {
        if ($acao === 'criar') {
            $ids = preg_split('/\r\n|\r|\n/', post('placason_ids')) ?: [];
            $r = criar_lote(
                post('data_compra'),
                post_int('modelo_id'),
                post_int('quantidade'),
                parse_money(post('custo_unitario')),
                post('fornecedor'),
                post('observacoes'),
                $ids
            );
            $c = $r['codigos'];
            flash('success', sprintf('Lote #%d registrado com %d placa(s): %s%s.', $r['lote_id'], count($c), $c[0], count($c) > 1 ? ' a ' . end($c) : ''));
            redirect('placas.php?lote=' . $r['lote_id']);
        }
        if ($acao === 'excluir') {
            $id = post_int('id');
            $usadas = (int)q_val("SELECT COUNT(*) FROM placas WHERE lote_id = ? AND status <> 'estoque'", [$id]);
            if ($usadas > 0) {
                throw new DomainException('Esse lote já tem placas vendidas. Ele não pode ser excluído.');
            }
            transaction(function () use ($id) {
                q('DELETE FROM placas WHERE lote_id = ?', [$id]);
                q('DELETE FROM lotes WHERE id = ?', [$id]);
            });
            flash('success', "Lote #{$id} excluído.");
            redirect('lotes.php');
        }
    } catch (DomainException $e) {
        flash('danger', $e->getMessage());
        redirect('lotes.php' . ($acao === 'criar' ? '?novo=1' : ''));
    }
}

$modelos = q_all('SELECT id, nome FROM modelos WHERE ativo = 1 ORDER BY ordem, nome');
$lotes = q_all("SELECT l.*, m.nome AS modelo,
        SUM(p.status = 'estoque') AS em_estoque, COUNT(p.id) AS placas,
        MIN(p.codigo) AS primeiro, MAX(p.codigo) AS ultimo
    FROM lotes l JOIN modelos m ON m.id = l.modelo_id LEFT JOIN placas p ON p.lote_id = l.id
    GROUP BY l.id ORDER BY l.data_compra DESC, l.id DESC");
$estoque = estoque_por_modelo();
$abrir = get('novo') === '1' || !$lotes;

layout_header('Lotes e estoque', 'lotes');
page_title('Lotes e estoque', 'Compras de placas do fornecedor e estoque por modelo.',
    '<button class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#novoLote"><i class="bi bi-plus-lg me-1"></i>Registrar lote</button>');
?>
<div class="collapse<?= $abrir ? ' show' : '' ?> mb-4" id="novoLote">
  <div class="card">
    <div class="card-header">Novo lote</div>
    <div class="card-body">
      <form method="post" class="row g-3">
        <?= csrf_field() ?><input type="hidden" name="acao" value="criar">
        <div class="col-6 col-md-3"><label class="form-label">Data da compra</label><input type="date" class="form-control" name="data_compra" value="<?= today() ?>" required></div>
        <div class="col-6 col-md-3"><label class="form-label">Modelo</label>
          <select class="form-select" name="modelo_id" required><?php foreach ($modelos as $m): ?><option value="<?= $m['id'] ?>"><?= h($m['nome']) ?></option><?php endforeach; ?></select></div>
        <div class="col-6 col-md-2"><label class="form-label">Quantidade</label><input type="number" min="1" max="500" class="form-control" name="quantidade" value="10" required></div>
        <div class="col-6 col-md-2"><label class="form-label">Custo unitário</label><div class="input-group"><span class="input-group-text">R$</span><input class="form-control" name="custo_unitario" value="20,00" inputmode="decimal" required></div></div>
        <div class="col-12 col-md-2"><label class="form-label">Fornecedor</label><input class="form-control" name="fornecedor" value="PlacasOn"></div>
        <div class="col-md-6"><label class="form-label">IDs na PlacasOn <span class="text-secondary small">(opcional, um por linha, na ordem das placas)</span></label>
          <textarea class="form-control font-monospace" name="placason_ids" rows="3" placeholder="Pode preencher depois na ficha de cada placa"></textarea></div>
        <div class="col-md-6"><label class="form-label">Observações</label><textarea class="form-control" name="observacoes" rows="3"></textarea></div>
        <div class="col-12"><button class="btn btn-primary">Registrar lote e gerar códigos</button>
          <span class="text-secondary small ms-2">Cada placa recebe um código sequencial (PNF-0001, PNF-0002...).</span></div>
      </form>
    </div>
  </div>
</div>

<div class="card mb-4">
  <div class="card-header">Estoque por modelo</div>
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead><tr><th>Modelo</th><th class="text-end">Em estoque</th><th class="text-end">Mínimo</th><th class="text-end">Já saíram</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($estoque as $m): $baixo = (int)$m['ativo'] && (int)$m['em_estoque'] <= (int)$m['estoque_minimo']; ?>
        <tr class="<?= $m['ativo'] ? '' : 'text-secondary' ?>">
          <td><?= h($m['nome']) ?><?= $m['ativo'] ? '' : ' <span class="badge text-bg-light">inativo</span>' ?></td>
          <td class="text-end fw-semibold"><a href="placas.php?status=estoque&modelo=<?= $m['id'] ?>"><?= (int)$m['em_estoque'] ?></a></td>
          <td class="text-end"><?= (int)$m['estoque_minimo'] ?></td>
          <td class="text-end"><?= (int)$m['saidas'] ?></td>
          <td class="text-end"><?= $baixo ? '<span class="badge text-bg-danger"><i class="bi bi-exclamation-triangle me-1"></i>Estoque baixo</span>' : '' ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="card-footer bg-white small text-secondary">O estoque mínimo de cada modelo é ajustado em <a href="configuracoes.php#modelos">Configurações</a>.</div>
</div>

<div class="card">
  <div class="card-header">Lotes registrados</div>
  <?php if (!$lotes): ?>
    <div class="empty">Nenhum lote ainda. Registre a primeira compra de placas acima.</div>
  <?php else: ?>
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead><tr><th>#</th><th>Data</th><th>Modelo</th><th>Códigos</th><th class="text-end">Qtd</th><th class="text-end">Em estoque</th><th class="text-end">Custo un.</th><th class="text-end">Total</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($lotes as $l): ?>
        <tr>
          <td><?= (int)$l['id'] ?></td>
          <td><?= date_br($l['data_compra']) ?></td>
          <td><?= h($l['modelo']) ?></td>
          <td><a class="code-pill" href="placas.php?lote=<?= $l['id'] ?>"><?= h($l['primeiro']) ?><?= $l['placas'] > 1 ? ' a ' . h($l['ultimo']) : '' ?></a></td>
          <td class="text-end"><?= (int)$l['quantidade'] ?></td>
          <td class="text-end"><?= (int)$l['em_estoque'] ?></td>
          <td class="text-end"><?= money($l['custo_unitario']) ?></td>
          <td class="text-end"><?= money($l['custo_unitario'] * $l['quantidade']) ?></td>
          <td class="text-end">
            <?php if ((int)$l['em_estoque'] === (int)$l['placas']): ?>
              <form method="post" class="d-inline" data-confirm="Excluir o lote #<?= $l['id'] ?> e as <?= (int)$l['placas'] ?> placas dele?">
                <?= csrf_field() ?><input type="hidden" name="acao" value="excluir"><input type="hidden" name="id" value="<?= $l['id'] ?>">
                <button class="btn btn-sm btn-outline-danger" title="Excluir lote"><i class="bi bi-trash"></i></button>
              </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php layout_footer();
