# Teste manual do fluxo completo

Roteiro para conferir, depois de instalar, que o painel funciona de ponta a ponta:
**cadastrar lote → vender placa → vincular cliente → registrar instalação com marco zero → registrar checagem de acompanhamento.**

Cada passo diz o que fazer e o que deve aparecer. Marque ✓ conforme for conferindo. Leva uns 15 minutos.

---

## 0. Login e segurança

| # | Ação | Resultado esperado | ✓ |
| --- | --- | --- | --- |
| 0.1 | Abra o endereço do painel sem estar logado | Vai direto para a tela de login | |
| 0.2 | Entre com a senha errada | Mensagem "Usuário ou senha incorretos" | |
| 0.3 | Entre com a senha certa | Abre o **Painel**, com os cartões Em estoque, Vendidas, Instaladas e MRR zerados | |
| 0.4 | Confira o cadeado do navegador | Endereço com `https://` | |

## 1. Cadastrar lote

| # | Ação | Resultado esperado | ✓ |
| --- | --- | --- | --- |
| 1.1 | **Lotes > Registrar lote**. Modelo "Google Avaliações Preto", quantidade 10, custo 20,00. No campo IDs PlacasOn, digite 3 linhas: `ABC-101`, `ABC-102`, `ABC-103` | Mensagem "Lote #1 registrado com 10 placa(s): PNF-0001 a PNF-0010" e a lista de placas do lote | |
| 1.2 | Veja a coluna **ID PlacasOn** | PNF-0001 a PNF-0003 com ABC-101 a ABC-103, as outras com "-" | |
| 1.3 | Registre outro lote de 3 placas "Google Avaliações Branco" | Códigos continuam a sequência: PNF-0011 a PNF-0013 | |
| 1.4 | Volte ao **Painel** | Em estoque = 13. Aparece "Estoque baixo" para os modelos sem placa (Azul, Instagram) e para o Branco (3 em estoque, mínimo 3) | |

## 2. Vender placa e vincular cliente

| # | Ação | Resultado esperado | ✓ |
| --- | --- | --- | --- |
| 2.1 | **Nova venda**. Oferta **Google Completo** (já vem marcada e com R$ 250,00) | Valor preenchido com 250,00 | |
| 2.2 | Em Cliente, escolha **Novo cliente**: "Classic Centro de Beleza", nicho "Salão de beleza", bairro "Alto da Boa Vista", WhatsApp, origem "Porta a porta" | Campos de novo cliente aparecem | |
| 2.3 | Escolha a placa PNF-0001, pagamento Pix e clique **Registrar venda** | Abre a venda: "Google Completo · R$ 250,00", placa PNF-0001 com status **Vendida** e botão "Registrar instalação" | |
| 2.4 | Volte ao **Painel** | Vendidas = 1. Em Ações pendentes: "Fotos do combo não tiradas", "Otimização do perfil pendente" e "Instalar PNF-0001 e registrar marco zero" | |
| 2.5 | Teste o kit: **Nova venda**, oferta **Kit 2 Plaquinhas** | Aparece o campo **Placa 2** e o valor muda para 140,00 | |
| 2.6 | Tente registrar o kit com só uma placa | Mensagem "Kit 2 Plaquinhas precisa de 2 placas." | |

## 3. Registrar instalação com marco zero

| # | Ação | Resultado esperado | ✓ |
| --- | --- | --- | --- |
| 3.1 | Abra a placa PNF-0001 (pela venda ou buscando "pnf-1" no topo) | Ficha da placa com o bloco roxo "Registrar instalação e marco zero" | |
| 3.2 | Tente colocar nota 6 | Mensagem "Nota do Google inválida. Use um valor de 1,0 a 5,0." | |
| 3.3 | Preencha data da instalação, nota **4,9**, avaliações **126**, local "Recepção" e registre | Status **Instalada**. Cartão "Marco zero 4,9 · 126 aval." e as datas previstas das checagens de 7 e 30 dias | |
| 3.4 | Abra a venda e ligue "Fotos tiradas no local" e "Perfil do Google otimizado", depois **Salvar etapas** | As duas pendências do combo somem do Painel | |

## 4. Registrar checagem de acompanhamento

| # | Ação | Resultado esperado | ✓ |
| --- | --- | --- | --- |
| 4.1 | Na ficha da PNF-0001, em **Checagens de acompanhamento**, coloque nota 4,9, avaliações **129**, scans **5** e registre | Nova linha na tabela com **+3** em verde na coluna Novas. Cartão roxo "Evolução +3 aval., nota mantida" | |
| 4.2 | Abra a ficha do cliente Classic | Na tabela de placas: marco zero 4,9 · 126, última checagem 4,9 · 129, evolução **+3 aval.** Linha do tempo com venda, instalação e checagem | |
| 4.3 | Clique em **Scans na PlacasOn** | Abre o painel da PlacasOn em outra aba | |

## 5. Assinatura e faturamento (complementar)

| # | Ação | Resultado esperado | ✓ |
| --- | --- | --- | --- |
| 5.1 | Na ficha do cliente, em **Assinatura mensal**, clique **Iniciar assinatura** (já vem R$ 24,90) | Assinatura ativa com o próximo relatório para daqui a 1 mês. MRR no Painel = R$ 24,90 | |
| 5.2 | Clique **Mensalidade paga hoje** | Faturamento do mês no Painel soma vendas do mês + R$ 24,90 | |
| 5.3 | Em **Assinaturas > (cliente)**, clique **Marcar relatório como enviado** | Próximo relatório avança 1 mês. Se estava atrasado, sai das pendências | |

## 6. Upgrade e materiais (complementar)

| # | Ação | Resultado esperado | ✓ |
| --- | --- | --- | --- |
| 6.1 | Faça uma venda **avulsa** e, na tela da venda, use **Upgrade para Google Completo** (R$ 170,00) | Nova venda "Upgrade para Google Completo" com o histórico mostrando a venda avulsa original. Pendências de fotos e perfil aparecem para ela | |
| 6.2 | **Materiais > Card de oferta**, escolha cada oferta e clique **Baixar PNG** | Baixa `card-oferta-google-completo-1080x1080.png` (e os outros), 1080x1080, roxo e preto | |
| 6.3 | **Materiais > Baixar PDF** | Baixa `ofertas-google-completo-plaquinha.pdf`, 1 página, com as 3 ofertas, como funciona, garantias e seus contatos | |
| 6.4 | **Modo apresentação** no celular | Modelos e ofertas em tela escura, fácil de mostrar ao dono do comércio | |

## 7. Limpeza depois do teste

Se fez o teste com dados reais (como o Classic), pode manter. Se usou dados de teste:
- Vendas lançadas por engano: na tela da venda, **Editar venda > Cancelar venda** (só antes da instalação; a placa volta ao estoque).
- Lote de teste sem nenhuma placa vendida: em **Lotes**, botão da lixeira.
- Para zerar tudo: no phpMyAdmin apague todas as tabelas e rode o instalador de novo (envie a pasta `install/` outra vez e apague `app/config.php`).

---

## Resultado do teste automático feito antes da entrega

Antes de gerar o ZIP, o fluxo completo foi executado de verdade em PHP 8.3 + MariaDB 10.11 (mesmo banco usado pela Hostinger), com um script que preenche os formulários como um usuário faria. Resultado em 07/10/2026: **76 verificações, 76 OK, nenhum aviso ou erro de PHP no log** (com todos os níveis de aviso ligados, incluindo os de versões futuras do PHP).

O que foi verificado:

- **Instalação:** instalador cria tabelas e usuário; recusa rodar de novo.
- **Segurança:** página protegida exige login; senha errada recusada; formulário sem token CSRF recusado; cabeçalhos de segurança e cookie HttpOnly; nome de cliente com código HTML exibido como texto (sem XSS); link `javascript:` no perfil Google descartado; arquivo que não é imagem recusado no upload; após 5 senhas erradas o login fica bloqueado mesmo com a senha certa; logout encerra a sessão.
- **Lotes:** códigos PNF sequenciais entre lotes; IDs PlacasOn gravados; data inválida recusada.
- **Vendas:** combo com novo cliente; avulsa; kit com 2 placas (e recusa com 1); placa já vendida não vende de novo; upgrade avulsa para combo mantendo histórico (e recusa de upgrade duplicado); cancelamento devolvendo a placa ao estoque.
- **Instalação e checagens:** recusa instalação antes da venda e nota fora de 1,0 a 5,0; marco zero 4,9 / 126; checagem com +3 avaliações; pendência de 7 dias aparece e some depois da checagem.
- **Painel:** pendências do combo, instalação, checagem e relatório; estoque, MRR e faturamento do mês (vendas + mensalidade) com os valores corretos.
- **Ciclo da placa:** desativar, reativar e substituir por defeito (cliente passa para a placa nova).
- **Assinatura:** criação a R$ 24,90; recusa de segunda assinatura ativa; relatório enviado; pagamento; mensalidade padrão editável.
- **Busca:** por código ("pnf-1"), por nome do cliente e pelo ID da PlacasOn.
- **Materiais:** card 1080x1080 nas 3 ofertas; PDF legível; modo apresentação; foto de modelo recodificada em JPG.
- **Telas:** todas as páginas abrem sem erro; no celular (390 px de largura) não há rolagem lateral; nenhum erro de JavaScript.
